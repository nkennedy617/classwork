#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include "iobuffer.h"

int main()
{
	char *filename;
	filename = "this.txt";
	fstream fin(filename, ios::end);
	if (fin.tellp() != fin.eof())
	   cout << "Ooops"<<endl;
	else
	   cout << "Worked"<<endl;
	fin.close();
	return 1;
}
