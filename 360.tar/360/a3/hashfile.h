#include "recfile.h"
#include "direct.h"
#include <strstream.h>
#include <string.h>

// The template parameter RecType must support the following
//	int Pack (BufferType &); pack record into buffer
//	int Unpack (BufferType &); unpack record from buffer

template <class RecType>
class HashedFile
{public:
	HashedFile(IOBuffer & buffer, int size = 4);
	~HashedFile();
	int Create(char * name);
	int Read(char * key, RecType & record);
	int Open(char * name);
	int Close();
	int Append(const RecType & record);
	void Print();
protected:
	Directory Direct;
	RecordFile<RecType> DataFile;
	char * FileName; // base file name for file

	int SetFileName(char * fileName, char *& dataFileName);
};

// template method bodies
template <class RecType>
HashedFile<RecType>::HashedFile(IOBuffer & buffer, int size = 4 )
	:DataFile(buffer),Direct(size)
{
}

template <class RecType>
HashedFile<RecType>::~HashedFile()
{
	Direct.~Directory();
}

template <class RecType>
int HashedFile<RecType>::Create(char * name)
{
	char * dataFileName;
	int result;
	result=SetFileName(name, dataFileName);
	int mode = ios::in|ios::out;
	result = DataFile.Create(dataFileName, mode);
	if(!result)
	{
		cout<<"error in data create"<< result<<endl;
		return -1;
	}
	result = Direct.Create(name);
	if(!result)
	{
		cout<<"error in dir create"<<endl;
		return -1;
	}


	return result;
}

template <class RecType>
int HashedFile<RecType>::Read(char * key, RecType & record)
{
	int addr;
	addr = Direct.Search(key);
	cout<<addr<<key<<endl;
	int result = DataFile.Read(record,addr);
	//this is failing & i have no idea why
	//the address is right according to jeffmake
	cout<<"DataFile Read result"<<result<<endl;
	return result;
}
template <class RecType>
int HashedFile<RecType>::Open(char * name)
{
	char * dataFileName;
	int result;
	result = SetFileName (name, dataFileName);
	result = Direct.Open(name);
	if(!result ) return -1;
	result = DataFile.Open(dataFileName,ios::in||ios::out);	
	if (!result) return -1;
        return 1;
}

template <class RecType>
int HashedFile<RecType>::Close()
{
	int result;
	result = Direct.Close();
	if(!result ) return -1;
	result = DataFile.Close();	
	if (!result) return -1;
	return result;
}

template <class RecType>
int HashedFile<RecType>::Append(const RecType & record)
{
	int ref;
	char * key = record.Key();
	ref = DataFile.Append(record);
	if (!ref) 
	{
		cout<<"error"<<endl;
		return -1;
	}
	int result = Direct.Insert(key,ref);
	return result;
}

template <class RecType>
void HashedFile<RecType>::Print()
{
	Direct.Print(cout);
}
template <class RecType>
int HashedFile<RecType>::SetFileName(char * fileName, char *& dataFileName)
// generate names for the data file and the index file
{
        if (FileName != 0) // object is already attached to a file
                return 0;
        // set FileName member
        FileName = strdup(fileName);
        // generate real file names
        ostrstream dataName, indexName;
        dataName << FileName <<".dat"<<ends;
        dataFileName = strdup(dataName . str());
        return 1;
}

