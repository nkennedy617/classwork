// jeffmake.cpp
#include "direct.h"
#include "hashfile.h"
#include "delim.h"
#include "recordng.h"
#include <iostream.h>

// make a hashed file from a recording file
int IndexRecordingFile (char * myfile, 
	HashedFile<Recording> & indexFile)
{
	Recording rec; int recaddr, result;
	DelimFieldBuffer Buffer; // create a buffer
	BufferFile RecFile(Buffer); 
	result = RecFile . Open (myfile,ios::in);
	if (!result)
	{
		cout << "Unable to open file "<<myfile<<endl;
		return 0;
	}
	while (1) // loop until the read fails
	{
		recaddr = RecFile . Read (); // read next record
		if (recaddr < 0) break;
		rec. Unpack (Buffer);
		indexFile . Append(rec);
	}
	indexFile.Print();
}


int main (int argv, char ** argc)
{// first argument is the file name for the data file
	int result;
	DelimFieldBuffer Buffer; // create a buffer
	HashedFile<Recording> IndFile (Buffer);
	result = IndFile . Create ("hashed");
	if (!result) 
	{
		cout<<"Unable to create indfile "<<result<<endl;
		cout << "Perhaps you need to delete the files." << endl;
		return 0;
	}	
	IndexRecordingFile ("recs.txt", IndFile);
	IndFile.Close();
}

