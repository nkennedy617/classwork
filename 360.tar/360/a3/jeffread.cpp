// jeffread.cpp
#include "direct.h"
#include "hashfile.h"
#include "delim.h"
#include "recordng.h"
#include <iostream.h>

int main (int argv, char ** argc)
{
        cout <<"Begin Test:"<<endl;
        cout <<flush;
        char key[12];
	Recording rec1;
	DelimFieldBuffer Buffer;
	HashedFile<Recording> IndFile(Buffer);

	int result = IndFile . Open ("hashed");

	if(!result)
	{
		cout<<"Unable to open hash file"<<result<<endl;
		return 0;
	}


	for(int i = 0; i<4; i++)
	{
		switch (i)
		{
			case 0:
				strcpy(key, "RCA2626");
				break;
			case 1:
				strcpy(key, "LON8767");
				break;
			case 2:
				strcpy(key, "ANG3795");
				break;
			case 3:
				strcpy(key, "URL9021");
				break;
		}


		int status = IndFile.Read(key, rec1);

		if(status == 1)
		{
			cout<<rec1<<endl;
		}
		else
		{
			cout<<"Key not found! Return Code is "<<status<<endl;
		}
	}
	IndFile.Close();
}

