#include <fstream.h>

#include <iomanip.h>
#include <string.h>
#include "iobuffer.h"
#include "fixfld.h"
#include "length.h"
#include "person.h"
#include "buffile.h"
#include "recfile.h"

Person Thomas, Woodrow, Andrew, Martin, Lyndon;

void InitPresidents()
{
	cout << "Five Presidents"<<endl;
	strcpy (Thomas.LastName, "Jefferson");
	strcpy (Thomas.FirstName, "Thomas");
	strcpy (Thomas.Address, "12 Hill St.");
	strcpy (Thomas.City, "Richmond");
	strcpy (Thomas.State, "VA");
	strcpy (Thomas.ZipCode, "11111");
	Thomas. Print (cout);
	strcpy (Woodrow.LastName, "Wilson");
	strcpy (Woodrow.FirstName, "Woodrow");
	strcpy (Woodrow.Address, "49 Einstein");
	strcpy (Woodrow.City, "Princeton");
	strcpy (Woodrow.State, "NJ");
	strcpy (Woodrow.ZipCode, "22222");
	Woodrow. Print (cout);
	strcpy (Andrew.LastName, "Jackson");
	strcpy (Andrew.FirstName, "Andrew");
	strcpy (Andrew.Address, "123 Maple");
	strcpy (Andrew.City, "Knoxville");
	strcpy (Andrew.State, "TN");
	strcpy (Andrew.ZipCode, "33333");
	Andrew. Print (cout);
	strcpy (Martin.LastName, "VanBuren");
	strcpy (Martin.FirstName, "Martin");
	strcpy (Martin.Address, "88 Brook Way");
	strcpy (Martin.City, "Yonkers");
	strcpy (Martin.State, "NY");
	strcpy (Martin.ZipCode, "44444");
	Martin . Print (cout);
	strcpy (Lyndon.LastName, "Johnson");
	strcpy (Lyndon.FirstName, "Lyndon");
	strcpy (Lyndon.Address, "662 Cattle Way");
	strcpy (Lyndon.City, "Dallas");
	strcpy (Lyndon.State, "TX");
	strcpy (Lyndon.ZipCode, "55555");
	Lyndon . Print (cout);
}

int main(int argc, char ** argv)
{
	Person person; 
	int result;

	InitPresidents();
	cout << "\nTesting LengthTextBuffer"<<endl;
	LengthFieldBuffer Buff;
	Person :: InitBuffer (Buff);

	RecordFile<Person> outfile(Buff);
	result = outfile . Create ("pres.txt",ios::out|ios::trunc);
	if (!result)
	{	cout << "you must delete file "<<endl
		<< "pres.txt" << endl ; exit(1);}
	outfile. Write (Thomas);
	outfile. Write (Woodrow);
	outfile. Write (Andrew);
	outfile. Write (Martin);
	outfile. Write (Lyndon);
	outfile. Close ();
	RecordFile<Person> TestIn (Buff);
	TestIn . Open ("pres.txt", ios::in);
	cout << "Which Record(1-5): ";
	int choice;
	cin >> choice;
	TestIn . Read (person, choice);
	person . Print (cout, "Here you are....");
}
