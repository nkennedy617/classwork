// jeffread.cpp
#include "secind.h"
#include "delim.h"
#include "buffile.h"
#include "recordng.h"
#include "secfile.h"
#include <iostream.h>

int main (int argv, char ** argc)
{
	cout <<"Begin Test:"<<endl;
	cout <<flush;
	char artist[12];
	int i = 0;
	Recording rec1;
	DelimFieldBuffer Buffer; // create a buffer
	cout <<"Next Sec stuff"<<endl;
	cout <<flush;
	SecIndexedFile<Recording> indFile (Buffer, 12, 15, 15);
	cout <<"here is first call "<<endl;
	cout <<flush;
	int result = indFile . Open ("indfile");
	if (!result) 
	{
		cout<<"Unable to open indfile "<<result<<endl;
		return 0;
	}	
indFile.Print();
	for (i = 0; i < 3; i++) {
		switch (i) {
			case 0:
			strcpy(artist, "Beethoven"); break;
			case 1:
			strcpy(artist, "Prokofiev"); break;
			case 2:
			strcpy(artist, "Corea"); break;
		};
		int num = indFile.HowManyOfKey(artist);
	cout <<"here is how many : "<< num << endl;
	cout <<flush;
		cout << num << " found for " << artist << endl;
		for (int j=0; j < num; j++) {
			indFile.Read(artist, j , rec1);
			cout << rec1 << endl;
		}
		cout << endl;
	}
	indFile.Close();
}

