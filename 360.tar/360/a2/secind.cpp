//textind.cc
#include "secind.h"
#include <iostream.h>
#include <string.h>

SecIndex:: SecIndex (int maxKeys)
	: NumKeys (0), Keys(0), Refs(0)
{Init (maxKeys);}

SecIndex :: ~SecIndex ()
{delete Keys; delete Refs;}

int SecIndex :: Insert (const char * key, const char * ref)
{
        int i=0;
        for (i = NumKeys-1; i >= 0; i--)
        {
                if (strcmp(key, Keys[i])>0) break; // insert into location
                Keys[i+1] = Keys[i];
                Refs[i+1] = Refs[i];
        }
        Keys[i+1] = strdup(key);
        Refs[i+1] = strdup(ref);
 
 
        NumKeys ++;
        return 1;

}

int SecIndex :: NumOfKeys (const char * key) const
{
	int total = 1;
	int index = Find (key);
	if (index < 0) return index;
	while ( !strcmp(Keys[++index],key) ) total++;
	return total;
}


char * SecIndex :: GetRef (const char *key, int offset)
{
	int index = Find(key);
	if (index < 0) return 0;
	if ( strcmp(key, Keys[index+offset]) ) return 0;
	return Refs[index+offset];
}



void SecIndex :: Print (ostream & stream) const
{
	stream << "Sec Index max keys "<<MaxKeys
			<<" num keys "<<NumKeys<<endl;
	for (int i = 0; i<NumKeys; i++)
		stream <<"\tKey["<<i<<"] "<<Keys[i]
			<<" Ref "<<Refs[i]<<endl;
}

int SecIndex :: Find (const char * key) const
{
	for (int i = 0; i < NumKeys; i++)
		if (strcmp(Keys[i], key)==0) return i;// key found
		else if (strcmp(Keys[i], key)>0) return -1;// not found
	return -1;// not found
}

int SecIndex :: Init (int maxKeys)
{
	if (maxKeys <= 0) 
	{
		MaxKeys = 0;
		return 0;
	}
	MaxKeys = maxKeys;
	Keys = new char *[maxKeys];
	Refs = new char *[maxKeys];
	return 1;
}

