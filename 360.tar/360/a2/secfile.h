// secfile.h
#include "recfile.h"
#include "sindbuff.h"
#include "indfile.h"
#include "secind.h"
#include <strstream.h>
#include <string.h>
// template class to support secondary indexes for files.
// Protected item DataFile implements data and primary index. 

// The template parameter RecType must support the following
//	int Pack (BufferType &); pack record into buffer
//	int Unpack (BufferType &); unpack record from buffer

template <class RecType>
class SecIndexedFile
{
public:
	// Read with 3 paramaters uses offset to read one record
	// when multiple records exist for a key. First record
	// is offset 0 (zero).
	int Read (RecType & record); // read next record
	int Read (char * key, int offset, RecType & record); // read by key

	// Returns number of secondary keys exist that match 
	// parameter key.
	int HowManyOfKey (char * key);

	// add record to sec. index and file
	int Append (const RecType & record);

	// Update not implemented.
	int Update (char * oldKey, const RecType & record);

	int Create (char * name, int mode=ios::in|ios::out);
	int Open (char * name, int mode=ios::in|ios::out);
	int Close ();

	// Prints secondary index.
	void Print() { Index.Print(cout); }
	SecIndexedFile (IOBuffer & buffer, 
		int keySize, int refSize, int maxKeys = 100); 
	~SecIndexedFile (); // close and delete
protected:
	SecIndex Index;
	BufferFile IndexFile;       // file for sec. index
	SecIndexBuffer IndexBuffer; // buffer for sec. index 
	TextIndexedFile<RecType> DataFile;
	char * FileName; // base file name for file
	int SetFileName(char * fileName, char *& indexFileName);
};

// template method bodies

template <class RecType>
int SecIndexedFile<RecType>::HowManyOfKey(char *key)
{
//returns the number of times a key occurs
	int numkeys =0;
	numkeys = Index.NumOfKeys(key);
	return numkeys;
}


template <class RecType>
int SecIndexedFile<RecType>::Read (RecType & record)
{	return result = DataFile . Read (record, -1);}

template <class RecType>
int SecIndexedFile<RecType>::Read (char * key, int offset, RecType & record)
{
//this should find the first occurrence of the key, add it to the offset
//then read that record.
	char * tempkey= Index.GetRef(key, offset);
	int result;
	return result = DataFile . Read (tempkey, record);
}

template <class RecType>
int SecIndexedFile<RecType>::Append (const RecType & record)
{
	 char * key = record.Key();
	 int thing = 0;
	 int result;
         char * tempkey= record.SecKey();
        int ref = DataFile . Append(record);
        result =  Index.Insert (tempkey, key);
        return ref;
}

template <class RecType>
int SecIndexedFile<RecType>::Update 
	(char * oldKey, const RecType & record)
// DO NOT TRY TO IMPLEMENT THIS.
{	return -1;}


template <class RecType>
int SecIndexedFile<RecType>::SetFileName(char * fileName, char *& indexFileName)
{
	if (FileName != 0) // object is already attached to a file
		return 0;
	// set FileName member
	FileName = strdup(fileName);
	// generate real file names
	ostrstream indexName;
	indexName<< FileName<<".in2"<<ends;
	indexFileName = strdup(indexName . str());
	return 1;
}

template <class RecType>
int SecIndexedFile<RecType>::Create (char * fileName, int mode)
{
//should call setfile to make the name
//then should create the file
	char * secindexfile;
	int result ;
	DataFile.Create(fileName, mode);
	result = SetFileName(fileName, secindexfile);
	IndexFile. Create (secindexfile, mode);
        if (!result)
        {
                DataFile . Close(); // close the data file
                FileName = 0; // remove connection
                return 0;
        }
	return 1;
}


template <class RecType>
int SecIndexedFile<RecType>::Open (char * fileName, int mode)
// open data and index file and read index file
{
	char * secindexfile;
	int result = SetFileName(fileName, secindexfile);
	//opens the primary index file and the datafile
	result = DataFile.Open(fileName, mode);
        if (!result)
        {
                DataFile . Close(); // close the data file
                FileName = 0; // remove connection
		cout <<"something wrong in data open" <<flush<<endl;
                return 0;
        }
	//open the secondary index file
	result= IndexFile.Open(secindexfile,  ios::out);
        if (!result)
        {
                IndexFile . Close(); // close the data file
                FileName = 0; // remove connection
		cout<<"something wrong on index open"<<flush<<endl;
                return 0;
        }
        // read index into memory
        result = IndexFile . Read ();
        if (result != -1)
        {
                result = IndexBuffer . Unpack (Index);
                if (result != -1) return 1;
        }
        // read or unpack failed!
        DataFile.Close();
        IndexFile.Close();
        FileName = 0;
        return 0;

}

template <class RecType>
int SecIndexedFile<RecType>::Close ()
{	
	//does the house keeping with the buffer, then writes out, closes
	int result;	
	if (!FileName) return 0; // already closed!
	result = DataFile.Close();
	IndexFile . Rewind ();
        IndexBuffer.Pack (Index);
        result= IndexFile . Write ();
	result = IndexFile.Close();
        if (!result)
        {
                IndexFile . Close(); // close the data file
                FileName = 0; // remove connection
		cout<<"something wrong on index close"<<endl;
                return 0;
        }
	return 1;
}

template <class RecType>
SecIndexedFile<RecType>::SecIndexedFile (IOBuffer & buffer,
		int keySize, int refSize, int maxKeys)
	:DataFile(buffer, keySize, maxKeys), Index (maxKeys), 
	IndexFile(IndexBuffer),
        IndexBuffer(keySize, refSize, maxKeys)
{
	FileName = 0;
}

template <class RecType>
SecIndexedFile<RecType>::~SecIndexedFile ()
{	Close(); 
}

