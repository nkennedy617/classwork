// secind.h

#ifndef SECIND_H 
#define SECIND_H
#include "iostream.h"

class SecIndex
{
  public:
	SecIndex (int maxKeys = 100);
	~SecIndex ();
	int Insert (const char * key, const char * ref);

	// return number of keys that match.
	int NumOfKeys (const char * key) const;

	// return pointer to primary key that is the
	// reference for the item with secondary key "key" and 
	// offset "offset". First item is offset 0 (zero).
	char * GetRef ( const char * key, int offset);
	void Print (ostream &) const;
  protected:
	int MaxKeys;
	int NumKeys;
	char * * Keys;
	char * * Refs;
	int Find (const char * key) const;
	int Init (int maxKeys);
friend class SecIndexBuffer;
};

#endif

