//tindbuff.h
#ifndef SINDBUFF_H
#define SINDBUFF_H

#include "secind.h"
#include "fixfld.h"

// class SecIndexBuffer supports reading and writing index records from
//	class SecIndex
// each record is consistent in its maximum size
class SecIndexBuffer: public FixedFieldBuffer
{public:
	SecIndexBuffer(int keySize, int refSize, int maxKeys = 100, 
		int extraFields = 0, int extraSize=0);
	// extraSize is included to allow derived classes to extend
	// the buffer with extra fields. 
	// Required because the buffer size is exact.
	int Pack (const SecIndex &);
	int Unpack (SecIndex &);
	void Print (ostream &) const;
protected:
	int MaxKeys;
	int KeySize;
	int RefSize;
	char * Dummy; // space for dummy in pack and unpack
};

#endif
