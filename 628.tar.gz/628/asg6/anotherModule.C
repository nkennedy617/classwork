#include <iostream.h>
#include "someModule.h"
int main () {
  someModule* s;                       
  s = new someModule ();              
  cout << s->getMsg() << endl;
  return (0);
}                                        

