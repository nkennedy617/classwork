public class sum {
int Result;
 public static int square(int t) throws MyFirstException2 {
   try {
     if(t*t+Result>2147483647)
	throw new MyFirstException2();
     Result=t*t+Result;
     return Result;
   } catch (MyFirstException2 m) {
 	System.out.print("Error! Number too big");
      	exit(-1);
   }
}
 public static int read (InputStream s) throws MyFirstException1 {
       int myint;
        myint=s.readInt();
      try {
        if(myint<-100)
       	   throw new MyFirstException1();
	if(myint>100)
       	   throw new MyFirstException1();

	return(myint);
        } catch (MyFirstException1 m) {
    	    if (myint>100){
              System.out.print( " Invalid # won't count!");
	      return;
           }
          }
 
 }
public static void main(String[] argv) {
 InputStream s = new FileInputStream("./integers");
 int tmp;
  try {
   	if(s = EOF)
           throw new MyFirstException();
    
	tmp=read(s);
	Result=square(tmp);
   }
   catch (MyFirstException m) {
	System.out.print("Result" + Result);
        s.close();
   }      
  }

}
