class Base {
  protected int i;
  public Base () {
    System.out.println ("Constructor for Base called");
    i = -1;
  }

  public void print () {
    System.out.println ("The value of i in Base is " + i);
  }

  public void assign (int q) {
    i = q;
  }
  
}

class Derived extends Base {
  protected  int j;
  public Derived () {
    System.out.println ("Constructor for Derived called");
    j = -2;
  }

  public void print () {
    System.out.println ("The value of i,j in Derived is " + i + "," + j);
  }

  public void assign (int q) {
    j = q;
  }

}

class Example {
  public static void UnderstandStructors () {
    Base b = new Base ();
    Derived d = new Derived ();

    Base bp;
    Derived dp;
  
    bp = new Base ();
    dp = new Derived ();
  }

  public static void UnderstandTypeBinding () {

    Base b = new Base();
    b.print();

    Derived d = new Derived ();
    d.print();

    Base bp = new Base ();
    bp.print ();
    bp.assign (10);
    bp.print ();


    Derived dp = new Derived ();
    bp = dp;
    bp.print ();
    bp.assign (10);
    bp.print ();
    dp.assign (100);
    bp.print ();

    b = d;
    b.print ();  
    b.assign (50);  
    b.print ();  
  
  }



  public static void  main (String argv[]) {

    UnderstandStructors ();
    UnderstandTypeBinding ();
}

}
