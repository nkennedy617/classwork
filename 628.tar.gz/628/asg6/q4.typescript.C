Script started on Wed 04 Apr 2001 09:10:01 PM EDT
matrix[21] CC -v Example.C
### CC: Note: LM_LICENSE_FILE = (null)
### CC: Note: NLSPATH = /opt/SUNWspro/bin/../SC5.0/bin/../lib/locale/%L/LC_MESSAGES/%N.cat:/opt/SUNWspro/bin/../SC5.0/bin/../../lib/locale/%L/LC_MESSAGES/%N.cat
/opt/SUNWspro/bin/../SC5.0/bin/ccfe -y-o -yExample.o -y-fbe -y/opt/SUNWspro/bin/../SC5.0/bin/fbe -y-xarch=v7 -y-verbose -O0 -ptf /tmp/13665%1.%2 -ptx /opt/SUNWspro/bin/../SC5.0/bin/CC -ptk "-v  -xs " -D__SunOS_5_7 -D__SUNPRO_CC=0x500 -Dunix -Dsun -Dsparc -D__sparc -D__unix -D__sun -D__BUILTIN_VA_ARG_INCR -D__SVR4 -D__SUNPRO_CC_COMPAT=5 -y-s -I/opt/SUNWspro/SC5.0/include/CC -I/opt/SUNWspro/SC5.0/include/CC/rw7 -I/opt/SUNWspro/SC5.0/include/cc Example.C -s /tmp/ccfe.13665.0.s
/opt/SUNWspro/bin/../SC5.0/bin/fbe -xarch=v7 -s -o Example.o /tmp/yabeAAA2XaqSA 
rm /tmp/yabeAAA2XaqSA
/opt/SUNWspro/bin/../SC5.0/bin/CClink -ptk "-v  -xs  -xildoff " -ptx /opt/SUNWspro/bin/../SC5.0/bin/CC Example.o -o a.out
### CC: Note: LM_LICENSE_FILE = (null)
### CC: Note: NLSPATH = /opt/SUNWspro/bin/../SC5.0/bin/../lib/locale/%L/LC_MESSAGES/%N.cat:/opt/SUNWspro/bin/../SC5.0/bin/../../lib/locale/%L/LC_MESSAGES/%N.cat:/opt/SUNWspro/bin/../SC5.0/bin/../lib/locale/%L/LC_MESSAGES/%N.cat:/opt/SUNWspro/bin/../SC5.0/bin/../../lib/locale/%L/LC_MESSAGES/%N.cat
### CC: Note: LD_LIBRARY_PATH = /usr/ccs/lib:/usr/lib:/usr/openwin/lib:/usr/local/X11/lib:/usr/local/X11/lib:/local/app/oracle/product/8.0.4/lib
### CC: Note: LD_RUN_PATH     = (null)
### CC: Note: LD_OPTIONS = (null)
/usr/ccs/bin/ld -u __1cH__CimplKcplus_init6F_v_ -R/opt/SUNWspro/lib/rw7:/opt/SUNWspro/lib:/usr/ccs/lib:/usr/lib:/opt/SUNWspro/lib -o a.out /opt/SUNWspro/SC5.0/lib/crti.o /opt/SUNWspro/SC5.0/lib/crt1.o /opt/SUNWspro/SC5.0/lib/values-xa.o -Y P,/opt/SUNWspro/lib/rw7:/opt/SUNWspro/lib:/opt/SUNWspro/SC5.0/lib/rw7:/opt/SUNWspro/SC5.0/lib:/usr/ccs/lib:/usr/lib Example.o -lCstd -lCrun -lC_mtstubs -lm -lw -lcx -lc /opt/SUNWspro/SC5.0/lib/crtn.o >&/tmp/ld.13669.0.err
/opt/SUNWspro/bin/../SC5.0/bin/c++filt -stderr </tmp/ld.13669.0.err
rm /tmp/ld.13669.0.err
rm Example.o
rm /tmp/ccfe.13665.0.s
matrix[22] a.out
Constructor for Base called
Constructor for Base called
Constructor for Derived called
Constructor for Base called
Constructor for Base called
Constructor for Derived called
Destructor for Derived called
Destructor for Base called
Destructor for Derived called
Destructor for Base called
Destructor for Base called
Constructor for Base called
The value of i in Base is -1
Constructor for Base called
Constructor for Derived called
The value of i,j in Derived is -1,-2
The value of i in Base is -1
The value of i in Base is 10
The value of i,j in Derived is -1,-2
The value of i,j in Derived is 10,-2
The value of i,j in Derived is 10,100
The value of i in Base is 10
The value of i in Base is 50
Destructor for Derived called
Destructor for Base called
Destructor for Base called
matrix[23] exit
exit

script done on Wed 04 Apr 2001 09:10:32 PM EDT
