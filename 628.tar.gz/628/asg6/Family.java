import java.io.*;
class Family {

  public static void main (String argv[]) 
     throws IOException, ClassNotFoundException { 

    Person p1;
    p1  = new Person ("James");
    Person p2 = new Person ("Ken");
    Person p3 = new Person ("Arnold");
    Person p4 = new Person ("Guy");
    Person p5 = new Person ("Kim");
    Person p6 = new Person ("Dorothy");
    Person p7 = new Person ("Martha");

    p1.setParents (p5, p2);
    p2.setParents (p6, p3);
    p7.setParents (p6, p3);

    System.out.println (p1);
    System.out.println (p2);
    System.out.println (p7);

    FileOutputStream fOut = new FileOutputStream ("tmp");
    ObjectOutputStream outPerson  =  new  ObjectOutputStream (fOut);
    outPerson.writeObject(p1);
    outPerson.writeObject(p2);
    outPerson.writeObject(p7);
    outPerson.close();

    FileInputStream fIn = new FileInputStream("tmp");
    ObjectInputStream inPerson = new ObjectInputStream (fIn);
    Person r1 = (Person)inPerson.readObject();
    System.out.println (r1);
    Person r2 = (Person)inPerson.readObject();
    System.out.println (r2);
    Person r3 = (Person)inPerson.readObject();
    System.out.println (r3);
    inPerson.close();
   
    Person p8 = new Person ("Jill");
    r2.setParents (p8, p6);
    fOut = new FileOutputStream ("tmp");
    outPerson  =  new  ObjectOutputStream (fOut);
    outPerson.writeObject(r1);
    outPerson.writeObject(r2);
    outPerson.writeObject(r3);
    outPerson.close();

    fIn = new FileInputStream("tmp");
    inPerson = new ObjectInputStream (fIn);
    r1 = (Person)inPerson.readObject();
    System.out.println (r1);
    r2 = (Person)inPerson.readObject();
    System.out.println (r2);
    r3 = (Person)inPerson.readObject();
    System.out.println (r3);
    inPerson.close();
   

  }

}
