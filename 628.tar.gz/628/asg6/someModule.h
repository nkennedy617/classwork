class someModule {                       
 private:
  char* msg;
 public:
  someModule () {
    msg = "bar";           
  }

  char* getMsg () {             
    return (msg);                   
  }
};
                                      
