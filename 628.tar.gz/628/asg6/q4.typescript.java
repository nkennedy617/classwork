Script started on Wed 04 Apr 2001 09:11:22 PM EDT
matrix[21] javac Example.java 
matrix[22] java Example.[K
Constructor for Base called
Constructor for Base called
Constructor for Derived called
Constructor for Base called
Constructor for Base called
Constructor for Derived called
Constructor for Base called
The value of i in Base is -1
Constructor for Base called
Constructor for Derived called
The value of i,j in Derived is -1,-2
Constructor for Base called
The value of i in Base is -1
The value of i in Base is 10
Constructor for Base called
Constructor for Derived called
The value of i,j in Derived is -1,-2
The value of i,j in Derived is -1,10
The value of i,j in Derived is -1,100
The value of i,j in Derived is -1,-2
The value of i,j in Derived is -1,50
matrix[23] exit
exit

script done on Wed 04 Apr 2001 09:11:54 PM EDT
