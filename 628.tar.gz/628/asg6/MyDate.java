import java.io.*;
class MyDate implements Serializable {
  public int month;
  public int day;
  public int year;

  public MyDate (int month, int day, int year) extends Family
 {
    this.month = month;
    this.day  = day;
    this.year  = year;
  }

  //public void setParents (Person mother, Person father) {
    //this.mother = mother;
    //this.father = father;
  //}

  

}
