import java.io.*;
class Person implements Serializable {
  public String name;
  public Person mother;
  public Person father;
  public MyDate Bday;
   public int weight;

  public Person (String name) {
    this.name = name;
    this.mother  = null;
    this.father  = null;
    this.weight = 0;
    MyDate(0,0,0);
  }

  public void setWeight (int myweight ) {
    this.weight = weight;
  }
  public void setParents (Person mother, Person father) {
    this.mother = mother;
    this.father = father;
  }

  public String toString () {
    String rep = null;
    if ( (mother.name != null)  & (father.name != null) )
       rep = new String (name + ": Parents=> " + mother.name + " & " + father.name);
    if ( (mother.name == null)  & (father.name != null) )
       rep = new String (name + ": Parents=> " + father.name);
    if ( (mother.name != null)  & (father.name == null) )
       rep = new String (name + ": Parents=> " + father.mother);
    return (rep);
  }
    
  

}
