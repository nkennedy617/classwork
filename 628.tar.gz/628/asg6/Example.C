#include <iostream.h>
class Base {
protected:
  int i;
public:
  Base () {
    cout << "Constructor for Base called" << endl;
    i = -1;
  };

  ~Base () {
    cout << "Destructor for Base called" << endl;
  };

  virtual void print () {
    cout << "The value of i in Base is " << i << endl;
  };

  void assign (int q) {
    i = q;
  };
};

class Derived : public Base {
protected:
  int j;
public:
  Derived () {
    cout << "Constructor for Derived called" << endl;
    j = -2;
  };

  ~Derived () {
    cout << "Destructor for Derived called" << endl;
  };

  virtual void print () {
    cout << "The value of i,j in Derived is " << i << "," << j << endl;
  };

  void assign (int q) {
    j = q;
  };

};

void UnderstandStructors () {
  Base b;
  Derived d;

  Base* bp;
  Derived* dp;
  
  bp = new Base ();
  dp = new Derived ();

  delete dp;
}

void UnderstandTypeBinding () {
  Base b;
  b.print();

  Derived d;
  d.print();

  Base* bp;
  bp = &b;
  bp->print ();
  bp->assign (10);
  bp->print ();

  bp = &d;
  bp->print ();
  bp->assign (10);
  bp->print ();
  d.assign (100);
  bp->print ();

  b = d;
  b.print ();  
  b.assign (50);  
  b.print ();  
}

int main () {

  UnderstandStructors ();
  UnderstandTypeBinding ();

  return (0);
};
