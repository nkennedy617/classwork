import java.lang.*;
class anotherModule {                    
   public static                         
       void main (String argv[]) {       
     someModule s;                       
     s = new someModule ();              
     System.out.println (s.getMsg());    
   }                                     
}                                        
