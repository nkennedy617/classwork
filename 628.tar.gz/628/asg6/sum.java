import java.io.*;
         import java.util.Vector;
public class sum {
        int siz=1;
 Vector victor;
             private static final int size = 10;
 public static void ListOfNumbers(){
victor = new Vector();
  		Vector nell;
                nell = new Vector(10);
                 //victor = new Vector(size);
                 for (int i = 0; i < size; i++) {
                     nell.addElement(new Integer(i));}
victor=nell;             
    }
public void writeList() {
              PrintWriter out = new PrintWriter(new FileWriter("OutFile.txt"));
                 for (int i = 0; i < size; i++)
                     out.println("Value at: " + i + " = " + nell.elementAt(i));
                 out.close();
             }
public static void main(String[] argv) {
        
 	System.out.println("hello there");
  }

}
