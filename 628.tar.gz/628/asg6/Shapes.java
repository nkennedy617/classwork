abstract class Shape {
  public abstract double area( );
  public abstract double circumference( );
}

class Circle extends Shape {
  protected double r;
  Circle( ) {r = 1.0;}
  Circle(double r) {this.r = r;}
  static final double PI = 3.14159265;
  // area of a circle is PI * square (radius)
  public double area( ) {return PI * r * r;}

  // circumference of a circle is diameter times PI
  public double circumference( ) {return PI * 2 * r;}
}

class Triangle extends Shape {
  protected double b, h;
  Triangle( ) {this(0.0, 0.0);}
  Triangle(double b, double h) {this.b = b; this.h = h;}
  // area of a circle is PI * square (radius)
  public double area( ) {return .5 * b * h;}

  // circumference of a circle is diameter times PI
  public double circumference( ) {return  2 * b * h;}
}
class Rectangle extends Shape {
  protected double w, h;
  Rectangle( ) {this(0.0, 0.0);}
  Rectangle(double w, double h) {
    this.w = w;
    this.h = h;
  }

  // area of a rectangle is height times width
  public double area( ) {return w * h;}
  // circumference of a rectangle is the sum of its sides
  public double circumference( ) {return w + w + h + h;}
}

class Shapes {
  public static void computeArea (Shape shapes[]) {
    double total_area = 0;
    for (int i = 0; i < shapes.length; i++)
      total_area += shapes[i].area( );
    System.out.println ("The total area is: " + total_area);

  }
  public static void computeCircumference (Shape shapes[]) {
    double total_circumference = 0;
    for (int i = 0; i < shapes.length; i++)
      total_circumference += shapes[i].circumference( );
    System.out.println ("The total circumference is: " + total_circumference);

  }

  public static void main (String argv[]) {
    Shape[ ] bunchOfShapes = new Shape[4];
    bunchOfShapes[0] = new Circle(2.0);
    bunchOfShapes[1] = new Rectangle(1.0, 3.0);
    bunchOfShapes[2] = new Rectangle(4.0, 2.0);
    bunchOfShapes[3] = new Rectangle(4.0, 2.0);

    computeArea (bunchOfShapes);
    computeCircumference (bunchOfShapes);
  }

}
                
