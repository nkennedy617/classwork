class someModule {                       
   private String msg = "bardd";           
   public String getMsg () {             
         return (msg);                   
   }                                     
}                                        
