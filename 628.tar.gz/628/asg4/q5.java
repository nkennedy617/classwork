class ShortCircuit {
  static int someNum =0;
  public static boolean divisibleByThree (int i) {
    if((i % 3) ==0) {
      someNum = i + someNum;
      return true;
    }
    else 
      return false;
  }
  public static boolean divisibleByFive (int i) {
    if((i % 5) == 0) 
     return true;
    else
     return false;
  }
  public static void main(String[] argv) {
    int count =0;
    for (int num=0; num < 5000; num++)
     //short circuit
     if (divisibleByThree(num) | divisibleByFive(num))
       count = count + 1;
    System.out.println ("COUNT= " + count);
    System.out.println ("Some number= " + someNum);
  }
}
