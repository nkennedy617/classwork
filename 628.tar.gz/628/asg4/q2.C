#include <iostream.h>
int returnInt () {
  static int counter =0;
  counter = counter + 1;
//cout <<endl <<counter <<endl;
  return (counter);}
void printArray (int* theArray) {
  int i;
  for (i=0;i<10;i++)
   cout << theArray[i] << " ";
  cout << endl; }
main () {
  int intArray[10];
   int i;
  for (i=0;i<10;i++)
   intArray[i]= 2*(i+1);
  intArray[7] += 3;
   intArray[2] +=intArray[2] +1;
  intArray[6]++;
  intArray[2] +=intArray[9] +1;
  printArray(intArray);
  intArray[returnInt()] = intArray[returnInt()] + 1;
  printArray(intArray);
  intArray[2] = intArray[1] +1;
  printArray(intArray);
  intArray[returnInt()] += 1;
  printArray(intArray);
  intArray[returnInt()]++;
  printArray(intArray);
}
  
