class q2 {
 static int counter = 0;
 public static int returnInt() {
   counter = counter + 1;
   return (counter);
 }
 public static void printArray(int theArray[]) {
   int i;
  for(i=0;i<10;i++){
    System.out.print(theArray[i]);
    System.out.print("  ");
  }
  System.out.println();
  }
  public static void main (String[] argv) {
   int intArray[] = new int[10];
  int i;
  for(i=0;i<10;i++){
   intArray[i]=2*(i+1);
  }
  intArray[7] += 3;
  intArray[2] += intArray[2] + 1;
  intArray[6]++;
  intArray[2] += intArray[9] + 1;
  printArray (intArray);
  intArray[returnInt()] = intArray[returnInt()] + 1;
  printArray (intArray);
  intArray[2] += intArray[1] + 1;
  printArray (intArray);
  intArray[returnInt()] += 1;
  printArray (intArray);
  intArray[returnInt()]++;
  printArray (intArray);
 }
}
