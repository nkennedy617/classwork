#include <iostream.h>
class Weight {
public:
  int lbs;
  int oz;
};
class Person {
public:
  int taxCode;
  int age;
  Weight weight;
  void print (char* msg) {
    cout << "Person:" << msg << endl
         << "  TCN: " << taxCode <<  endl
         << "  Age: " <<  age << endl 
         << "  Weight: " << weight.lbs <<  "lbs, " 
                        << weight.oz <<  "oz." << endl << endl;};
};

main () {
  Person p1;
  Person p2;
  Person& p3 = p1;
  Weight w1;
  Weight w2;

  w1.lbs = 180;
  w1.oz  = 12; 
  w2.lbs = 110;
  w2.oz  = 1; 
  p1.age = 34;
  p1.taxCode = 12345;  
  p1.weight = w1;
  p2.age = 21;
  p2.taxCode = 15432;  
  p2.weight = w2;
  p1.print("p1");
  p2.print("p2");
  p3.print("p3");
  p1 = p2;
  p1.print("p1");
  p2.print("p2");
  p3.print("p3");
  p1.age = 52;
  w2.lbs = 115;
  w2.oz =   15;
  p1.print("p1");
  p2.print("p2");
  p3.print("p3");
}
