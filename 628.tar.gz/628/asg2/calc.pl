#!/usr/local/bin/perl

open(CAL, "<tokens");
$i=0;
while(<CAL>) {
 $line=$_;
 $who=chop($line);
 @aa=split(' ', $line);
 foreach $item (@aa) {
 if(($item eq '+') | ($item eq '-') | ($item eq  '*') | ($item eq '/')) {
	push(@identifier, ' ');
 }
 elsif($item eq '=') {
	push(@identifier, "\n");
}
 else {
	push(@identifier, $item);
 }
 	$my= pop(@identifier);
	print $my ;
 }
  
}
close(CAL);
