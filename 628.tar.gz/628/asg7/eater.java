public class eater extends Thread {
public void run() {
 eat_letter();
 try{
    Thread.sleep(100);
 } catch (InterruptedException e) {
   System.out.println(e.getMessage());
 } 
}
}

