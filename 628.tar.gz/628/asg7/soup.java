import java.lang.*;
class soup {
public char letter1='@';
public char letter2='@';
public char letter3='@';
public char letter4='@';
public char letter5='@';
public char letter6='@';

public void eat_letter() {
 if(letter1!='@') {
  letter2=letter3;
  letter3=letter4;
  letter5=letter6;
  letter6='@';
 }
 }
public void make_letter() {
 if(letter1=='@') {
  letter1='n';
 }
 else if(letter2=='@'){
  letter2='e';
  }
 else if(letter3=='@'){
  letter3='l';
  }
 else if(letter4=='@'){
  letter4='l';
  }
 else if(letter5=='@'){
  letter5='j';
  }
 else{
  letter6='b';
 }
 }
}
 public void main(){
  mysoup=new soup;

  kermit=new chef;
  piggy=new eater;

kermit(soup);
piggy(soup);  
 }
