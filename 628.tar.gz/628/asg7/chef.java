public class chef extends Thread {
public void run() {
  soup.make_letter();
  try{
     Thread.sleep(100);
  } catch (InterruptedException e) {
    System.out.println(e.getMessage());
  }
  soup.make_letter();
}
}

