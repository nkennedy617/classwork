#include <stdio.h>

main(){
int i, j;
int oldi;
i=4;
j=5;
while (i>0) {
  oldi=i;
  i =j % i;
  j = oldi;
  printf ("%d  %d\n", i, j);
}
 
}
