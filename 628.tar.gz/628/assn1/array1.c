/* *************************************************************** */
/* Nell Beatty							   */
/* Computer Science 628						   */
/* Assignment Number  1						   */
/* This program will violate the bounds of the array		   */
/* There will be an attempt made to do run-time semanatic checks   */
/* *************************************************************** */

#include <stdio.h>


main(){
int myarray[5];



/* array assignment */
myarray[1]=2; 
myarray[2]=3; 
myarray[3]=4; 
myarray[4]=5;

/* the violation of the array bounds */


myarray[1]= myarray[4] * myarray[5];
printf ("The result is %d\n", myarray[1]);
}
