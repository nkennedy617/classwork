#!/usr/local/bin/perl

$myarray[1]=2;
$myarray[2]=3;
$myarray[3]=4;
$myarray[4]=5;
$item=5;
$myarray[1]= $myarray[4] * $myarray[$item];
printf ("The result is %d\n", $myarray[1]);

