#define R 1000
#define C 1010
#include <iostream.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <time.h>
int main () {
	time_t currentTime;
       // initialize random number generator
       int someNum;
       cout << "Enter a number: ";
       cin >> someNum;
       srandom (someNum); 
      
       int matrix[R][C];
       for (int i = 0; i < R; i++)
         for (int j = 0; j < C; j++)
           matrix[i][j] = random ();

      time(&currentTime);
      cout <<ctime(&currentTime)<<endl;
       
       int count = 0; // counts even numbers
       for (int j = 0; j < C; j++)
         for (int i = 0; i < R; i++)
           if (matrix[i][j] %2 == 0)
             count = count + 1;

      time(&currentTime);
      cout <<ctime(&currentTime)<<endl;

       cout << "EVEN NUMBERS: " << count << " out of " << R*C << endl;

}
