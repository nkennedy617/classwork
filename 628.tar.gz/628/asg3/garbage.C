#include <iostream.h>
int* allocateInt () {
  int *i;
  i = new int;
  *i = 10;
  return (i);
}

int* returnStatic () {
  static int i = 20;
  i = i + 1;
  return (&i);
}

int* returnMystery () {
  int i = 20;
  i = i + 1;
  return (&i);
}

void buildStack (int *i) {
  int j = 200;
  int k = 100;
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;
  cout << "L-Value: " << (unsigned int) &j << endl;
  cout << "L-Value: " << (unsigned int) &k << endl;

}


main () {

  int* i;
  i = allocateInt ();
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;
  i = allocateInt ();
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;

  i = returnStatic ();
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;
  i = returnStatic ();
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;
  
  i = returnMystery ();
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;
  i = returnMystery ();
  cout << "L-Value: " << (unsigned int) &i << " R-Value: " << (unsigned int) i << " Deref: " << *i << endl;

  buildStack (i);
}

