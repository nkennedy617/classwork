#include <map>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

typedef map<string, string> Table;

int main(int argv, char**argc)   {
    if(argv == 1)
	exit(1);
    ifstream infike(argc[1]);
    string temp;
    Table FGtable;

    while(getline(infike, temp))   {
	int tmp = temp.find(' ');
	FGtable[temp.substr(tmp + 1, temp.length()-tmp)] = temp.substr(0, tmp);
    }
    Table::iterator it = FGtable.begin();
    for(it; it != FGtable.end(); ++it)
	cout << "<"<<it->first << "> : <" << it->second << ">" <<endl;
}
