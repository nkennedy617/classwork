#!/usr/local/bin/perl
if (open(FILE, "+Grammar.Spring.2003.txt"))  {
	$firstpiece = "";
	$myline = "";
	if(open(OUT, ">RevisedGrammar.txt")){
	}
   while(<FILE>)    {
	$line = <FILE>;
		print OUT $line;
	$firstchar = substr($line, 0,1);
	if($firstchar ne '$'){
		
		if($firstchar eq ' ') {
	$myline = "";
			#print OUT "need to take space\n";
			#@parts = split ' ', $line;
			#print $line . "\n";
				#$myline = $firstpiece;
			#foreach $piece (@parts){
				#print "Firstchar". $piece . "\n";
				#$myline = $myline . " " . $piece;
			#}
			#print $myline;
		}
		else
		{
			print "need to do other stuff\n";	
			@parts = split ' ', $line;
			   $firstpiece = $parts[0];
				print "Part[0]" . $parts[0]."\n";
				print "Firstpiece" . $firstpiece."\n";
			foreach $piece (@parts){
				#print $piece . "\n";
			}
		}	
	}
   }
   #close files
 close(FILE);
 close(OUT);
}
 
	
