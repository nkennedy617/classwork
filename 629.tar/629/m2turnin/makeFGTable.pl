#!/usr/bin/perl
# This script takes in the output from the grammar analyzer program
# It then parses the file into item value1 value2
# It is run prior to the Parser, creating the static files used there
if (open(FILE, "+Grammar.Spring.2003.txt.out"))  {
   $line = <FILE>;
   if($line eq "\n"){
   }
   else {
	@fields = split /\w/, $line;
   }
   while(($line eq "\n")|| ($fields[0] ne "Precedence"))   {
	$line = <FILE>;
	if($line ne "\n"){
	@fields = split ' ', $line;
	if($fields[0] eq "Precedence"){
	break;
	}
	}

   }
   print "out of while\n";
	$line = <FILE>;
   if($line ne "\n") {
	@fields= split ' ', $line;
   }
   open(OUT, ">FGTable");
   while($fields[0] ne "Analysis") {
   if($line ne "\n") {
	$myline="";
	foreach $piece (@fields){
		#print OUT $piece;
		if($myline ne ""){
		print $piece;
		print $myline;
		$myline = $myline . " " . $piece;
		}
		else {
		$myline = $piece;
		}
		#print OUT " ";
	}
	print OUT $myline;
	print OUT "\n";
   }
	$line = <FILE>;
   if($line ne "\n") {
	@fields= split ' ', $line;
	if(($fields[0] eq "Symbol")&& ($fields[1] eq "F") && ($fields[2] eq "G")){
	$line = <FILE>;
   if($line ne "\n") {
	@fields= split ' ', $line;
}
        }
   }

   }

 close(OUT);
   #close files
 close(FILE);
 close(OUT);
}


