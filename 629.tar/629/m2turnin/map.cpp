#include <map>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

#define F	0
#define G	1

struct tableStruct   {
    int x[2];
    int &operator[](int i) {return x[i];}
};
typedef map<string, tableStruct> Table;
bool checkMap(string token, Table &tmpT);

int main(int argv, char**argc)   {
    if(argv == 1)
	exit(1);
    ifstream infike(argc[1]);
    string temp;
    Table FGtable;

    while(getline(infike, temp))   {
	tableStruct tmp;
	int sp1 = temp.find(' ') + 1;
	int sp2 = temp.find_last_of(' ') + 1;
	tmp[F] = atoi(temp.substr(sp1, sp2 - sp1 - 1).c_str());
	tmp[G] = atoi(temp.substr(sp2, temp.length() - sp2).c_str());
	FGtable[temp.substr(0, temp.find(' '))] = tmp;	
    }
    Table::iterator it;
    for(it = FGtable.begin(); it != FGtable.end(); ++it)   {
	if(it->first == "")
	    continue;
	cout<<it->first <<": "<< it->second[F]<<" : "<<it->second[G] << endl;
    }
    if(checkMap("test", FGtable))
	cout << "SHIT!: " << endl;
    else cout << "YEHA!" << endl;
}

bool checkMap(string token, Table &tmpT)   {
    return tmpT.find(token) == tmpT.end() ? false : true;
}

