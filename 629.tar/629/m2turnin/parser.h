#ifndef PARSER_H
#define PARSER_H

#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <stack>
#include <map>
#include <stdlib.h>
#include "tokenizer.h"

//******************************************************************************
// Programmers  : Nell Beatty : nell@cs.clemson.edu
//              : Leonard D. Holman Jr. : ldholma@cs.clemson.edu
// Date & Time  : Feburary 17 2003; 7:32PM
// Program      : Parser : Milestone 2
// Due Date     : Feburary 18 2003
// Program Description : This is a parser to check for symantically correct
//      sentences based upon Grammar.Spring.2003. The Parser component uses the
//      previously developed Lexical Analyzer.  The parser receives valid tokens
//      from the Lexical Analyzer and uses them in conjunction with the simple
//      precendence functions table.  The Parser implements the use of a stack
//      which contains valid tokens and their corresponding simple precendence
//      function relations.  The tokens are removed from the stack in the
//      reduction process.  The reduction process has two possible outcomes;
//      one is correct, and the other is error-recovery. The correct path
//      generates a handle(or a token), which is pushed back upon the stack.
//      Error-recovery will pop all tokens part of the error-causing token
//      sentence.  Upon completion, the parser gracefully terminates.
// *****************************************************************************
// Parser Flags
// 7  -  print the reduction (symbolic)
// 8  -  print the stack (symbolic) before and after a reduction
// 9  -  print the top of stack, input symbol and relation (all symbolic)
// 10  -  print the handle (symbolic)
// *****************************************************************************

using namespace std;

#define F	0
#define G	1
enum check {LES, GRT, EQT};

struct tableStruct   {
    int x[2];
    int &operator[](int i) {return x[i];}
};

class stkStrct   {
public:
    stkStrct(string i){item = i;}
    stkStrct(string i, check c){item = i; eq = c;}
    string item;
    check eq;
};

typedef map<string, tableStruct> Table;
typedef map<string, string> Grammar;

class Parser   {
public:
    Parser(string filename, string tfile, string gfile):token(filename){
        getFGTable(tfile);
        getGrammar(gfile);
    }
    void start();

private:
    LexicalAnalyzer token;
    Table FGtable;
    Grammar grammar;
    stack<stkStrct> pStack;
    bitset<4> flags;

    string reduceStack();
    void fixStack();
    void getFGTable(string filename);
    void getGrammar(string filename);
    bool checkGrammar(string token);
    bool checkHandle(string temp);
    void printStack();
    void flagCall(int i, string temp, string temp2)    ;
};

#endif
