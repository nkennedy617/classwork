#!/usr/bin/perl
# This script reads in the Grammar file
# It parses that file into a usable format,
# removing the $ lines and bringing the lefthand side
# down to those productions that don't have it
if (open(FILE, "+grammar.txt"))  {
 if(open(OUT, ">RevisedGrammar.txt")){
  @lines = <FILE>;
  foreach $line (@lines){
	if($line =~ /[^\n]/) {
         if($line =~ /^[^\$]/){
	  if($line =~ /^\w/){
		print OUT $line;
		@parts = split ' ', $line;
		$firstpiece = $parts[0];
    	  }
	  else{
		print OUT $firstpiece . $line;
	  }
	 }
	}
   }

 }
 else {
    print "ERROR \n";
   }
   #close files
 close(FILE);
 close(OUT);
}


