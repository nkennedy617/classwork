#ifndef __TOKENIZER
#define __TOKENIZER


#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
#include <iomanip>


using namespace std;


//******************************************************************************
// Programmers  : Nell Beatty : nell@cs.clemson.edu
//              : Leonard D. Holman Jr. : ldholma@cs.clemson.edu
// Date & Time  : Feburary 5 2003; 7:38PM
// Program      : Lexical Analyzer : Milestone 1
// Due Date     : Feburary 6 2003
// Program Description : This is a Lexical Analyzer class used to return valid
//      tokens found in a given file.  The user passes in the file name to the
//      Lexical Analyzer and then proceeds to ask for valid tokens via the
//      Next_Token function.  All invalid tokens are ignored and replaced by the
//      next valid token found; a warning message is then displayed to the user.
//      This calss also handles debugging flags which are found in the file and //      executes them accordingly, ignoring everthing with the debugging flags.
//      The Lexical Analyzer class will run until the end of file marker is
//      found.
//******************************************************************************


enum Reserved_Word { Not, Times, openParenthesis, closeParenthesis,
                     Plus, Minus, Equal, openBracket, closeBracket,
                     openBox, closeBox, Colon, Semicolon, lessThan, Comma,
                     greaterThan, backSlash, equalEqual, notEqual,
                     lessEqual, greaterEqual, backArrow, Or, And,  BeginComment,
                     EndComment, END, PROGRAM, DECLARE, INTEGER, REAL,
                     PROCEDURE, VALUE, REFERENCE, COMPUTE, INPUT, OUTPUT, CALL,
                     IF, ELSE, THEN, WHILE, DO, Identifier, Integer, Real,
                     Punctuation, Error, Flag, end_of_file};

class LexicalAnalyzer {
public:
   LexicalAnalyzer(string file_name);   //  Constructor
   ~LexicalAnalyzer();                  //  Destructor
   string Next_Token();                 //  Update
   Reserved_Word Type() const;          //  The type of the current token
   string Text() const;                 //  The text of the current token
   unsigned int Line() const;           //  Current Line count
   unsigned int Column() const;         //  Current column count
   bool Token_Error ();
   bitset<32> flags;

private:
   int line, col, ptr, endPtr;
   bool error, stateReal, flagging;
   Reserved_Word type;
   string token;
   ifstream infile;
   string buffer;


   void nextToken();
   string getDigit(int i);
   string getIdentifier(int i);
   string getPunct();
   bool testToken();
   void setFlag();
   void executeDebugFlag(int i);
   void setType();
   void getToken();
   void clearComment();
   void printFsaTable();
   void printHeader();
};

#endif
