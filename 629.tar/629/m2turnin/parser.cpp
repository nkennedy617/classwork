#include "parser.h"

void Parser::start()   {
  //****************************************************************************
  // This function starts the parser, check for syntatically correctness
  //****************************************************************************
string Token_List[50] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                  "]", ":", ";", "<", ",", ">", "/", "==", "!=", "<=",
                  ">=", "<-", "||", "&&", "/*", "*/", "END", "PROGRAM",
                  "DECLARE", "INTEGER", "REAL", "PROCEDURE", "VALUE",
                  "REFERENCE", "COMPUTE", "INPUT", "OUTPUT", "CALL", "IF",
                  "ELSE", "THEN", "WHILE", "DO", "var", "integer",
                  "real", "Punctuation", "Error", "Flag", "end_of_file"};
    token.Next_Token();                     // Starts parser going

    while(!token.Token_Error())   {
        string temp = Token_List[token.Type()];
        if(pStack.empty())   {              // Case for first Item on Stack
    	    if(checkGrammar(temp))          // Error Check
    	        pStack.push(stkStrct(temp, LES));
    	    else
               cout<<"\t\t***REDUCABILITY ERROR***" << endl;
  	        token.Next_Token();
  	        continue;
        }
	    if(!checkGrammar(temp))   {         // Token not in grammar
            cout << "\t\t***REDUCABILITY ERROR***" << endl;
            fixStack();
            continue;
	    }
	    string sTop = pStack.top().item;
	    if(token.flags.test(9))
    	    flagCall(9, temp, sTop);
        if(FGtable[sTop][F] > FGtable[temp][G])   {
        // Reduction process
            if(token.flags.test(8))
                flagCall(8, "before", "");

    	    string tp = reduceStack();
//	        if(find(grammar.begin(), grammar.end(), tp) == grammar.end())  {
            if(!checkHandle(tp) || tp == "")   {
                cout << "\t\t***REDUCABILITY ERROR***" << endl;
                fixStack();
                continue;
	        }
            if(!pStack.empty())   {
    	        sTop = pStack.top().item;
    	        if(FGtable[sTop][F] > FGtable[tp][G])   {
    	            cout << sTop << " : " << tp << endl;
    		        cout << "\t\t***STACKABILITY ERROR***" << endl;
    	    		fixStack();
    	    		continue;
    	        }
            }
            check c;
            if(!pStack.empty())   {
            	sTop = pStack.top().item;
            	c = FGtable[sTop][F]<FGtable[tp][G] ? LES : EQT;
          	}
            else
                c = LES;
            pStack.push(stkStrct(tp , c));          // Reduced token pushed on
            sTop = pStack.top().item;
            if(token.flags.test(8))
                flagCall(8, "after", "");
            continue;
	    }
	    // New token is pushed on stack
        pStack.push(stkStrct(temp,FGtable[sTop][F]<FGtable[temp][G]?LES:EQT));
        token.Next_Token();
    }
}

string Parser::reduceStack()   {
  //****************************************************************************
  // This function pops items off the stack until a less than equality is found
  //  meaning a complete RHS is found and is then returned.
  //****************************************************************************
    string temp;
    while(!pStack.empty() && pStack.top().eq != LES)   {
    	temp.insert(0, pStack.top().item + " ");
    	pStack.pop();
    }
    if(!pStack.empty())   {
        temp.insert(0, pStack.top().item + " ");
        pStack.pop();
    }
    if(temp[temp.length() - 1] == ' ')
        temp.erase(temp.length() - 1, 1);
    if(token.flags.test(7))    {
    	string t = "REDUCTION FROM STACK LHS = <" + grammar[temp];
    	t += "> RHS <" + temp + ">";
    if(!pStack.empty()&&FGtable[pStack.top().item][F]>FGtable[grammar[temp]][G])
    	    t = "REDUCTION FROM STACK NOT DONE,  STACKABILITY ERROR!";
        cout << setw(80) << t << endl;
    }
    if(token.flags.test(10))    {
	string t = "SYMBOLIC HANDLE = <" + temp + ">";
	cout << setw(80) << t << endl;
    }
    return grammar[temp];
}

void Parser::fixStack()   {
  //****************************************************************************
  // This function is called when an error is found in the file.  All tokens
  //  are popped off until a less than eqaulity is found and then all tokens
  //  from the file are removed which correspond to the bad sentence.
  //****************************************************************************
    while(!token.Token_Error() && token.Text() != ";")
        token.Next_Token();
    if(!token.Token_Error())
        token.Next_Token();
    while(!pStack.empty() && pStack.top().eq != LES)
    	pStack.pop();
    pStack.pop();
}

void Parser::getFGTable(string table_file)   {
  //****************************************************************************
  // This function reads a file, filling the FGtable map structure with the
  //  simple precedence function values.
  //****************************************************************************
    ifstream infike(table_file.c_str());
    string temp;

    while(getline(infike, temp))   {
    	tableStruct tmp;
    	int sp1 = temp.find(' ') + 1;
    	int sp2 = temp.find_last_of(' ') + 1;
    	tmp[F] = atoi(temp.substr(sp1, sp2 - sp1 - 1).c_str());
    	tmp[G] = atoi(temp.substr(sp2, temp.length() - sp2).c_str());
    	FGtable[temp.substr(0, temp.find(' '))] = tmp;
    }
}

void Parser::getGrammar(string grammar_file)   {
  //****************************************************************************
  // This function reads a file, filling the grammar map structure with the
  //  corresponding grammar information.
  //****************************************************************************
    ifstream infike(grammar_file.c_str());
    string temp;

    while(getline(infike, temp))   {
    	int tmp = temp.find(' ');
	    grammar[temp.substr(tmp + 1, temp.length()-tmp)] = temp.substr(0, tmp);
    }
/*    cout <<"**********************************************"<<endl;
    Grammar::iterator it = grammar.begin();
    for(it; it != grammar.end(); ++it)
        cout <<"|"<<it->first << "| --> |" << it->second << "|"<<endl;
    cout <<"**********************************************"<<endl; */
}

bool Parser::checkGrammar(string token)   {
  //****************************************************************************
  // This function checks if the passed in token is in the FGTable.
  //****************************************************************************
    return FGtable.find(token) == FGtable.end() ? false : true;
}

bool Parser::checkHandle(string temp)   {
  //****************************************************************************
  // This function checks if the passed in token is in the grammar.
  //****************************************************************************
    Grammar::iterator it = grammar.begin();
    for(it; it != grammar.end(); ++it)
        if(it->second == temp)
            return true;
    return false;
}

void Parser::flagCall(int i, string temp, string temp2)   {
  //****************************************************************************
  // This function handles parser flags found in the file.
  //****************************************************************************
    string t;
    switch(i)   {
        case 8:
            if(temp == "before")
                cout << setw(80) << "==Parse Stack Before Reduction===" << endl;
            else
                cout << setw(80) << "==Parse Stack After Reduction===" << endl;
            printStack();
            break;
        case 9:
            if(token.flags.test(9))   {
                string t = "Top of Stack <" + pStack.top().item;
                t += ">  Input Symbol <" + temp + ">  Relation <";
                if(FGtable[temp2][G] > FGtable[temp][F])
                    t += "Greater Than>";
                else if(FGtable[temp2][G] == FGtable[temp][F])
                    t += "Equal To>";
                else
                    t += "Less Than>";
                cout << setw(80) << t << endl;
            }
            break;
        case 10:

            break;
    }
}

void Parser::printStack()   {
  //****************************************************************************
  // THis function prints the current stack.
  //****************************************************************************
    stack<stkStrct> temp(pStack);
    while(!temp.empty())   {
        cout << setw(80) << temp.top().item << endl;
        temp.pop();
    }
}
