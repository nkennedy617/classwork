#include <string>
#include <iostream>
#include <fstream>
#include <stack>
#include <map>

enum check {LES, GRT, EQT};
#define F       0
#define G       1
using namespace std;

struct tableStruct   {
    int x[2];
    int &operator[](int i) {return x[i];}
};
struct stackStruct   {
    string item;
    check equality;
};
typedef map<string, tableStruct> Table;
typedef map<string, string> Grammer;

string reduceStack();
void getFGTable(string table);
void getGrammer(string gramm);
bool checkMap(string token);

    Table FGtable;
    Grammer grammer;
    stack<stackStruct> parseStack;

int main()   {
    getFGTable("FGTable");
    getGrammer("gram.txt");

//declstat- type var integer
    stackStruct tmp;
    tmp.item = "type";
    tmp.equality = LES;
    parseStack.push(tmp);
    tmp.item = "var";
    tmp.equality = EQT;
    parseStack.push(tmp);
    tmp.item = "integer";
    parseStack.push(tmp);
    string f = reduceStack();//cout<<"FINAL STRING = " << reduceStack() << endl;
    cout << "right hand side = :" << f << ":" << endl;
    cout << grammer[f] << endl;
}

string reduceStack()   {
    string temp;
    temp = parseStack.top().item;
    parseStack.pop();
    cout << "temp = " << temp << endl;
    while(parseStack.top().equality != LES)   {
       	temp.insert(0, parseStack.top().item + " ");
       	parseStack.pop();
       	cout << "temp = " << temp << endl;
    }
    temp.insert(0, parseStack.top().item + " ");
    parseStack.pop();
    return temp;
}

void getFGTable(string table)   {
    ifstream infike(table.c_str());
    string temp;

    while(getline(infike, temp))   {
    	tableStruct tmp;
	int sp1 = temp.find(' ') + 1;
	int sp2 = temp.find_last_of(' ') + 1;
	tmp[F] = atoi(temp.substr(sp1, sp2 - sp1 - 1).c_str());
	tmp[G] = atoi(temp.substr(sp2, temp.length() - sp2).c_str());
	FGtable[temp.substr(0, temp.find(' '))] = tmp;
    }
}

void getGrammer(string gramm)   {
    ifstream infike(gramm.c_str());
    string temp;

    while(getline(infike, temp))   {
	int tmp = temp.find(' ');
	grammer[temp.substr(tmp + 1, temp.length()-tmp)] = temp.substr(0, tmp);
    }
}

bool checkMap(string token)   {
    return FGtable.find(token) == FGtable.end() ? false : true;
}
