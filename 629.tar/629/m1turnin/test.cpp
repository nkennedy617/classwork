#include "tokenizer.h"
#include <iostream>

using namespace std;

int main()   {
    LexicalAnalyzer myToken("l.txt");
    while(!myToken.Token_Error())   {
	myToken.Next_Token();
    }
}