#include "parser.h"

void Parser::startSemantics()   {
    if(token.Token_Error())
        return;
    start();                                // ADDED FOR PROG3
    string tmp = sStack[0];
    while(!pStack.empty())
        reduceStack();
    if(token.flags.test(16))
        printST(0, tmp);
}

void Parser::start()   {
  //****************************************************************************
  // This function starts the parser, check for syntatically correctness
  //****************************************************************************
string Token_List[50] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                  "]", ":", ";", "<", ",", ">", "/", "==", "!=", "<=",
                  ">=", "<-", "||", "&&", "/*", "*/", "END", "PROGRAM",
                  "DECLARE", "INTEGER", "REAL", "PROCEDURE", "VALUE",
                  "REFERENCE", "COMPUTE", "INPUT", "OUTPUT", "CALL", "IF",
                  "ELSE", "THEN", "WHILE", "DO", "var", "integer",
                  "real", "Punctuation", "Error", "Flag", "end_of_file"};
    token.Next_Token();                     // Starts parser going

    while(!token.Token_Error())   {
        string temp = Token_List[token.Type()];
        if(pStack.empty())   {              // Case for first Item on Stack
    	    if(checkGrammar(temp))   {          // Error Check
    	        pStack.push(stkStrct(temp, LES));
                sStack.push_back(token.Text());
            }
    	    else
               cout<<"\t\t***REDUCABILITY ERROR***" << endl;
  	        token.Next_Token();
  	        continue;
        }
	    if(!checkGrammar(temp))   {         // Token not in grammar
            cout << "\t\t***REDUCABILITY ERROR***" << endl;
            fixStack();
            continue;
	    }
	    string sTop = pStack.top().item;
	    if(token.flags.test(9))
    	    flagCall(9, temp, sTop);
        if(FGtable[sTop][F] > FGtable[temp][G])   {
        // Reduction process
            if(token.flags.test(8))
                flagCall(8, "before", "");
            if(token.flags.test(12))
                flagCall(12, "before", "");
    	    string tp = reduceStack();
//	        if(find(grammar.begin(), grammar.end(), tp) == grammar.end())  {
            if(!checkHandle(tp) || tp == "")   {
                cout << "\t\t***REDUCABILITY ERROR***" << endl;
                fixStack();
                continue;
	        }
            if(!pStack.empty())   {
    	        sTop = pStack.top().item;
    	        if(FGtable[sTop][F] > FGtable[tp][G])   {
    	            cout << sTop << " : " << tp << endl;
    		        cout << "\t\t***STACKABILITY ERROR***" << endl;
    	    		fixStack();
    	    		continue;
    	        }
            }
            check c;
            if(!pStack.empty())   {
            	sTop = pStack.top().item;
            	c = FGtable[sTop][F]<FGtable[tp][G] ? LES : EQT;
          	}
            else
                c = LES;
            pStack.push(stkStrct(tp , c));          // Reduced token pushed on
            sTop = pStack.top().item;
            if(token.flags.test(8))
                flagCall(8, "after", "");
            if(token.flags.test(12))
                flagCall(12, "after", "");
            continue;
	    }
	    // New token is pushed on stack
        pStack.push(stkStrct(temp,FGtable[sTop][F]<FGtable[temp][G]?LES:EQT));
        sStack.push_back(token.Text());
        token.Next_Token();
    }
}

string Parser::reduceStack()   {
  //****************************************************************************
  // This function pops items off the stack until a less than equality is found
  //  meaning a complete RHS is found and is then returned.
  //****************************************************************************
    string temp;
    int numPops = 0;

// Here is where I think we should call the semantic part, sending it a pstack
// and I think we also need to send it grammar[temp]

    while(!pStack.empty() && pStack.top().eq != LES)   {
    	temp.insert(0, pStack.top().item + " ");
    	pStack.pop();
        numPops++;
    }
    if(!pStack.empty())   {
        temp.insert(0, pStack.top().item + " ");
        pStack.pop();
        numPops++;
    }
    if(temp[temp.length() - 1] == ' ')
        temp.erase(temp.length() - 1, 1);
    if(token.flags.test(7))    {
    	string t = "REDUCTION FROM STACK LHS = <" + grammar[temp];
    	t += "> RHS <" + temp + ">";
    if(!pStack.empty()&&FGtable[pStack.top().item][F]>FGtable[grammar[temp]][G])
    	    t = "REDUCTION FROM STACK NOT DONE,  STACKABILITY ERROR!";
        cout << setw(80) << t << endl;
    }
    if(token.flags.test(10))    {
        string t = "SYMBOLIC HANDLE = <" + temp + ">";
        cout << setw(80) << t << endl;
    }
    checkReduction(temp, grammar[temp], numPops - 1);
    return grammar[temp];
}

void Parser::fixStack()   {
  //****************************************************************************
  // This function is called when an error is found in the file.  All tokens
  //  are popped off until a less than eqaulity is found and then all tokens
  //  from the file are removed which correspond to the bad sentence.
  //****************************************************************************
    while(!token.Token_Error() && token.Text() != ";")
        token.Next_Token();
    if(!token.Token_Error())
        token.Next_Token();
    while(!pStack.empty() && pStack.top().eq != LES)   {
    	pStack.pop();
    	sStack.pop_back();
    }
    pStack.pop();
  	sStack.pop_back();
}

void Parser::getFGTable(string table_file)   {
  //****************************************************************************
  // This function reads a file, filling the FGtable map structure with the
  //  simple precedence function values.
  //****************************************************************************
    ifstream infike(table_file.c_str());
    string temp;

    while(getline(infike, temp))   {
    	tableStruct tmp;
    	int sp1 = temp.find(' ') + 1;
    	int sp2 = temp.find_last_of(' ') + 1;
    	tmp[F] = atoi(temp.substr(sp1, sp2 - sp1 - 1).c_str());
    	tmp[G] = atoi(temp.substr(sp2, temp.length() - sp2).c_str());
    	FGtable[temp.substr(0, temp.find(' '))] = tmp;
    }
}

void Parser::getGrammar(string grammar_file)   {
  //****************************************************************************
  // This function reads a file, filling the grammar map structure with the
  //  corresponding grammar information.
  //****************************************************************************
    ifstream infike(grammar_file.c_str());
    string temp;

    while(getline(infike, temp))   {
    	int tmp = temp.find(' ');
	    grammar[temp.substr(tmp + 1, temp.length()-tmp)] = temp.substr(0, tmp);
    }
/*    cout <<"**********************************************"<<endl;
    Grammar::iterator it = grammar.begin();
    for(it; it != grammar.end(); ++it)
        cout <<"|"<<it->first << "| --> |" << it->second << "|"<<endl;
    cout <<"**********************************************"<<endl; */
}

bool Parser::checkGrammar(string token)   {
  //****************************************************************************
  // This function checks if the passed in token is in the FGTable.
  //****************************************************************************
    return FGtable.find(token) == FGtable.end() ? false : true;
}

bool Parser::checkHandle(string temp)   {
  //****************************************************************************
  // This function checks if the passed in token is in the grammar.
  //****************************************************************************
    Grammar::iterator it = grammar.begin();
    for(it; it != grammar.end(); ++it)
        if(it->second == temp)
            return true;
    return false;
}

void Parser::flagCall(int i, string temp, string temp2)   {
  //****************************************************************************
  // This function handles parser flags found in the file.
  //****************************************************************************
    string t;
    switch(i)   {
        case 8:
            if(temp == "before")
                cout << setw(80) << "==Parse Stack Before Reduction===" << endl;
            else
                cout << setw(80) << "==Parse Stack After Reduction===" << endl;
            printStack();
            break;
        case 9:
            if(token.flags.test(9))   {
                string t = "Top of Stack <" + pStack.top().item;
                t += ">  Input Symbol <" + temp + ">  Relation <";
                if(FGtable[temp2][G] > FGtable[temp][F])
                    t += "Greater Than>";
                else if(FGtable[temp2][G] == FGtable[temp][F])
                    t += "Equal To>";
                else
                    t += "Less Than>";
                cout << setw(80) << t << endl;
            }
            break;
        case 12:
            if(temp == "before")
                cout <<setw(80)<<"==Semantic Stack Before Reduction===" << endl;
            else
                cout << setw(80)<<"==Semantic Stack After Reduction===" << endl;
            printSemanticStack();
            break;
    }
}

void Parser::printStack()   {
  //****************************************************************************
  // THis function prints the current stack.
  //****************************************************************************
    stack<stkStrct> temp(pStack);
    while(!temp.empty())   {
        cout << setw(80) << temp.top().item << endl;
        temp.pop();
    }
}

// ****************BEGIN OF SEMANIC STACK CODE**********************************

void Parser::printSemanticStack()   {
  //****************************************************************************
  // THis function prints the current stack.
  //****************************************************************************
    for(int i = sStack.size() - 1; i >= 0; i--)
        cout << setw(80) << sStack[i] << endl; //.print();
}

void Parser::checkReduction(string rhs, string lhs, int numPops)   {
//cout << "IN CHECKREDUCTION lhs<"<<lhs<<">   rhs<"<<rhs<<">"<< endl;
    if(lhs=="start")   {                // 1
        if(token.flags.test(13))   {
            printTuple(ST[j()][sStack[i(2)]]->STEntry,"ENDPROGRAM",
                "-", "-");
        }
        if(token.flags.test(15))
            ST[j()][sStack[i(2)]]->print();
    }
    else if(lhs=="prog")   {            // 2
        if(token.flags.test(17))   {
            cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
            cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS DECLARATION:"<<endl;
            if(checkST(sStack[i()], 0))   {
                cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                cout << "\tEND OF TRACE" << endl;
            }
        }
        if(checkST(sStack[i()], 0))   {
            cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :"<<sStack[i()]<<endl;
            popItems(numPops);
            return;
        }
        ST[j()][sStack[i()]] = new STElem(sStack[i()],
                "", "", "BEGINPROGRAM", "");
        sStack[i(1)] = sStack[i()];
        if(token.flags.test(17))   {
            cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
            cout<<"\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH CONTAINS:"<<endl;
            ST[j()][sStack[i()]]->print();
            cout << "\tEND OF TRACE" << endl;
        }
        if(token.flags.test(13))
            printTuple(sStack[i()], "BEGINPROGRAM", "-", "-");
        if(token.flags.test(15))
            ST[j()][sStack[i()]]->print();
    }
    else if(lhs=="body")   {                // 3, 4
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="declpart")   {            // 5
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="decllist")   {            // 6
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="decllist-")   {           // 7, 8
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="declstat")   {            // 9
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="declstat-")   {       // 10, 11, 12, 13, 14, 15, 16
        if(rhs == "declstat- , var")   {                        // 10
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            STElem tmp(*(ST[j()][sStack[i(2)]]));
            tmp.STEntry = sStack[i()];
            ST[j()][sStack[i()]] = new STElem(tmp);
            sStack[i(2)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                string tmp = ST[j()][sStack[i()]]->tupletype;
                printTuple(sStack[i()], ST[j()][sStack[i()]]->tupletype,
                    ST[j()][sStack[i()]]->rows, ST[j()][sStack[i()]]->cols);
    	    }
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="declstat- type var")   {                  // 11
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "MEMORY", "", 1);
            sStack[i(2)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i()], "MEMORY", "1", "0");
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="declstat- type var integer")   {          // 12
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "MEMORY", "",
                    atoi(sStack[i()].c_str()));
            sStack[i(3)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(1)], "MEMORY",
                    sStack[i()], "1");
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="declstat- type var integer integer")   {  // 13
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "MEMORY", "",
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            sStack[i(4)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(2)], "MEMORY",
                    sStack[i(1)], sStack[i()]);
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
        else if(rhs=="type var")   {                            // 14
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "MEMORY", "", 1);
            sStack[i(1)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i()], "MEMORY", "1", "0");
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="type var integer")   {                    // 15
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "MEMORY", "",
                atoi(sStack[i()].c_str()));
            sStack[i(2)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(1)], "MEMORY",
                    sStack[i()], "1");
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="type var integer integer")   {            // 16
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "MEMORY", "",
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            sStack[i(3)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(2)], "MEMORY",
                    sStack[i(1)], sStack[i()]);
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
    }
    else if(lhs=="type")   {                // 17, 18
        popItems(numPops);
        return;
    }
    else if(lhs=="procpart")   {            // 19
        popItems(numPops);
        return;                         // these are empty
    }
    else if(lhs=="proclist")   {            // 20, 21
        popItems(numPops);
        return;                         // these are empty
    }
    else if(lhs=="proc")   {            // 22, 23
        if(rhs=="prochead declpart statlist END")   {
            if(token.flags.test(14))
                printST(j(), sStack[i(3)]);
            if(token.flags.test(13))
                printTuple(sStack[i(3)], "ENDPROC", "-", "-");
        }
        else if(rhs=="prochead declpart procpart statlist END")   {
            if(token.flags.test(14))
                printST(j(), sStack[i(4)]);
            if(token.flags.test(13))
                printTuple(sStack[i(4)], "ENDPROC", "-", "-");
        }
        ST.pop_back();      // GOOD?? YES
    }
    else if(lhs=="prochead")   {            // 24, 25
        popItems(numPops);
        return;
    }
    else if(lhs=="procname")   {            // 26
        if(token.flags.test(17))   {
            cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
            cout << "\t\tCREATING NEW SYMBOL TABLE FOR PROCEDURE"<<endl;
        }
        SymbolTable tmpST;
        tmpST[sStack[i()]] = new STElem(sStack[i()],
            "", "", "BEGINPROC", "");
        ST.push_back(tmpST);
        sStack[i(1)] = sStack[i()];
        if(token.flags.test(17))   {
            cout<<"\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH CONTAINS:"<<endl;
            ST[j()][sStack[i()]]->print();
            cout << "\tEND OF TRACE" << endl;
        }
        if(token.flags.test(13))
            printTuple(sStack[i()], "BEGINPROC", "-", "-");
        if(token.flags.test(15))
            ST[j()][sStack[i(1)]]->print();
    }
    else if(lhs=="null-list")   {           // 27
        if(token.flags.test(13))
            printTuple("-", "NOPARAMS", "-", "-");
    }
    else if(lhs=="fparmlist")   {           // 28
        if(token.flags.test(13))
            printTuple("-", "ENDPARAMS", "-", "-");
    }
    else if(lhs=="fparmlist-")   {      // 29 - 35
        if(rhs=="fparmlist- , var")   { // 29
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            STElem tmp(*(ST[j()][sStack[i(2)]]));
            tmp.STEntry = sStack[i()];
            ST[j()][sStack[i()]] = new STElem(tmp);
            sStack[i(2)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                string tmp = ST[j()][sStack[i()]]->tupletype;
                printTuple(sStack[i()], ST[j()][sStack[i()]]->tupletype,
                    ST[j()][sStack[i()]]->rows, ST[j()][sStack[i()]]->cols);
    	    }
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="fparmlist- , calltype type var")   {  // 30
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "PARAM", sStack[i(2)], 1);
            sStack[i(4)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i()], "PARAM",
                    sStack[i(2)], SIZE);
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="fparmlist- , calltype type var integer")   {  // 31
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "PARAM", sStack[i(3)],
                atoi(sStack[i()].c_str()));
            sStack[i(5)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(1)], "PARAM",
                    sStack[i(3)],
                    SIZE * atoi(sStack[i()].c_str()));
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="fparmlist- , calltype type var integer integer")   { // 32
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "PARAM", sStack[i(4)],
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            sStack[i(6)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(2)], "PARAM",
                    sStack[i(4)], SIZE *
                    atoi(sStack[i()].c_str()) *
                    atoi(sStack[i(1)].c_str()));
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
        else if(rhs=="{ calltype type var")   {             // 33
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "PARAM", sStack[i(2)], 1);
            sStack[i(3)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                printTuple("-", "BEGINPARAM", "-", "-");
                printTuple(sStack[i()], "PARAM",
                    sStack[i(2)], SIZE);
            }
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="{ calltype type var integer")   {     // 34
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "PARAM", sStack[i(3)],
                atoi(sStack[i()].c_str()));
            sStack[i(4)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                printTuple("-", "BEGINPARAM", "-", "-");
                printTuple(sStack[i(1)], "PARAM",
                    sStack[i(3)],
                    SIZE * atoi(sStack[i()].c_str()));
            }
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="{ calltype type var integer integer")   {     // 35
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "PARAM", sStack[i(4)],
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            sStack[i(5)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                printTuple("-", "BEGINPARAM", "-", "-");
                printTuple(sStack[i(2)], "PARAM",
                    sStack[i(4)],
                    SIZE * atoi(sStack[i()].c_str()) *
                    atoi(sStack[i(1)].c_str()));
            }
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
    }
    else if(lhs=="calltype")   {            // 36, 37
        popItems(numPops);
        return;
    }
    popItems(numPops);
}

void Parser::popItems(int n)   {
    for(int i = 0; i < n; i++)
        sStack.pop_back();
}

void Parser::printTuple(string s1, string s2, string s3, string s4)   {
    string tmp = "tuple (" + s1 +", "+ s2 +", "+ s3 +", "+ s4 +")";
    cout << setw(80) << tmp << endl;
}
void Parser::printTuple(string s1, string s2, string s3, int s4)   {
    ostringstream os;
    os << s4;
    string tmp = "tuple (" +s1+", "+s2+", "+s3+", "+ os.str() +")";
    cout << setw(80) << tmp << endl;
}
void Parser::printTuple(string s1, string s2, int s3, int s4)   {
    ostringstream os;
    os << s3 <<", "<<s4;
    string tmp = "tuple (" +s1+", "+s2+", "+ os.str() +")";
    cout << setw(80) << tmp << endl;
}

void STElem::print()   {
/*string tmp[15] {"PARAM", "MEMORY", "NOPARAM", "BEGINPARAM", "ENDPARAM",
    "BEGINPROC", "ENDPROC", "BEGINPROGRAM", "ENDPROGRAM", "MATRIX",
    "VECTOR", "SCALAR", "VALUE", "REFERENCE", "NONE"};*/

    cout << "\t\tSymbol Table Entry Data===" << endl;
    cout << "\t\t  Entry Name: " << STEntry << endl;
    cout << "\t\t  Tuple Type: " << tupletype << endl;
    cout << "\t\t  Call Type : " << calltype << endl;
//    cout << "\t\t  Parse Code: " << parsecode << endl;
    cout << "\t\t  Shape     : " << shape << endl;
    cout << "\t\t  Rows      : " << rows << endl;
    cout << "\t\t  Columns   : " << cols << endl;
    cout << "\t\t  Size      : " << size << endl;
}


bool Parser::checkST(string token, int loc)   {
  //****************************************************************************
  // This function checks if the passed in token is in the FGTable.
  //****************************************************************************
    if(ST[j(loc)].empty())
        return false;
    return ST[j(loc)].find(token) == ST[j(loc)].end() ? false : true;
}

void Parser::printST(int p, string pname)   {
     cout <<"\tENTRIES FOR SYMBOL TABLE: " << pname << endl;
     for(int i = p; i < ST.size(); i++)   {
         SymbolTable::iterator it = ST[i].begin();
         if(p == 0 && i > 0)
             cout <<"\tENTRIES FOR NEXT SYMBOL TABLE" << endl;
         for(it; it != ST[i].end(); ++it)   {
             cout <<"\tTABLE ENTRY :"<<it->first << endl;
             it->second->print();
         }
         cout << "\tEND OF ENTRTIES FOR THIS TABLE" << endl;
     }
}
