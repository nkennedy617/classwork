#ifndef SEMANTIC_H
#define SEMANTIC_H

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
#include <stack>
#include <map>
#include <stdlib.h>
#include "tokenizer.h"

//******************************************************************************
// Programmers  : Nell Beatty : nell@cs.clemson.edu
//              : Leonard D. Holman Jr. : ldholma@cs.clemson.edu
// Date & Time  : Feburary 26 2003; 7:32PM
// Program      : Semantic I : Milestone 3
// Due Date     : March 11 2003
// Program Description :
// *****************************************************************************
// Parser Flags
// *****************************************************************************

using namespace std;
enum shapedef{MATRIX, VECTOR, SCALAR};
enum tuple_Type {PARAM, MEMORY, NOPARAM, BEGINPARAM, ENDPARAM, BEGINPROC, ENDPROC};

class STElem   {
public:
    STELem(string en, Reserved_Word pc, shapedef s, int r = 0, int c = 0)   {
        STEntryname = en;
        parsecode = pc;
        shape = s;
        rows = r;
        cols = c;
        setTuple();
    }
    tuple_Type tupleType;
	string STEntryname;
    Reserved_Word parsercode;
    shapedef shape;
    int rows;
    int cols;
    void makeSTEntry();
	string tuple;
private:
	void setTuple();
	void makeTuple();
    bitset<6> flags;
};

class SemanticStack {
public:
    void start();
private:
    vector SemStack;
};

#endif
