#include "semantic.h"

void SemStack::start()   {
  //****************************************************************************
  //****************************************************************************

// initialize all the new stuff
//this is called from parser
// needs the syntax stack b/c needs items like the indivudal var, integer, integer

//Start the Lex and parser

// when something is <> on the parser, we need to do semantic stuff
// if(lhs=="body")
// 	return  to the parser for next item
// else if(lhs=="declpart")
// 	return  to the parser for next item
// else if(lhs=="decllist")
// 	return  to the parser for next item
// else if(lhs=="decllist-")
// 	return  to the parser for next item
// else if(lhs=="declstat")
// 	return  to the parser for next item
// else
// this section actually requires us to process stuff
//   if the lhs is type then we need to 
//   Set s@I to "int"/"real"
}


void STElem::makeSTEntry(){
// This needs to take in the syntax stack
// It will process the stack 
// Then it will call makeTuple to make memory tuple
}

void STElem::makeTuple(){
// tuple = "("
// make memory tuple for later use
// if it is a scalar, vector, or matrix
// calculate total memory needed
// return (name, MEMORY, size rows, size columns)

// if it is a procedure
// construct tuple
// return(name, start/end PROCEDURE, , )
//tupble=tuple + ")"
}