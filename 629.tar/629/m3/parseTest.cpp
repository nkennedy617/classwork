#include <iostream>
#include <string>
#include "parser.h"

using namespace std;

int main(int argc, char **argv)   {
    if(argc != 4)
        exit(1);
    // argv[1] = code file, argv[2] = FGtable, argv[3] = Grammer
    Parser myParser(argv[1], argv[2], argv[3]);
    myParser.startSemantics();
}
