#include <iostream>
#include <vector>
#include <map>
#include <string>

using namespace std;
class poo   {
	public:
	poo();
	poo(int p) { pp = p; }
	int pp;
};
typedef map<string, poo*> tt;

int main()   {
	tt m;
	m["FART"] = new poo(10);
//	&poo(10);
	cout << m["FART"]->pp << endl; 
}
