#include <iostream>
#include <string>
#include "parser.h"
#include "semantic.h"

using namespace std;

int main(int argc, char **argv)   {
    SymbolTable ST;
    semanticStack ss;
    parser p(argv[1], argv[2], argv[3]);

    while(p.getNextSentence())   {
        ss()
    }
}
