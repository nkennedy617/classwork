#include "tokenizer.h"
#include <iostream>

using namespace std;

int main()   {
    Token myToken("l.txt");
    while(!myToken.Token_Error())   {
	cout << myToken.LexAnal() << endl;
    }
}
