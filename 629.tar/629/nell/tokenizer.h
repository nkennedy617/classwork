#ifndef __TOKENIZER
#define __TOKENIZER

#include <iostream>
#include <fstream>
#include <string>
#include <bitset>

using namespace std;

enum Reserved_Word { Not, Times, openParenthesis, closeParenthesis,
		     Plus, Minus, Equal, openBracket, closeBracket,
		     openBox, closeBox, Colon, Semicolon, lessThan,
		     greaterThan, backSlash, equalEqual, notEqual,
		     lessEqual, greaterEqual, backArrow, Or, And,
		     END, PROGRAM, DECLARE, INTEGER, REAL, PROCEDURE,
		     VALUE, REFERENCE, COMPUTE, INPUT, OUTPUT, CALL,
		     IF, ELSE, THEN, WHILE, DO, Identifier, Integer, Real,
		     Punctuation, Error, Flag, end_of_file };

class Token {
public:
   //  Constructor
   Token (string file_name);

   string LexAnal();
   //  Update

   Reserved_Word Type () const;
   //  The type of the current token

   string Text () const;
   //  The text of the current token

   unsigned int Line () const;
   unsigned int Column () const;
   //  The line and first column of the current token


   bool Token_Error ();

private:
   int line, col, ptr, endPtr;
   bool error, stateReal, flagging;
   Reserved_Word type;
   string token;
   bitset<32> flags;

   ifstream infile;
   string buffer;

   void Next_Token ();
   string getDigit (int i);
   string getIdentifier (int i);
   string getPunct ();
   bool testDigit();
   void setFlag();
   void executeDebugFlag(int i);
   void setType ();
   void getToken ();
   void clearComment (string typ);
   void printFsaTable();

};

//#include "tokenizer.cpp"
#endif
