#include "tokenizer.h"

Token::Token (string file_name)   {
  //******************************************************************
  // Opens file given when Token is declared
  // If file not there, error is set and user is prompeted
  //******************************************************************
    infile.open(file_name.c_str());
    if(!infile)
    	cout << "Tokenizer could not open file" << endl;
    ptr = 0; col = 1; line = 0; error = false; stateReal = false;
    flags.set(1);
}

string Token::LexAnal()   {
  //******************************************************************
  // LexAnal tests each token for validity, tokens are removed until
  //  the next good token is found which is then returned
  //******************************************************************
    Next_Token();
    if(flags.test(3))
    	executeDebugFlag(3);

    while(type == Error || type == Integer || type == Real)   {
	if(type != Error)
	    if(testDigit())	// Valid digit found
		break;
    	Next_Token();
    }
    if(type == Flag)   {
	setFlag();
	return LexAnal();
    }
    return token;
}

bool Token::testDigit()   {
    if(type == Integer)
	if(token.size() > 9)
	    return false;
    else   {
	while(token[token.size() - 1] == '0')
	    token.erase(token.size() - 1);
	if(token.size() > 7)
	    return false;
    }
    return true;
}

void Token::Next_Token ()   {
  //******************************************************************
  // Next_Token gets new buffer lines and throws away spaces and empty
  //  lines found in file.  The column and line values are set
  //  accordingly.  If end of file is found, error is set to true.
  //******************************************************************
    if(infile && ptr >= endPtr || line == 0)   {	// Grabs new line
    	getline(infile, buffer);
    	ptr = 0; col = 1; line++;
	executeDebugFlag(1);
    	endPtr = buffer.length();
    }
    if(infile)    {
    	while((ptr==endPtr || isspace(buffer[ptr])) && infile)  {
	    if(ptr >= endPtr)   {	    	// Passes spaces and
        	ptr = 0; col = 1; line++;		//  empty lines
	        getline(infile, buffer);
		if(flags.test(1))
		    executeDebugFlag(1);
    	    	endPtr = buffer.length();
	    }
    	    while(ptr < endPtr && isspace(buffer[ptr]) && infile)
	       	ptr++;
    	    if(ptr >= endPtr)   {
	        ptr = 0; col = 1; line++;
	        getline(infile, buffer);
		if(flags.test(1))
		    executeDebugFlag(1);
	        endPtr = buffer.length();
	    }
	}
	col = ptr + 1;
	if(infile)   {					// Gets token if file
	    if (flags.test(4))
		cout << "In start state, receiving input" <<endl;
    	    getToken();				//  is still open
	}
    	else   {					// Else error Flag set
    	    token = " ";			//  and type set to
	    col = 1; type = end_of_file;		//  end of file
    	}
    }
    else   {						// If end of file, type
	token = " ";				//  is set to e/o/f
	col = 1; type = end_of_file; error = true;
    }
}

Reserved_Word Token::Type () const   {
  //******************************************************************
  // Returns the type of token found.
  //******************************************************************
    return type;
}
string Token::Text () const   {
  //******************************************************************
  // Returns the text of the token.
  //******************************************************************
    return token;
}
unsigned int Token::Line () const   {
  //******************************************************************
  // Returns line number.
  //******************************************************************
    return line;
}
unsigned int Token::Column () const   {
  //******************************************************************
  // Returns column number.
  //******************************************************************
    return col;
}
bool Token::Token_Error ()   {
  //******************************************************************
  // Returns the value set in error.
  //******************************************************************
    return error;
}

void Token::getToken ()   {
  //******************************************************************
  // Checks current ptr location in buffer.  Depending on the value
  //  found, the token a found and set.
  //******************************************************************
    error = false;
    if(ispunct(buffer[ptr]))   { 			// Punct found
	if(flags.test(4))
	    cout << "Input is ascii, going to State D" << endl;
    	token = getPunct();
    }
    else if(isdigit(buffer[ptr]))   {		// Number found
	if(flags.test(4))
	    cout << "Input is digit, going to State B" << endl;
    	token = getDigit(ptr);			// Checks for float
    	int tmptr = token.length();
    	if(buffer[ptr + tmptr] == '.' && isdigit(buffer[ptr + tmptr + 1]))   {
	    if(flags.test(4))   {
	        cout << "Input is period, going to State C" << endl;
	        cout << "Input is digit, going to Stats C" << endl;
	        stateReal = true;
	    }
	    token += buffer[ptr + tmptr] + getDigit(ptr + (tmptr+1));
	    stateReal = false;
	}
    }
    else if(isalpha(buffer[ptr]) && isupper(buffer[ptr]))   {// Identifier found
	if(flags.test(4))
	    cout << "Input is Uppercase, going to State F" << endl;
        token = buffer[ptr];
    	token += getIdentifier(ptr + 1);
    }
    else   {
	if(flags.test(4))
	    cout << "Input is error, going to error state" << endl;
        error = true;
        token = buffer[ptr];
    }

    if(token == "")     	    			// If no token found
    	Next_Token();	    				//  retry and set token
    else   {					        	//  to new value
        ptr += token.length();
        if(error)
            type = Error;
        else
            setType();
    }
}

string Token::getPunct()   {
  //******************************************************************
  // Gets all forms of puncuation.
  //******************************************************************
    string temp, blank;
    string pun[26] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                      "]", ":", ";", "<", ">", "/", "==", "!=", "<=",
                      ">=", "<-" , "||", "&&", "##"};
    cout << buffer[ptr] << endl;
    temp = buffer[ptr];
    if(ptr < endPtr - 1 && ispunct(buffer[ptr + 1]))   {
    	temp.assign(buffer, ptr, 2);
    	if(temp == "/*")   {
            cout << "*" << endl;
    	    clearComment("/*");
	        return blank;
    	}
        for(int i = 16; i < 26; i++) 		// Checks for punctuation
	    if(temp == pun[i]) {		//  double
    	        cout << temp[1] << endl;	
                return pun[i];
             }
    	temp.erase(1);
    }
    for(int i = 0; i < 16; i++) 		// Checks for punctuation
	if(temp == pun[i])
            return pun[i];
    error = true;
	return "%";
}

string Token::getDigit(int i)   {
  //******************************************************************
  // Grab all digits recersively and return as string.
  //******************************************************************
    string blank;
    if(i >= endPtr)   {
        ptr = 0; col = 1; line++; i = 0;
        getline(infile, buffer);
	executeDebugFlag(1);
        endPtr = buffer.length();
    }
    if(!infile)
	return blank;
    if(isdigit(buffer[i]))    {
        if(flags.test(3)) 	
            cout << buffer[i] << endl;
        if(flags.test(4))   {
	    if(stateReal)
	    	cout << "Input is digit, going to state C" << endl;
	    else
	    	cout << "Input is digit, going to state B" << endl;
	}
     	return buffer[i] + getDigit(i + 1);
    }
    return blank;
}

string Token::getIdentifier(int i)   {
  //******************************************************************
  // Grab an identifier recersively until a digit or alpha or
  //  underscore is not found.  Value is then returned as a string.
  //******************************************************************
    string blank;
    if(i >= endPtr)   {
        ptr = 0; col = 1; line++; i = 0;
        getline(infile, buffer);
	executeDebugFlag(1);
        endPtr = buffer.length();
    }
    if(!infile)
	return blank;
    if(isdigit(buffer[i]) || isalpha(buffer[i]) || buffer[i] == '_')   {
        if(flags.test(3)) 	
            cout << buffer[i] << endl;
	if(flags.test(4))
	    cout << "Input is identifiable, going to state F" << endl;
       	return buffer[i] + getIdentifier(i + 1);
    }
    return blank;
}

void Token::setType()   {
  //******************************************************************
  // Sets the type of the token from the token currently grab from
  //  file.
  //******************************************************************
    string pun[40] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                      "]", ":", ";", "<", ">", "/", "==", "!=", "<=",
                      ">=", "<-", "||", "&&", "END", "PROGRAM", "DECLARE",
                      "INTEGER", "REAL", "PROCEDURE", "VALUE", "REFERENCE",
                      "COMPUTE", "INPUT", "OUTPUT", "CALL", "IF", "ELSE",
                      "THEN", "WHILE", "DO"};

    if(type != end_of_file)   {
    	bool tmp = false;
    	int i;
    	for(i = 0; i < 40; i++) 			// Checks for reserved
	    if(token == pun[i])   {			//  words
    	        tmp = true;
    	        break;
	    }
	    if(tmp) 				        // If res word found,
	        type = Reserved_Word(i);		//  set type
	    else   {
	        if(token == "##")
	            type = Flag;
    	    	else if(isdigit(token[0]))
    	       	    type = token.find('.') != string::npos ? Real : Integer;
	        else if(isalpha(token[0]))		// Set as identifier
	            type = Identifier;
	    }
    }
}

void Token::clearComment(string typ)   {
  //******************************************************************
  // When a comment is found, this function grabs the whole comment
  //  and checks for errors.  An error occures when a mulit comment
  //  tag is not closed.  If an error is found, then error is set
  //  to true
  //******************************************************************
    if(typ == "/*")   {			// Mulit comment tag check
    	int i = ptr + 2;
    	while((buffer[i] != '*' || buffer[i + 1] != '/') && infile)   {
    	    i++;	// Passes all input after until
    	    if(i >= endPtr)   {	//  end of file or close comment
    	        i = 0; ptr = 0; line++;	//  is found
    	        getline(infile, buffer);
		if(flags.test(1))
		    executeDebugFlag(1);
    	    }
    	}
    	ptr += (i + 2);
    	if(!infile)   {				// Checks for unterminated comm
    	    col = 1;
    	    error = true;
    	}
    }
}

void Token::setFlag()   {
  //******************************************************************
  // When a flag token is found, this function will set all the flags
  //  found between the flag tags and then grab the next available
  //  token for the user
  //******************************************************************
    bool fstate;        // true = + : false = -
    Next_Token();

    while(type != Flag)   {
	if(type != Minus || type != Plus)   {
            Next_Token();
	    continue;
	}
        fstate = type == Minus ? false : true;
        Next_Token();
        if(fstate)
            flags.set(atoi(token.c_str()));
        else
            flags.reset(atoi(token.c_str()));
        Next_Token();
    }
}
void Token::executeDebugFlag(int i)   {
  //******************************************************************
  // If a flag is set, the tokenizer will call this function based on
  //  checks set throughout the code and execute the required flag.
  //******************************************************************
    switch(i)   {
	case 1:
	    cout << "Source Line :" << line << ":" << endl;
	    cout << buffer << endl;
	    break;
	case 3:
	    cout << "Lexical Token : " << token << endl;
	    break;
        case 5:
            printFsaTable();
	    break;
    }
}

void Token::printFsaTable()   {
  //******************************************************************
  // This function simply prints the FSA table for this grammer to the
  // screen upon termination of file being read.
  //******************************************************************

}
