#!/usr/bin/perl
# Names:	Nell Beatty, A+++ Perl Programmer 
#		Leonard Holman, C+++++ Programmer
# Email:	nbeatty@cs.clemson.edu
#		ldholma@cs.clemson.edu
# Date:		04/25/03
#
# Description: Code Generator that takes tuples from our parser and produces
# Sparc Assembly language, which can then be compiled into machine code
# This program meets the baseline of adding 2 numbers, sorting a list viat
# The Bubble Sort Algorithm.  We then additionally did recursion, matrices,
# floating point, static scoping, pass by reference, procedures, and pass by 
# value.  We are glad this project is done, and we really hope not to take the exam


$skipme=0;
$matrix=0;
$matrixoffset=0;
$printflag=0;
$matrixcols=0;
$matrixrows=0;
$frecursion = 0;
$testrecursion = 0;
$floatprint =0;
$haveproc=0;
$procname1="";
$eatingproc=0;
$reftype=0;
$static=0;
$floatver=0;
  # register stuff
  $freeregister = 1234567;
  $floatfreeregister = 2468;
  $registercontents[7];
  $floatregistercontents[4];
  for($i=1;$i<=7;$i++){
    $registercontents[$i]=0;
  }
  for($i=1;$i<=4;$i++){
    $floatregistercontents[$i]=0;
  }
if(open(FILE, "+tuple.txt")){
 if (open(OUT, ">draft.s"))  {
open(FILE1, "+tuple.txt");
 open(OUT1, ">draft.txt");
  open(FILE2, "+tuple.txt");
  @findflag= <FILE2>;
  foreach $searchtuple (@findflag){
	@parts = split ',', $searchtuple;
	$counter=0;
	$firstpiece = $parts[0];
	@subparts = split '\(', $firstpiece;
	$firstpiece = $subparts[1];
	$secondpiece = $parts[1];
	$thirdpiece = $parts[2];
	@subparts = split '\ ', $thirdpiece;
	$thirdpiece = $subparts[1];
	$fourthpiece = $parts[3];
	@subparts = split '\)', $fourthpiece;
	$fourthpiece = $subparts[0];
	@subparts = split '\ ', $fourthpiece;
	$fourthpiece = $subparts[1];
	if($secondpiece eq " BEGINPROC"){
	 	$testrecursion = 1;
		$procname = $firstpiece;
	}
	elsif($secondpiece eq " ENDPROC"){
		$testrecursion=0;
	}
	elsif($secondpiece eq " SUBASSIGN"){
	   if($thirdpiece =~ /\d+\.\d+/){
		print OUT "$firstpiece"."_m: .single 0r$thirdpiece\n";
		$floatprint =1;
	   }
	}
	elsif($secondpiece eq " CALL"){
	   if($thirdpiece eq "OUTPUT"){
		$printflag=0;
	   }
	   else{
		if($testrecursion==1){
		$procname1 =$firstpiece;
		if($procname eq $procname1){
			$frecursion =1;
		}
	        else{
			$frecursion = 0;
		}
		}
	   }
	}
}
  @findproc= <FILE1>;
  foreach $tuple (@findproc){
	@parts = split ',', $tuple;
	$counter=0;
	$firstpiece = $parts[0];
	@subparts = split '\(', $firstpiece;
	$firstpiece = $subparts[1];
	$secondpiece = $parts[1];
	$thirdpiece = $parts[2];
	@subparts = split '\ ', $thirdpiece;
	$thirdpiece = $subparts[1];
	$fourthpiece = $parts[3];
	@subparts = split '\)', $fourthpiece;
	$fourthpiece = $subparts[0];
	@subparts = split '\ ', $fourthpiece;
	$fourthpiece = $subparts[1];
	if($secondpiece eq " BEGINPROC"){
	   $eatingproc =1;
		$procname = $firstpiece;
		$haveproc = 1;
	}
           if($eatingproc ==1){	
	if($secondpiece eq " SUBASSIGN"){
	   if($thirdpiece =~ /\d+\.\d+/){
		print OUT1 "$firstpiece"."_m: .single 0r$thirdpiece\n";
		$floatprint =1;
	   }
	   elsif($thirdpiece =~ /^\d+/ && $haveproc ==1){
	      if($fourthpiece eq '-'){
	         for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $firstpiece){
	         	if($reftype==0){
			$actregister = "l" . $i;
			}
			else{
			$actregister = "g" . $i;
			}
			$ldinstruction = "set";
			$ldoperands = "$thirdpiece, %";
			$ldoperands = $ldoperands . $actregister;
			print OUT1 "$ldinstruction  $ldoperands\n\t";
		     }
		  }
	      }
	   }
	   elsif($fourthpiece eq '-'){
		if($static==0){
	         for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $firstpiece){
	         	if($reftype==0){
			$ldoperand1 = "%l" . $i;
 			}
			else{
			$ldoperand1 = "%g" . $i;
			}
			$ldinstruction = "mov";
		     }
		  }
	         for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $thirdpiece){
	                if($reftype==0){
			$ldoperand2 = "%l" . $i;
			}
			else{
			$ldoperand2 = "%g" . $i;
			}
		     }
		  }
	          print OUT1 "$ldinstruction\t  $ldoperand2, $ldoperand1\n\t";
	   }
	   else{
	         for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $firstpiece){
			$ldoperand1 = "%g" . $i;
			$ldinstruction = "mov";
		     }
		  }
	         for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $thirdpiece){
	                if($reftype==0){
			$ldoperand2 = "%l" . $i;
			}
			else{
			$ldoperand2 = "%g" . $i;
			}
		     }
		  }
	          print OUT1 "$ldinstruction\t  $ldoperand2, $ldoperand1\n\t";
	   }
	   }
 
 	
	}
	elsif($secondpiece eq " BEGINPARAM"){
		$paramcounter=1;
	}
	elsif($secondpiece eq " PARAM"){
	  if($thirdpiece eq "VALUE"){
	    if($fourthpiece == 1) { #scalar
	       $myreg = chop($freeregister);
	       $registercontents[$myreg]=$firstpiece;
	    }
	 
	    print OUT1 "mov\t %i$paramcounter, %l$myreg\n\t"; 
		$paramcounter++;
		$reftype=0;
	    }
	    else{
		#REFERENCE
		$reftype=1;
            }
	}
	elsif($secondpiece eq " NOPARAMS"){
	}
	elsif($secondpiece eq " ENDPARAMS"){
	}
	elsif($secondpiece eq " MEMORY"){
	    if($fourthpiece == 0) { #scalar
	       $myreg = chop($freeregister);
	       $registercontents[$myreg]=$firstpiece;
	    }
	}
	elsif($secondpiece eq " MEMORYSTATIC"){
	   if($static==0){
	   $static=1;

	    if($fourthpiece == 0) { #scalar
	       $myreg = chop($freeregister);
	       $registercontents[$myreg]=$firstpiece;
	    }
	   }
 	    
	}
	elsif($secondpiece eq " LESSEQUAL"){
	   #need to find register for thirdpiece
	   for($i=1;$i<=7;$i++){
	      if($registercontents[$i] eq $thirdpiece){
	         if($reftype==0){
	   	 $operand1="%l".$i;
		 }
		 else{
	   	 $operand1="%g".$i;
		 }
	      }
	   }
			

	   #need to find register for fourthpiece
	   if($fourthpiece =~ /^\d/){
	       $myreg = chop($freeregister);
	       $registercontents[$myreg]=$firstpiece;
	         if($reftype==0){
		 $operand2="%l".$myreg;
		 }
		 else{
		 $operand2="%g".$myreg;
		 }
		 print OUT1 "set\t $fourthpiece, $operand2\n\t";
	   }

	   #assembly instruction cmp  %g1, %g2
	   #assembly instruction subcc %g1, <what>, %g0
	   print OUT1 "cmp   $operand2, $operand1\n\t";
	
	   #set branch type
	   $brinstruction = "ble";

	   #add back intermediate result register
	   if($thirdpiece =~ /^I/){
	      $freeregister = $freeregister . chop($operand1);
	    }

	    if($fourthpiece =~ /^I/){
	       $freeregister = $freeregister . chop($operand2);
	     }
	}
	elsif($secondpiece eq " CJUMP"){
	   print OUT1 "$brinstruction $firstpiece\n\t";
	   print OUT1 "nop\n\t";
	}
	elsif($secondpiece eq " CALL"){
	   if($thirdpiece eq "OUTPUT"){
		$printflag=1;
	   }
	   else{
		$procname1 =$firstpiece;
		if($procname eq $procname1){
			$recursion =1;
		}
	        else{
			$recursion = 0;
		}
	   }
	}
	elsif($secondpiece eq " ACTUALPARAMS"){
	   if($printflag == 1){
	   print OUT1 "sethi   %hi(.LLC0), %o0\n\t";
	   print OUT1 "or     %o0, %lo(.LLC0), %o0\n\t";
	   $movinstruction = "mov  ";
	   $outregister =" ,%o1";
	   for($i=1;$i<=7;$i++){
	       if($registercontents[$i] eq $thirdpiece){
	         if($reftype==0){
		   $operand1="%l".$i;
		 }
		 else{
		   $operand1="%g".$i;
		 }
		 if($static==1){
		   $operand1="%g".$i;
		 }
	       }
	    }	
	    if($reftype==0){
	       if($recursion==1||$frecursion==1){
            $operand1 = "%i1";
		}
	    $outregister = ", %o1";	
            }
	    else{
	    }
	    print OUT1 $movinstruction .$operand1 . $outregister . "\n\t";
	    print OUT1 "call   printf\n\t";
	    print OUT1 "nop   \n\t";
	    print OUT1 "sethi   %hi(.LLC1), %o0\n\t";
	    print OUT1 "or     %o0, %lo(.LLC1), %o0\n\t";
	    print OUT1 "call   printf\n\t";
	    print OUT1 "nop   \n";
	    if($thirdpiece =~ /^I\$/){
	       	 $freeregister = $freeregister . chop($operand1);
	    }
	    }
	    else{
	     for($i=1;$i<=7;$i++){
		 if($registercontents[$i] eq $thirdpiece){
			if($reftype==0){
			$operand1="%l".$i;
			}
			else{
			$operand1="%g".$i;
			}
		 }
	      }
	      
	      if($reftype==0){
	      print OUT1 "mov\t $operand1, %o0\n\t";	
		}
               
		print OUT1 "call $procname1\n\t";
		print OUT1 "nop\n\t";	
	    }
	}
	elsif($secondpiece eq " BEGINACTUALPARAMS"){
	}
	elsif($secondpiece eq " ENDACTUALPARAMS"){
		$printflag=0;
	}
	elsif($secondpiece eq " ADD"){
	   #find thirpiece & fourhtpiece in register-land
	   if($thirdpiece =~ /^\d/){
 	      $operand1 = $thirdpiece;
           }
	   else{
	     for($i=1;$i<=7;$i++){
		if($registercontents[$i] eq $thirdpiece){
	         if($reftype==0){
		   $operand1="%l".$i;
		 }
		 else{
		   $operand1="%g".$i;
		 }
		}
	     }
	   }		
	
	   if($fourthpiece =~ /^\d/){
 	 	$operand2 = $fourthpiece;
            }
	    else{
		for($i=1;$i<=7;$i++){
		   if($registercontents[$i] eq $fourthpiece){
	             if($reftype==0){
		      $operand2="%l".$i;
		     }
  		     else{
		      $operand2="%g".$i;
		     }
		   }
		}
	    }

	    #find free register for firstpiece
	    $myreg = chop($freeregister);
	    $registercontents[$myreg]=$firstpiece;
	    #construct Add assembly insturction
	    if($frecursion==0){
  	    print OUT1 "add\t";
	             if($reftype==0){
	    print OUT1 $operand2 .", $operand1, %l$myreg\n\t";
			}
		      else{
	    print OUT1 $operand2 .", $operand1, %g$myreg\n\t";
		     }
	    }
	    else{ 
	    print OUT1 "set\t 1, %l1\n\t";
	    $operand1 ="%i1";
            $operand2 ="%l1"; 
  	    print OUT1 "add\t";
            print OUT1 $operand2 .", $operand1, %o1\n\t";
	    }
	}
	elsif($secondpiece eq " LABEL"){
	   #if($skipme==0){
  	      print OUT1 "$firstpiece:\n\t";
           #}
	   #else{
           #   $skipme=0;
           #}
	}
	elsif($secondpiece eq " ENDPROC"){
		$procname1 ="";
		$eatingproc =0;
		print OUT1 "ret\n\t";
		print OUT1 "restore\n\t";
		print OUT1 "."."LLfe2:\n\t";
		print OUT1 ".size   add,.LLfe2-add\n\t";
		print OUT1 ".section\t". '"'.".rodata".'"'."\n\t";
		print OUT1 ".align 8\n";
		close(OUT1);
  # register stuff
  if($static==0){
  $freeregister = 1234567;
  $floatfreeregister = 2468;
  $registercontents[7];
  $floatregistercontents[4];
  for($i=1;$i<=7;$i++){
    $registercontents[$i]=0;
  }
  for($i=1;$i<=4;$i++){
    $floatregistercontents[$i]=0;
  }
  }
	}
  }
  }
  $header1 = '"';
  $header1 = $header1 . "add.c";
  $header1 = $header1 . '"';
  print OUT "\t";
  print OUT ".file\t" . $header1 . "\n\t";
  if($haveproc==0){
     print OUT ".global   .mul\n\t";
  }
  else{
    print OUT ".global    $procname\n\t";
    print OUT ".type      $procname,#function\n\t";
    print OUT ".proc      04\n\t";
  }
  $header2 = '"';
  $header2 = $header2 . ".rodata";
  $header2 = $header2 . '"';
  print OUT ".section\t" . $header2 ."\n\t";
  print OUT ".align 8\n";
  if($haveproc==1){
		print OUT "$procname:\n\t";
  print OUT "!#PROLOGUE# 0\n\t";
  print OUT "save    %sp, -128, %sp\n\t";
  print OUT "!#PROLOGUE# 1\n\t";
  open(FILE2, "+draft.txt");
  @hlines = <FILE2>;
  foreach $hline (@hlines){
    print OUT "$hline"; 
  }
	
  }
  print OUT ".LLC0:\n\t";
  $header4 = '"';
  if($floatprint == 0){
  $header4 = $header4 . "%d";
  }
  else{
  $header4 = $header4 . "%f";
  }
  $header4 = $header4 . '"';
  print OUT ".asciz\t" . $header4 ."\n\t";
  $header3 = '"';
  $header3 = $header3 . ".text";
  $header3 = $header3 . '"';
  print OUT ".section\t" . $header3 ."\n\t";
  print OUT ".align 4\n";
  print OUT ".LLC1:\n\t";
  $header4 = '"';
  $header5 =  '\\';
  $header6 =  'n';
  print OUT ".asciz\t" . $header4 . $header5 . $header6 . $header4 ."\n\t";
  $header3 = '"';
  $header3 = $header3 . ".text";
  $header3 = $header3 . '"';
  print OUT ".section\t" . $header3 ."\n\t";
  print OUT ".align 4\n\t";
  print OUT ".global " . "main" . "\n\t";
  print OUT ".type   ". "main"  .",#function\n\t";
  print OUT ".proc   04\n";
  print OUT "main:\n\t";
  print OUT "!#PROLOGUE# 0\n\t";
  print OUT "save    %sp, -128, %sp\n\t";
  print OUT "!#PROLOGUE# 1\n\t";


  @lines = <FILE>;
  foreach $line (@lines){
    if($line =~ /[^\n]/) {
     if($line =~ /^\(/){
	@parts = split ',', $line;
	$counter=0;
	$firstpiece = $parts[0];
	@subparts = split '\(', $firstpiece;
	$firstpiece = $subparts[1];
	$secondpiece = $parts[1];
	$thirdpiece = $parts[2];
	@subparts = split '\ ', $thirdpiece;
	$thirdpiece = $subparts[1];
	$fourthpiece = $parts[3];
	@subparts = split '\)', $fourthpiece;
	$fourthpiece = $subparts[0];
	@subparts = split '\ ', $fourthpiece;
	$fourthpiece = $subparts[1];
	if($secondpiece eq " BEGINPROGRAM"){
            $skipme=1;
	}
	elsif($secondpiece eq " LABEL"){
	   if($skipme==0){
  	      print OUT "$firstpiece:\n\t";
           }
	   else{
              $skipme=0;
           }
	}
	elsif($secondpiece eq " NOPARAMS"){
	  if($eatingproc==0){
		print OUT "call $procname\n\t";
		print OUT "nop\n\t";	
	}
	}
	elsif($secondpiece eq " ENDPARAMS"){
	}
	elsif($secondpiece eq " BEGINPARAM"){
	}
	elsif($secondpiece eq " JUMP"){
	}
	elsif($secondpiece eq " EQUALEQUAL"){
	}
	elsif($secondpiece eq " EQUAL"){
	}
	elsif($secondpiece eq " GREATER"){
	}
	elsif($secondpiece eq " PARAM"){
	}
	elsif($secondpiece eq " LESSEQUAL"){
	  if($eatingproc==0){
	   #need to find register for thirdpiece
	   for($i=1;$i<=7;$i++){
	      if($registercontents[$i] eq $thirdpiece){
	   	 $operand1="%l".$i;
	      }
	   }
			

	   #need to find register for fourthpiece
	   if($fourthpiece =~ /^\d/){
	       $myreg = chop($freeregister);
	       $registercontents[$myreg]=$firstpiece;
		 $operand2="%l".$myreg;
		 print OUT1 "set\t $fourthpiece, $operand2\n\t";
	   }

	   #assembly instruction cmp  %g1, %g2
	   #assembly instruction subcc %g1, <what>, %g0
	   print OUT1 "cmp   $operand1, $operand2\n\t";
	
	   #set branch type
	   $brinstruction = "ble";

	   #add back intermediate result register
	   if($thirdpiece =~ /^I/){
	      $freeregister = $freeregister . chop($operand1);
	    }

	    if($fourthpiece =~ /^I/){
	       $freeregister = $freeregister . chop($operand2);
	     }
		
	}
	}
	elsif($secondpiece eq " LESS"){
	   #need to find register for thirdpiece
	   for($i=1;$i<=7;$i++){
	      if($registercontents[$i] eq $thirdpiece){
	   	 $operand1="%g".$i;
	      }
	   }
			

	   #need to find register for fourthpiece
	   for($i=1;$i<=7;$i++){
	      if($registercontents[$i] eq $fourthpiece){
		 $operand2="%g".$i;
	       }
	   }

	   #assembly instruction cmp  %g1, %g2
	   #assembly instruction subcc %g1, <what>, %g0
	   print OUT "cmp   $operand1, $operand2\n\t";
	
	   #set branch type
	   $brinstruction = "bl";

	   #add back intermediate result register
	   if($thirdpiece =~ /^I/){
	      $freeregister = $freeregister . chop($operand1);
	    }

	    if($fourthpiece =~ /^I/){
	       $freeregister = $freeregister . chop($operand2);
	    }
	}
	elsif($secondpiece eq " CJUMP"){
	  if($eatingproc==0){
	   print OUT "$brinstruction $firstpiece\n\t";
	   print OUT "nop\n\t";
          }
	}
	elsif($secondpiece eq " ENDPROGRAM"){
	}
	elsif($secondpiece eq " CALL"){
	   if($thirdpiece eq "OUTPUT"){
		$printflag=1;
	   }
	   elsif($firstpiece ne '-'){
		$procname =$firstpiece;
	   }
	}
	elsif($secondpiece eq " ITOR"){
	}
	elsif($secondpiece eq " ADD"){
	   if($eatingproc==0){
	   #find thirpiece & fourhtpiece in register-land
	   if($thirdpiece =~ /^\d/){
 	      $operand1 = $thirdpiece;
           }
	   else{
	     for($i=1;$i<=7;$i++){
		if($registercontents[$i] eq $thirdpiece){
		   $operand1="%g".$i;
		}
	     }
	   }		
	
	   if($fourthpiece =~ /^\d/){
 	 	$operand2 = $fourthpiece;
            }
	    else{
		for($i=1;$i<=7;$i++){
		   if($registercontents[$i] eq $fourthpiece){
		      $operand2="%g".$i;
		   }
		}
	    }

	    #find free register for firstpiece
	   if($firstpiece =~ /^\I/){
	    $myreg = chop($freeregister);
	    $registercontents[$myreg]=$firstpiece;
            }
	    else{
		for($i=1;$i<=7;$i++){
		   if($registercontents[$i] eq $firstpiece){
		      $operand2="%g".$i;
		   }
		}
	    }
	    #construct Add assembly insturction
  	    print OUT "add\t";
	    print OUT $operand2 .", $operand1, %g$myreg\n\t";
           }
	}
	elsif($secondpiece eq " MEMORY"){
	   if($eatingproc==0){
	   #check register to see if there
	   for($i=1;$i<=7;$i++){
	      if($registercontents[$i] eq $firstpiece){
		 print "ERROR!!!!!!!!!!!!    DOUBLE VAR USAGE\n";
	      }
	    }
				
	    #if not, there find free register & add it in	
	    #first, we need to see if vector, matrix or scalar
	    if($fourthpiece == 0) { #scalar
	       $myreg = chop($freeregister);
	       $registercontents[$myreg]=$firstpiece;
	    }
	    else{
	        $size=$thirdpiece*$fourthpiece;
	        for($i=0;$i<$size;$i++){
		    $myreg=chop($freeregister);
		    $registercontents[$myreg]=$firstpiece . $i;
	        } 
		$matrixcols=$thirdpiece;
		$matrixrows=$fourthpiece;
	    }
           }
	}
	elsif($secondpiece eq " BEGINPROC"){
		$eatingproc =1;
	}
	elsif($secondpiece eq " ENDPROC"){
		$eatingproc =0;
	}
	elsif($secondpiece eq " SUBLOAD"){
	#assumption that anything getting here will be an array/matrix of somekind
	    if($matrix == 1){
	       $tempvar =$thirdpiece . $matrixoffset;
	      
	       $myreg=chop($freeregister);
		
	       $registercontents[$myreg]=$firstpiece;
	       for($i=1;$i<=7;$i++){
		   if($registercontents[$i] eq $tempvar){
			$actregister = "%g" . $i;
			$ldinstruction = "mov";
			$ldoperands = "%g$myreg";
			$ldoperands = $actregister . ", " .$ldoperands;
			print OUT "$ldinstruction  $ldoperands\n\t";
			$matrix = 0;
		   }
		  }
	}
	elsif($fourthpiece =~ /^\d/){
	   $tempfind = $thirdpiece . $fourthpiece;
	   $myreg=chop($freeregister);
	   $registercontents[$myreg]=$firstpiece;
	   for($i=1;$i<=7;$i++){
	       if($registercontents[$i] eq $tempfind){
		  $actregister = "%g" . $i;
		  $ldinstruction = "mov";
		  $ldoperands = "%g$myreg";
		  $ldoperands = $actregister . ", " .$ldoperands;
		  print OUT "$ldinstruction  $ldoperands\n\t";
		}
	    }
	  }
	}
	elsif($secondpiece eq " SUBASSIGN"){
	   #find firstpiece in register-land
	   #handle x=1, etc
	   if($eatingproc==1){
           }
	   elsif($thirdpiece =~ /^R/){
	   for($i=2;$i<=8;$i+=2){
		if($thirdpiece eq $floatregistercontents[(($i-($i/2))-1)]){
			$operand1="%f$i";
		}	
	   }
	   for($i=2;$i<=8;$i+=2){
		if($firstpiece eq $floatregistercontents[(($i-($i/2))-1)]){
			$operand2="%f$i";
		}	
	   }
	    $mvinst = "fmovs";
	    print OUT "$mvinst $operand1, $operand2\n\t";
	    print OUT "nop\n\t";
	   }
	   elsif($thirdpiece =~ /\d+\.\d+/){
	      $myreg =chop($floatfreeregister);
	      $floatregistercontents[(($myreg-($myreg/2))-1)]=$firstpiece;
	      $flldinstruction = "set";
	      print OUT $flldinstruction ."\t". $firstpiece ."_m, %l" . $myreg . "\n\t";
	      $flldinstruction = "ld";
	      print OUT $flldinstruction ."\t". "[%l" . $myreg ."], %f".$myreg. "\n\t";
	      	
			
	   }
	   elsif($matrix == 1){
	      if($thirdpiece =~ /^\d/){
	      $tempvar =$firstpiece . $matrixoffset;
	      for($i=1;$i<=7;$i++){
		if($registercontents[$i] eq $tempvar){
		   $actregister = "g" . $i;
		   $ldinstruction = "set";
		   $ldoperands = "$thirdpiece, %";
		   $ldoperands = $ldoperands . $actregister;
		   print OUT "$ldinstruction  $ldoperands\n\t";
		   $matrix = 0;
		}
	      }
	      }
	      else{
	         $tempvar =$firstpiece . $matrixoffset;
		      $ldinstruction = "mov";
	         for($i=1;$i<=7;$i++){
		   if($registercontents[$i] eq $tempvar){
		      $ldoperand1 = "g" . $i;
		}
	        }
	         for($i=1;$i<=7;$i++){
		   if($registercontents[$i] eq $thirdpiece){
		      $ldoperand2 = "g" . $i;
			$freeme =$i;
                   }
                 }
		      print OUT "$ldinstruction  %$ldoperand2, %$ldoperand1\n\t";
		      $matrix = 0;
		if($thirdpiece =~ /^I/){
		 $Itest =chop($thirdpiece);
		 if($Itest != 0){
		 $freeregister = $freeregister . $freeme;
		 }
		}
	
	      }
	   }
	   elsif($thirdpiece =~ /^\d/){
	      if($fourthpiece eq '-'){
	         for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $firstpiece){
			$actregister = "g" . $i;
			$ldinstruction = "set";
			$ldoperands = "$thirdpiece, %";
			$ldoperands = $ldoperands . $actregister;
			print OUT "$ldinstruction  $ldoperands\n\t";
		     }
		  }
	      }
	      else {#matches fourthpiece if
		 $tempregname = $firstpiece . $fourthpiece;
		 $createme=1;
		 for($i=1;$i<=7;$i++){
		     if($registercontents[$i] eq $tempregname){
			$actregister = "g" . $i;
			$ldinstruction = "set";
			$ldoperands = "$thirdpiece, %";
			$ldoperands = $ldoperands . $actregister;
			print OUT "$ldinstruction  $ldoperands\n\t";
			$createme=0;
		     }
		 }
		 if($createme==1){
		    $newreg =chop($freeregister);
		    $registercontents[$newreg]=$tempregname;
		    $actregister = "g" . $newreg;
		    $ldinstruction = "set";
		    $ldoperands = "$thirdpiece, %";
		    $ldoperands = $ldoperands . $actregister;
		    print OUT "$ldinstruction  $ldoperands\n\t";
		 }
	     }
	}
	else { #matches thirdpiece if
	  if($fourthpiece eq '-'){
	     for($i=1;$i<=7;$i++){
		if($registercontents[$i] eq $firstpiece){
			$actregister = "g" . $i;
			$ldinstruction = "mov";
			$ldoperand1 = "%";
			$ldoperand1 = $ldoperand1 . $actregister;
		}
	 }
	 for($i=1;$i<=7;$i++){
	     if($registercontents[$i] eq $thirdpiece){
		$actregister = "g" . $i;
		$ldinstruction = "mov";
		$ldoperand2 = "%";
		$ldoperand2 = $ldoperand2 . $actregister;
		if($thirdpiece =~ /^I/){
		 $freeregister = $freeregister . $i;
		}
	     }
	  }
	 }
	 else{
	    $tempregname = $firstpiece . $fourthpiece;
	    for($i=1;$i<=7;$i++){
	        if($registercontents[$i] eq $tempregname){
		   $actregister = "g" . $i;
		   $ldoperand1 = "%".$actregister;
		 }
	     }
	     for($i=1;$i<=7;$i++){
	         if($registercontents[$i] eq $thirdpiece){
			$actregister = "g" . $i;
			$ldinstruction = "mov";
			$ldoperand2 = "%";
			$ldoperand2 = $ldoperand2 . $actregister;
			if($thirdpiece =~ /^I/){
			 $freeregister = $freeregister . $i;
	 		}
		  }
	        }
	}
	print OUT "$ldinstruction $ldoperand2, $ldoperand1\n\t";
	}
			#load thirdpiece as value
	$matrixoffset = 0;
	}
	elsif($secondpiece eq " MULT"){
			$ifloat=0;
	   for($i=2;$i<=8;$i+=2){
		if($thirdpiece eq $floatregistercontents[(($i-($i/2))-1)]){
			$ifloat=1;
			$operand1="%f$i";
		}	
	   }
	 
	   if($ifloat==1){
	   for($i=2;$i<=8;$i+=2){
		if($fourthpiece eq $floatregistercontents[(($i-($i/2))-1)]){
		   	$operand2="%f$i";
		}	
	   }
	   $myreg = chop($floatfreeregister);
	   $floatregistercontents[(($myreg-($myreg/2))-1)]=$firstpiece;
		   	$operand3="%f$myreg";
	    $mulinst = "fmuls";	
	    print OUT "$mulinst\t $operand1,$operand2, $operand3\n\t";
	    print OUT "nop\n\t";
	   }
           else{
	   #find thirpiece & fourhtpiece in register-land
	   if($thirdpiece =~ /^\d/){
 	 	$operand1 = $thirdpiece;
		print OUT "set   $thirdpiece, %o0\n\t";
           }
	   else{
		for($i=1;$i<=7;$i++){
		    if($registercontents[$i] eq $thirdpiece){
		       $operand1="%g".$i;
		       $freeme =$i;
		    }
		}
		print OUT "mov    $operand1, %o0\n\t";
           }
			if($thirdpiece =~ /^I/){
			 $freeregister = $freeregister . $freeme;
	 		}
			
	   if($fourthpiece =~ /^\d/){
 	 	$operand2 = $fourthpiece;
           }
	   else{
	     for($i=1;$i<=7;$i++){
		 if($registercontents[$i] eq $fourthpiece){
			$operand2="%g".$i;
		 }
	      }
           }
		print OUT "mov    $operand2, %o1\n\t";
	   #find free register for firstpiece
	   $myreg = chop($freeregister);
	   $registercontents[$myreg]=$firstpiece;
	   #construct MULTI assembly insturction
	   print OUT "call\t .mul\n\t";
	   print OUT "nop\n\t";
	   print OUT "mov\t %o0, %g$myreg\n\t";
  	   #print OUT "mul\t";
	   #print OUT $operand2 .", $operand1, %g$myreg\n\t";
	   }
	}
	elsif($secondpiece eq " MULTI"){
		$matrix = 1;
		$matrixoffset = $thirdpiece * $fourthpiece;
		
	}
	elsif($secondpiece eq " ADDI"){
		$matrixoffset = $matrixoffset + $fourthpiece;
		
	}
	elsif($secondpiece eq " ACTUALPARAMS"){
	  if($eatingproc==0){
	   if($haveproc==1 && $printflag==0){
	     for($i=1;$i<=7;$i++){
		 if($registercontents[$i] eq $thirdpiece){
			$operand1="%g".$i;
		 }
	      }
	      print OUT "mov\t $operand1, %o1\n\t";	
		print OUT "call $procname\n\t";
		print OUT "nop\n\t";	
	   }
	   elsif($printflag == 1){
	      if($eatingproc==0){
			$ifloat=0;
	   for($i=2;$i<=8;$i+=2){
		if($thirdpiece eq $floatregistercontents[(($i-($i/2))-1)]){
			$ifloat=1;
			$operand1="%f$i";
		}	
	   }
           
		
	   print OUT "sethi   %hi(.LLC0), %o0\n\t";
	   print OUT "or     %o0, %lo(.LLC0), %o0\n\t";
		if($ifloat == 1){
		 print OUT "std\t" .$operand1 .", [%sp+88]\n\t";	
		 print OUT "ld\t" ."[%sp+88], %o1\n\t";	
		}
		else{
	   $movinstruction = "mov  ";
	   $outregister =" ,%o1";
	   for($i=1;$i<=7;$i++){
	       if($registercontents[$i] eq $thirdpiece){
		   $operand1="%g".$i;
	       }
	    }	
	    print OUT $movinstruction .$operand1 . $outregister . "\n\t";
	    }
	    print OUT "call   printf\n\t";
	    print OUT "nop   \n\t";
	    print OUT "sethi   %hi(.LLC1), %o0\n\t";
	    print OUT "or     %o0, %lo(.LLC1), %o0\n\t";
	    print OUT "call   printf\n\t";
	    print OUT "nop   \n\t";
	    if($thirdpiece =~ /^I/){
		 $Itest =chop($thirdpiece);
		 if($Itest != 0){
	       	 $freeregister = $freeregister . chop($operand1);
	    }
	    }
	  }	
	  }	
	  }	
	}
	elsif($secondpiece eq " BEGINACTUALPARAMS"){
	}
	elsif($secondpiece eq " ENDACTUALPARAMS"){
		$printflag=0;
	}
	elsif($secondpiece eq " DIV"){
	}
	elsif($secondpiece eq " SUB"){
	}
	else {
	}
       }
     }
   }
  print OUT "nop\n\t";
  print OUT "ret\n\t";
  print OUT "restore\n";
  print OUT ".LLfe1:\n\t";
  print OUT ".size   main,.LLfe1-main\n\t";
  $header3 = '"';
  $header3 = $header3 . "GCC:  (GNU)  3.2.1";
  $header3 = $header3 . '"';
  print OUT ".ident\t" . $header3 .  "\t\n";

 }
 else {
    print "ERROR \n";
   }
   #close files
 close(FILE);
 close(OUT);
}


