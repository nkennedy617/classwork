#!/usr/bin/perl

$test = 25;

if($test =~/\d+\.\d+/){
	print "FLOAT\n";
}
