#include <stdio.h>

int main(){

	float a;
	float b;
	int c;

	a=0.9;
	b=12.1;
	
	c=a+b;
	
	printf("%f",c);
}
