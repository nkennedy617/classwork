#include <stdio.h>

int main(){

	int a[5];
	int x=0,i=0,j=0;
	a[0]=3;
	a[1]=10;
	a[2]=25;
	a[3]=4;
	a[4]=2;

        while(i<4){
	  while(j<4-i){
		if(a[j+1]<a[j]){
			x=a[j];
			a[j]=a[j+1];
			a[j+1]=x;
		}
		j++;
	  }
		i++;
		j=0;
	}

	for(i=0;i<5;i++){
		printf("%d\n", a[i]);
	}
}
