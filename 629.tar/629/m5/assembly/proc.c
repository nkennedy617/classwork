#include <stdio.h>


int add(int a){
	int b;
	int c;
	b=12;
	c=a+b;
	return c;

}
int main(){

	int a;

	a=0;
        a=add(a);	
	printf("%d",a);
}
