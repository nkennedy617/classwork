#include <stdio.h>

int main(){

	int a;
	int b;
	int c;

	a=0;
	b=12;
	
	c=a<b;
	
}
