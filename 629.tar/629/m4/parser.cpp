#include "parser.h"

void Parser::startSemantics()   {
    if(token.Token_Error())
        return;
    start();                                // ADDED FOR PROG3
    string tmp = sStack[0];
    while(!pStack.empty())
        reduceStack();
    if(token.flags.test(16))
        printST(0, tmp);
}

void Parser::start()   {
  //****************************************************************************
  // This function starts the parser, check for syntatically correctness
  //****************************************************************************
string Token_List[50] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                  "]", ":", ";", "<", ",", ">", "/", "==", "!=", "<=",
                  ">=", "<-", "||", "&&", "/*", "*/", "END", "PROGRAM",
                  "DECLARE", "INTEGER", "REAL", "PROCEDURE", "VALUE",
                  "REFERENCE", "COMPUTE", "INPUT", "OUTPUT", "CALL", "IF",
                  "ELSE", "THEN", "WHILE", "DO", "var", "integer",
                  "real", "Punctuation", "Error", "Flag", "end_of_file"};
    token.Next_Token();                     // Starts parser going

    while(!token.Token_Error())   {
	if(Token_List[token.Type()] == "end_of_file")  
		break;
        string temp = Token_List[token.Type()];
        if(pStack.empty())   {              // Case for first Item on Stack
    	    if(checkGrammar(temp))   {          // Error Check
    	        //pStack.push(stkStrct(temp, LES));
    	        pStack.push_back(stkStrct(temp, LES));
                sStack.push_back(token.Text());
            }
    	    else
               cout<<"\t\t***REDUCABILITY ERROR***" << endl;
  	        token.Next_Token();
  	        continue;
        }
	    if(!checkGrammar(temp))   {         // Token not in grammar
            cout << "\t\t***REDUCABILITY ERROR***" << endl;
            fixStack();
            continue;
	    }
if(temp == "IF")
nonL = true;
if(temp == "THEN")
nonL = false;
	    //string sTop = pStack.top().item;
	    string sTop = pStack[pStack.size() - 1].item;
	    if(token.flags.test(9))
    	    flagCall(9, temp, sTop);
        if(FGtable[sTop][F] > FGtable[temp][G])   {
        // Reduction process
            if(token.flags.test(8))
                flagCall(8, "before", "");
            if(token.flags.test(12))
                flagCall(12, "before", "");
    	    string tp = reduceStack();
//	        if(find(grammar.begin(), grammar.end(), tp) == grammar.end())  {
            if(!checkHandle(tp) || tp == "")   {
                cout << "\t\t***REDUCABILITY ERROR***" << endl;
                fixStack();
                continue;
	        }
            if(!pStack.empty())   {
    	        //sTop = pStack.top().item;
    	        sTop = pStack[pStack.size() - 1].item;
    	        if(FGtable[sTop][F] > FGtable[tp][G])   {
    	            cout << sTop << " : " << tp << endl;
    		        cout << "\t\t***STACKABILITY ERROR***" << endl;
    	    		fixStack();
    	    		continue;
    	        }
            }
            check c;
            if(!pStack.empty())   {
            	//sTop = pStack.top().item;
            	sTop = pStack[pStack.size() - 1].item;
            	c = FGtable[sTop][F]<FGtable[tp][G] ? LES : EQT;
          	}
            else
                c = LES;
            //pStack.push(stkStrct(tp , c));          // Reduced token pushed on
            pStack.push_back(stkStrct(tp , c));          // Reduced token pushed on
            //sTop = pStack.top().item;
            sTop = pStack[pStack.size() - 1].item;
            if(token.flags.test(8))
                flagCall(8, "after", "");
            if(token.flags.test(12))
                flagCall(12, "after", "");
            continue;
	    }
	    // New token is pushed on stack
        //pStack.push(stkStrct(temp,FGtable[sTop][F]<FGtable[temp][G]?LES:EQT));
        pStack.push_back(stkStrct(temp,FGtable[sTop][F]<FGtable[temp][G]?LES:EQT));
        sStack.push_back(token.Text());
        token.Next_Token();
    }
}

string Parser::reduceStack()   {
  //****************************************************************************
  // This function pops items off the stack until a less than equality is found
  //  meaning a complete RHS is found and is then returned.
  //****************************************************************************
    string temp;
    int numPops = 0;

// Here is where I think we should call the semantic part, sending it a pstack
// and I think we also need to send it grammar[temp]

    //while(!pStack.empty() && pStack.top().eq != LES)   {
    while(!pStack.empty() && pStack[pStack.size() - 1].eq != LES)   {
    	//temp.insert(0, pStack.top.item + " ");
    	temp.insert(0, pStack[pStack.size() - 1].item + " ");
    	//pStack.pop();
    	pStack.pop_back();
        numPops++;
    }
    if(!pStack.empty())   {
        //temp.insert(0, pStack.top().item + " ");
        temp.insert(0, pStack[pStack.size() - 1].item + " ");
        //pStack.pop();
        pStack.pop_back();
        numPops++;
    }
    if(temp[temp.length() - 1] == ' ')
        temp.erase(temp.length() - 1, 1);
    if(token.flags.test(7))    {
    	string t = "REDUCTION FROM STACK LHS = <" + grammar[temp];
    	t += "> RHS <" + temp + ">";
    //if(!pStack.empty()&&FGtable[pStack.top().item][F]>FGtable[grammar[temp]][G])
    if(!pStack.empty()&&FGtable[pStack[pStack.size() - 1].item][F]>FGtable[grammar[temp]][G])
    	    t = "REDUCTION FROM STACK NOT DONE,  STACKABILITY ERROR!";
        cout << setw(80) << t << endl;
    }
    if(token.flags.test(10))    {
        string t = "SYMBOLIC HANDLE = <" + temp + ">";
        cout << setw(80) << t << endl;
    }
    checkReduction(temp, grammar[temp], numPops - 1);
    return grammar[temp];
}

void Parser::fixStack()   {
  //****************************************************************************
  // This function is called when an error is found in the file.  All tokens
  //  are popped off until a less than eqaulity is found and then all tokens
  //  from the file are removed which correspond to the bad sentence.
  //****************************************************************************
    while(!token.Token_Error() && token.Text() != ";")
        token.Next_Token();
    if(!token.Token_Error())
        token.Next_Token();
    //while(!pStack.empty() && pStack.top().eq != LES)   {
    while(!pStack.empty() && pStack[pStack.size() - 1].eq != LES)   {
    	//pStack.pop();
    	pStack.pop_back();
    	sStack.pop_back();
    }
    //pStack.pop();
    pStack.pop_back();
  	sStack.pop_back();
}

void Parser::getFGTable(string table_file)   {
  //****************************************************************************
  // This function reads a file, filling the FGtable map structure with the
  //  simple precedence function values.
  //****************************************************************************
    ifstream infike(table_file.c_str());
    string temp;

    while(getline(infike, temp))   {
    	tableStruct tmp;
    	int sp1 = temp.find(' ') + 1;
    	int sp2 = temp.find_last_of(' ') + 1;
    	tmp[F] = atoi(temp.substr(sp1, sp2 - sp1 - 1).c_str());
    	tmp[G] = atoi(temp.substr(sp2, temp.length() - sp2).c_str());
    	FGtable[temp.substr(0, temp.find(' '))] = tmp;
    }
}

void Parser::getGrammar(string grammar_file)   {
  //****************************************************************************
  // This function reads a file, filling the grammar map structure with the
  //  corresponding grammar information.
  //****************************************************************************
    ifstream infike(grammar_file.c_str());
    string temp;

    while(getline(infike, temp))   {
    	int tmp = temp.find(' ');
	    grammar[temp.substr(tmp + 1, temp.length()-tmp)] = temp.substr(0, tmp);
    }
/*    cout <<"**********************************************"<<endl;
    Grammar::iterator it = grammar.begin();
    for(it; it != grammar.end(); ++it)
        cout <<"|"<<it->first << "| --> |" << it->second << "|"<<endl;
    cout <<"**********************************************"<<endl; */
}

bool Parser::checkGrammar(string token)   {
  //****************************************************************************
  // This function checks if the passed in token is in the FGTable.
  //****************************************************************************
    return FGtable.find(token) == FGtable.end() ? false : true;
}

bool Parser::checkHandle(string temp)   {
  //****************************************************************************
  // This function checks if the passed in token is in the grammar.
  //****************************************************************************
    Grammar::iterator it = grammar.begin();
    for(it; it != grammar.end(); ++it)
        if(it->second == temp)
            return true;
    return false;
}

void Parser::flagCall(int i, string temp, string temp2)   {
  //****************************************************************************
  // This function handles parser flags found in the file.
  //****************************************************************************
    string t;
    switch(i)   {
        case 8:
            if(temp == "before")
                cout << setw(80) << "==Parse Stack Before Reduction===" << endl;
            else
                cout << setw(80) << "==Parse Stack After Reduction===" << endl;
            printStack();
            break;
        case 9:
            if(token.flags.test(9))   {
                //string t = "Top of Stack <" + pStack.top().item;
                string t = "Top of Stack <" + pStack[pStack.size() - 1].item;
                t += ">  Input Symbol <" + temp + ">  Relation <";
                if(FGtable[temp2][G] > FGtable[temp][F])
                    t += "Greater Than>";
                else if(FGtable[temp2][G] == FGtable[temp][F])
                    t += "Equal To>";
                else
                    t += "Less Than>";
                cout << setw(80) << t << endl;
            }
            break;
        case 12:
            if(temp == "before")
                cout <<setw(80)<<"==Semantic Stack Before Reduction===" << endl;
            else
                cout << setw(80)<<"==Semantic Stack After Reduction===" << endl;
            printSemanticStack();
            break;
    }
}

void Parser::printStack()   {
  //****************************************************************************
  // THis function prints the current stack.
  //****************************************************************************
    //stack<stkStrct> temp(pStack);
    vector<stkStrct> temp(pStack);
    while(!temp.empty())   {
        //cout << setw(80) << temp.top().item << endl;
        cout << setw(80) << temp[temp.size() - 1].item << endl;
        //temp.pop();
        temp.pop_back();
    }
}

// ****************BEGIN OF SEMANIC STACK CODE**********************************

void Parser::printSemanticStack()   {
  //****************************************************************************
  // THis function prints the current stack.
  //****************************************************************************
    for(int i = sStack.size() - 1; i >= 0; i--)
        cout << setw(80) << sStack[i] << endl; //.print();
}

void Parser::checkReduction(string rhs, string lhs, int numPops)   {
//cout << "IN CHECKREDUCTION lhs<"<<lhs<<">   rhs<"<<rhs<<">"<< endl;
    if(lhs=="start")   {                // 1
        if(token.flags.test(13))   {
            printTuple(ST[j()][sStack[i(2)]]->STEntry,"ENDPROGRAM",
                "-", "-");
        }
        genTuple(ST[j()][sStack[i(2)]]->STEntry,"ENDPROGRAM",
                "-", "-");
        if(token.flags.test(15))
            ST[j()][sStack[i(2)]]->print();
    }
    else if(lhs=="prog")   {            // 2
        if(token.flags.test(17))   {
            cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
            cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS DECLARATION:"<<endl;
            if(checkST(sStack[i()], 0))   {
                cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                cout << "\tEND OF TRACE" << endl;
            }
        }
        if(checkST(sStack[i()], 0))   {
            cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :"<<sStack[i()]<<endl;
            popItems(numPops);
            return;
        }
        ST[j()][sStack[i()]] = new STElem(sStack[i()],
                "", "", "BEGINPROGRAM", "");
        genTuple(sStack[i()], "BEGINPROGRAM", "-", "-");
        sStack[i(1)] = sStack[i()];
        if(token.flags.test(17))   {
            cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
            cout<<"\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH CONTAINS:"<<endl;
            ST[j()][sStack[i()]]->print();
            cout << "\tEND OF TRACE" << endl;
        }
        if(token.flags.test(13))
            printTuple(sStack[i()], "BEGINPROGRAM", "-", "-");
        if(token.flags.test(15))
            ST[j()][sStack[i()]]->print();
    }
    else if(lhs=="body")   {                // 3, 4
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="declpart")   {            // 5
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="decllist")   {            // 6
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="decllist-")   {           // 7, 8
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="declstat")   {            // 9
        popItems(numPops);
     	return;                         // these are empty
    }
    else if(lhs=="declstat-")   {       // 10, 11, 12, 13, 14, 15, 16
        if(rhs == "declstat- , var")   {                        // 10
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            STElem tmp(*(ST[j()][sStack[i(2)]]));
            tmp.STEntry = sStack[i()];
            ST[j()][sStack[i()]] = new STElem(tmp);
            genTuple(sStack[i()], ST[j()][sStack[i()]]->tupletype,
                    ST[j()][sStack[i()]]->rows, ST[j()][sStack[i()]]->cols);
            sStack[i(2)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                string tmp = ST[j()][sStack[i()]]->tupletype;
                printTuple(sStack[i()], ST[j()][sStack[i()]]->tupletype,
                    ST[j()][sStack[i()]]->rows, ST[j()][sStack[i()]]->cols);
    	    }
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="declstat- type var")   {                  // 11
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "MEMORY", "", 1);
            genTuple(sStack[i()], "MEMORY", "1", "0");
            sStack[i(2)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i()], "MEMORY", "1", "0");
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="declstat- type var integer")   {          // 12
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "MEMORY", "",
                    atoi(sStack[i()].c_str()));
            genTuple(sStack[i(1)], "MEMORY", sStack[i()], "1");
            sStack[i(3)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(1)], "MEMORY", sStack[i()], "1");
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="declstat- type var integer integer")   {  // 13
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "MEMORY", "",
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            genTuple(sStack[i(2)], "MEMORY", sStack[i(1)], sStack[i()]);
            sStack[i(4)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(2)], "MEMORY", sStack[i(1)], sStack[i()]);
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
        else if(rhs=="type var")   {                            // 14
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "MEMORY", "", 1);
            genTuple(sStack[i()], "MEMORY", "1", "0");
            sStack[i(1)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i()], "MEMORY", "1", "0");
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="type var integer")   {                    // 15
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "MEMORY", "",
                atoi(sStack[i()].c_str()));
            genTuple(sStack[i(1)], "MEMORY", sStack[i()], "1");
            sStack[i(2)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(1)], "MEMORY", sStack[i()], "1");
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="type var integer integer")   {            // 16
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "MEMORY", "",
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            genTuple(sStack[i(2)], "MEMORY", sStack[i(1)], sStack[i()]);
            sStack[i(3)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(2)], "MEMORY", sStack[i(1)], sStack[i()]);
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
    }
    else if(lhs=="type")   {                // 17, 18
        popItems(numPops);
        return;
    }
    else if(lhs=="procpart")   {            // 19
        popItems(numPops);
        return;                         // these are empty
    }
    else if(lhs=="proclist")   {            // 20, 21
        popItems(numPops);
        return;                         // these are empty
    }
    else if(lhs=="proc")   {            // 22, 23
        if(rhs=="prochead declpart statlist END")   {
            if(token.flags.test(14))
                printST(j(), sStack[i(3)]);
            genTuple(sStack[i(3)], "ENDPROC", "-", "-");
            if(token.flags.test(13))
                printTuple(sStack[i(3)], "ENDPROC", "-", "-");
        }
        else if(rhs=="prochead declpart procpart statlist END")   {
            if(token.flags.test(14))
                printST(j(), sStack[i(4)]);
            genTuple(sStack[i(4)], "ENDPROC", "-", "-");
            if(token.flags.test(13))
                printTuple(sStack[i(4)], "ENDPROC", "-", "-");
        }
        ST.pop_back();      // GOOD?? YES
    }
    else if(lhs=="prochead")   {            // 24, 25
        popItems(numPops);
        return;
    }
    else if(lhs=="procname")   {            // 26
        if(token.flags.test(17))   {
            cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
            cout << "\t\tCREATING NEW SYMBOL TABLE FOR PROCEDURE"<<endl;
        }
        SymbolTable tmpST;
        tmpST[sStack[i()]] = new STElem(sStack[i()],
            "", "", "BEGINPROC", "");
        ST.push_back(tmpST);
        genTuple(sStack[i()], "BEGINPROC", "-", "-");
        sStack[i(1)] = sStack[i()];
        if(token.flags.test(17))   {
            cout<<"\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH CONTAINS:"<<endl;
            ST[j()][sStack[i()]]->print();
            cout << "\tEND OF TRACE" << endl;
        }
        if(token.flags.test(13))
            printTuple(sStack[i()], "BEGINPROC", "-", "-");
        if(token.flags.test(15))
            ST[j()][sStack[i(1)]]->print();
    }
    else if(lhs=="null-list")   {           // 27
        genTuple("-", "NOPARAMS", "-", "-");
        if(token.flags.test(13))
            printTuple("-", "NOPARAMS", "-", "-");
    }
    else if(lhs=="fparmlist")   {           // 28
        genTuple("-", "ENDPARAMS", "-", "-");
        if(token.flags.test(13))
            printTuple("-", "ENDPARAMS", "-", "-");
    }
    else if(lhs=="fparmlist-")   {      // 29 - 35
        if(rhs=="fparmlist- , var")   { // 29
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            STElem tmp(*(ST[j()][sStack[i(2)]]));
            tmp.STEntry = sStack[i()];
            ST[j()][sStack[i()]] = new STElem(tmp);
            genTuple(sStack[i()], ST[j()][sStack[i()]]->tupletype,
                    ST[j()][sStack[i()]]->rows, ST[j()][sStack[i()]]->cols);
            sStack[i(2)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                string tmp = ST[j()][sStack[i()]]->tupletype;
                printTuple(sStack[i()], ST[j()][sStack[i()]]->tupletype,
                    ST[j()][sStack[i()]]->rows, ST[j()][sStack[i()]]->cols);
    	    }
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="fparmlist- , calltype type var")   {  // 30
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "PARAM", sStack[i(2)], 1);
            genTuple(sStack[i()], "PARAM", sStack[i(2)], SIZE);
            sStack[i(4)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i()], "PARAM", sStack[i(2)], SIZE);
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="fparmlist- , calltype type var integer")   {  // 31
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "PARAM", sStack[i(3)],
                atoi(sStack[i()].c_str()));
            genTuple(sStack[i(1)], "PARAM", sStack[i(3)],
                    SIZE * atoi(sStack[i()].c_str()));
            sStack[i(5)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(1)], "PARAM", sStack[i(3)],
                    SIZE * atoi(sStack[i()].c_str()));
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="fparmlist- , calltype type var integer integer")   { // 32
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "PARAM", sStack[i(4)],
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            genTuple(sStack[i(2)], "PARAM", sStack[i(4)], SIZE *
                    atoi(sStack[i()].c_str()) * atoi(sStack[i(1)].c_str()));
            sStack[i(6)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))
                printTuple(sStack[i(2)], "PARAM", sStack[i(4)], SIZE *
                    atoi(sStack[i()].c_str()) * atoi(sStack[i(1)].c_str()));
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
        else if(rhs=="{ calltype type var")   {             // 33
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i()]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i()], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i()]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i()]] = new STElem(sStack[i()],
                sStack[i(1)], "SCALAR", "PARAM", sStack[i(2)], 1);
            genTuple("-", "BEGINPARAM", "-", "-");
            genTuple(sStack[i()], "PARAM", sStack[i(2)], SIZE);
            sStack[i(3)] = sStack[i()];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i()]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                printTuple("-", "BEGINPARAM", "-", "-");
                printTuple(sStack[i()], "PARAM", sStack[i(2)], SIZE);
            }
            if(token.flags.test(15))
                ST[j()][sStack[i()]]->print();
        }
        else if(rhs=="{ calltype type var integer")   {     // 34
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(1)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(1)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(1)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(1)]] = new STElem(sStack[i(1)],
                sStack[i(2)], "VECTOR", "PARAM", sStack[i(3)],
                atoi(sStack[i()].c_str()));
            genTuple("-", "BEGINPARAM", "-", "-");
            genTuple(sStack[i(1)], "PARAM", sStack[i(3)],
                    SIZE * atoi(sStack[i()].c_str()));
            sStack[i(4)] = sStack[i(1)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(1)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                printTuple("-", "BEGINPARAM", "-", "-");
                printTuple(sStack[i(1)], "PARAM", sStack[i(3)],
                    SIZE * atoi(sStack[i()].c_str()));
            }
            if(token.flags.test(15))
                ST[j()][sStack[i(1)]]->print();
        }
        else if(rhs=="{ calltype type var integer integer")   {     // 35
            if(token.flags.test(17))   {
                cout << "\tSYMBOL TABLE TRACE FOR <"<<sStack[i(2)]<<">"<<endl;
                cout << "\t\tCHECKING SYMBOL TABLE FOR PREVIOUS ";
                cout << "DECLARATION:"<<endl;
                if(checkST(sStack[i()], 0))   {
                    cout << "\t\t\tPREVIOUS DEClARATION FOUND!" << endl;
                    cout << "\tEND OF TRACE" << endl;
                }
            }
            if(checkST(sStack[i(2)], 0))   {
                cout<<"\t\tERROR: DOUBLY DECLARED VARIABLE :";
                cout<<sStack[i(2)]<<endl;
                popItems(numPops);
                return;
            }
            ST[j()][sStack[i(2)]] = new STElem(sStack[i(2)],
                sStack[i(3)], "MATRIX", "PARAM", sStack[i(4)],
                atoi(sStack[i(1)].c_str()), atoi(sStack[i()].c_str()));
            genTuple("-", "BEGINPARAM", "-", "-");
            genTuple(sStack[i(2)], "PARAM", sStack[i(4)],
                    SIZE * atoi(sStack[i()].c_str()) *
                    atoi(sStack[i(1)].c_str()));
            sStack[i(5)] = sStack[i(2)];
            if(token.flags.test(17))   {
                cout << "\t\t\tNO PREVIOUS DECLARATION FOUND" << endl;
                cout << "\t\tINSERTING ENTRY INTO SYMBOL TABLE WHICH ";
                cout << "CONTAINS:"<<endl;
                ST[j()][sStack[i(2)]]->print();
                cout << "\tEND OF TRACE" << endl;
            }
            if(token.flags.test(13))   {
                printTuple("-", "BEGINPARAM", "-", "-");
                printTuple(sStack[i(2)], "PARAM", sStack[i(4)],
                    SIZE * atoi(sStack[i()].c_str()) *
                    atoi(sStack[i(1)].c_str()));
            }
            if(token.flags.test(15))
                ST[j()][sStack[i(2)]]->print();
        }
    }
    else if(lhs=="calltype")   {            // 36, 37
        popItems(numPops);
        return;
    }
    //**************************************************************************
    // START OF PROGRAM 4 CODE
    //**************************************************************************
    else if(lhs=="execpart")   {            // 38 ????
	    //EMPTY????
//        popItems(numPops);
//        return;                         // these are empty
    }
    else if(lhs=="exechead")   {            // 39
   	genTuple(sStack[0], "LABEL", "-", "-");
        if(token.flags.test(13))
            printTuple(sStack[0], "LABEL", "-", "-");
        if(token.flags.test(15))
            ST[j()][sStack[i(1)]]->print();
    }
    else if(lhs=="statlist")   {            // 40
	    //EMPTY????
//        popItems(numPops);
//        return;                         // these are empty
    }
    else if(lhs=="statlist-")   {            // 41, 42
//        popItems(numPops);
//        return;                         // these are empty
    }
    else if(lhs=="stat")   {            // 43, 44, 45, 46, 47, 48
//        popItems(numPops);
//        return;                         // these are empty
    }
    else if(lhs=="instat")   {            // 49
//        genTuple(sStack[i(10)], "ENDACTUALPARAMS", "-", "-");
        genTuple("-", "ENDACTUALPARAMS", "-", "-");
        if(token.flags.test(13))
            printTuple("-", "ENDACTUALPARAMS", "-", "-");
//        sStack[i(1)] = sStack[i()];
    }
    else if(lhs=="instat-")   {            // 50, 51, 52, 53, 54, 55
	if(rhs=="instat- var")   {
	    genTuple("-", "ACTUALPARAMS", sStack[i()], "-");
        if(token.flags.test(13))
            printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
        if(token.flags.test(15))
            ST[j()][sStack[i(1)]]->print();

	sStack[i(1)] = sStack[i()];
	}
	else if(rhs=="instat- var [ aexpr ]")   {
	    int STlvl = checkST(sStack[i(3)]);
	    if(STlvl == -1)   cout << sStack[i(3)]<<" :VAR NOT IN ST!" << endl;
	    bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "SUBLOAD", ST[STlvl][sStack[i(3)]]->STEntry,
		     sStack[i(1)]);
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "SUBLOAD", 
		     ST[STlvl][sStack[i(3)]]->STEntry, sStack[i(1)]);
		printTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
	    }
	    I+=2;	    

	sStack[i(4)] = sStack[i(3)];	
	}
	else if(rhs=="instat- var [ aexpr : aexpr ]")   {
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
  	    bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
	    bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD",ST[STlvl][sStack[i(5)]]->STEntry,
		     itoa("I", I+1));
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "MULTI", 
		    itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
		printTuple(itoa("I", I+2), "SUBLOAD",
		    ST[STlvl][sStack[i(5)]]->STEntry, itoa("I", I+1));
		printTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
	    }
	    I+=3;
	sStack[i(6)] = sStack[i(5)];	    
	}
	else if(rhs=="INPUT var")   {
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", sStack[i()], "-");
            if(token.flags.test(13))   {
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	sStack[i(1)] = sStack[i()];	    
	}
	else if(rhs=="INPUT var [ aexpr ]")   {
	    int STlvl = checkST(sStack[i(3)]);
	    if(STlvl == -1)   cout << sStack[i(3)]<<" :VAR NOT IN ST!" << endl;
	    bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
	    genTuple(itoa("I", I), "SUBLOAD", ST[STlvl][sStack[i(3)]]->STEntry,
		     sStack[i(1)]);
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "SUBLOAD", 
			ST[STlvl][sStack[i(3)]]->STEntry, sStack[i(1)]);
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	    I+=2;
	sStack[i(4)] = sStack[i(3)];	    
	}
	else if(rhs=="INPUT var [ aexpr : aexpr ]")   {
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
	    bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
            bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD",ST[STlvl][sStack[i(5)]]->STEntry,
		     itoa("I", I+1));
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "MULTI", 
			itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
		printTuple(itoa("I", I+2), "SUBLOAD",
			ST[STlvl][sStack[i(5)]]->STEntry, itoa("I", I+1));
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	    I+=3;
	sStack[i(6)] = sStack[i(5)];	    
	}
    }
    else if(lhs=="outstat")   {            // 56
//        genTuple(sStack[i(10)], "ENDACTUALPARAMS", "-", "-");
        genTuple("-", "ENDACTUALPARAMS", "-", "-");
	if(token.flags.test(13))
	    printTuple("-", "ENDACTUALPARAMS", "-", "-");
//        sStack[i(1)] = sStack[i()];
    }
    else if(lhs=="outstat-")   {            // 57, 58, 59, 60, 61, 62
	if(rhs == "outstat- var")   {
	    genTuple("-", "ACTUALPARAMS", sStack[i()], "-");
            if(token.flags.test(13))
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	sStack[i(1)] = sStack[i()];	    
	}
	else if(rhs == "outstat- var [ aexpr ]")   {
	    int STlvl = checkST(sStack[i(3)]);
	    if(STlvl == -1)   cout << sStack[i(3)]<<" :VAR NOT IN ST!" << endl;
	 bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
	
	    genTuple(itoa("I", I), "SUBLOAD", ST[STlvl][sStack[i(3)]]->STEntry,
		     sStack[i(1)]);
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "SUBLOAD", 
			ST[STlvl][sStack[i(3)]]->STEntry, sStack[i(1)]);
		printTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
	    }
	    I+=2;
	sStack[i(4)] = sStack[i(3)];	    
	}
	else if(rhs == "outstat- var [ aexpr : aexpr ]")   {
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
  bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
	    bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD",ST[STlvl][sStack[i(5)]]->STEntry,
		     itoa("I", I+1));
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "MULTI", 
			itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
		printTuple(itoa("I", I+2), "SUBLOAD",
			ST[STlvl][sStack[i(5)]]->STEntry, itoa("I", I+1));
		printTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
	    }
	    I+=3;
	sStack[i(6)] = sStack[i(5)];	    
	}
	else if(rhs == "OUTPUT var")   {
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", sStack[i()], "-");
            if(token.flags.test(13))   {
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	sStack[i(1)] = sStack[i()];	    
	}
	else if(rhs == "OUTPUT var [ aexpr ]")   {
	    int STlvl = checkST(sStack[i(3)]);
	    if(STlvl == -1)   cout << sStack[i(3)]<<" :VAR NOT IN ST!" << endl;
            bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "SUBLOAD", ST[STlvl][sStack[i(3)]]->STEntry,
		     sStack[i(1)]);
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "SUBLOAD", 
			ST[STlvl][sStack[i(3)]]->STEntry, sStack[i(1)]);
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	    I+=2;
	sStack[i(4)] = sStack[i(3)];	    
	}
	else if(rhs == "OUTPUT var [ aexpr : aexpr ]")   {
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
  	    bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
	    bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD",ST[STlvl][sStack[i(5)]]->STEntry,
		     itoa("I", I+1));
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "MULTI", 
			itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
		printTuple(itoa("I", I+2), "SUBLOAD",
			ST[STlvl][sStack[i(5)]]->STEntry, itoa("I", I+1));
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	    I+=3;
	sStack[i(6)] = sStack[i(5)];	    
	}
    }
    else if(lhs=="callstat")   {            // 63, 64
//        popItems(numPops);
//        return;                         // these are empty
    }
    else if(lhs=="callname")   {            // 65
	genTuple(sStack[i()], "CALL", "-", "-");
	if(token.flags.test(13))
	    printTuple(sStack[i()], "CALL", "-", "-");
    }
    else if(lhs=="aparmlist")   {            // 66
//	genTuple(sStack[i(10)], "ENDACTUALPARAMS", "-", "-");
	genTuple("-", "ENDACTUALPARAMS", "-", "-");
	if(token.flags.test(13))
	    printTuple("-", "ENDACTUALPARAMS", "-", "-");
//        sStack[i(1)] = sStack[i()];
    }
    else if(lhs=="aparmlist-")   {            // 67, 68, 69, 70, 71, 72
	if(rhs=="aparmlist-, var"){		//67
	    genTuple("-", "ACTUALPARAMS", sStack[i()], "-");
            if(token.flags.test(13))
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	}
	if(rhs=="aparmlist-, var [ aexpr ]"){		//68
	    int STlvl = checkST(sStack[i(3)]);
	    if(STlvl == -1)   cout << sStack[i(3)]<<" :VAR NOT IN ST!" << endl;
 bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "SUBLOAD", ST[STlvl][sStack[i(3)]]->STEntry,
		     sStack[i(1)]);
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
            if(token.flags.test(13))
		printTuple(itoa("I", I), "SUBLOAD", 
			ST[STlvl][sStack[i(3)]]->STEntry, sStack[i(1)]);
	    I+=2;
	}
	if(rhs=="aparmlist-, var [ aexpr : aexpr ]"){		//69
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
  bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD",ST[STlvl][sStack[i(5)]]->STEntry,
		     itoa("I", I+1));
	    genTuple("", "ACTUALPARAMS", itoa("I", I+2), "");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "MULTI", 
			itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
		printTuple(itoa("I", I+2), "SUBLOAD",
			ST[STlvl][sStack[i(5)]]->STEntry, itoa("I", I+1));
		printTuple("", "ACTUALPARAMS", itoa("I", I+2), "");
	    }
	    I+=3;
	sStack[i(6)] = sStack[i(5)];	    
	}
	if(rhs=="{ var"){		//70
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", sStack[i()], "-");  // ?????
            if(token.flags.test(13))   {
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	sStack[i(1)] = sStack[i()];	    
	}
	if(rhs=="{ var [ aexpr ]"){		//71
	    int STlvl = checkST(sStack[i(3)]);
	    if(STlvl == -1)   cout << sStack[i(3)]<<" :VAR NOT IN ST!" << endl;
 bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "SUBLOAD", ST[STlvl][sStack[i(3)]]->STEntry,
		     sStack[i(1)]);
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+1), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I), "SUBLOAD", 
			ST[STlvl][sStack[i(3)]]->STEntry, sStack[i(1)]);
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	    I+=2;
	sStack[i(4)] = sStack[i(3)];	    
	}
	if(rhs=="{ var [ aexpr : aexpr ]"){		//72
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
  bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }
bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I),"MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD",ST[STlvl][sStack[i(5)]]->STEntry,
		     itoa("I", I+1));
	    genTuple("-", "BEGINACTUALPARAMS", "-", "-");
	    genTuple("-", "ACTUALPARAMS", itoa("I", I+2), "-");
            if(token.flags.test(13))   {
		printTuple(itoa("I", I),"MULTI", 
			itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(1)]);
		printTuple(itoa("I", I+2), "SUBLOAD",
			ST[STlvl][sStack[i(5)]]->STEntry, itoa("I", I+1));
		printTuple("-", "BEGINACTUALPARAMS", "-", "-");
		printTuple("-", "ACTUALPARAMS", sStack[i()], "-");
	    }
	    I+=3;
	sStack[i(6)] = sStack[i(5)];	    
	}
    }
    else if(lhs=="ifstat")   {            // 73, 74
	if(rhs=="ifhead statlist END"){		// 73
	    // ifstat ifhead statlist END
	    genTuple("L$" + sStack[i(2)], "LABEL", "-", "-");
            if(token.flags.test(13))
		printTuple("L$" + sStack[i(2)], "LABEL", "-", "-");
	    if(token.flags.test(15))
		ST[j()][sStack[i(1)]]->print();	    	    
	}
	if(rhs=="ifthen statlist END"){		// 74
	    //  ifstat ifthen statlist END
	    genTuple(itoa("L", sStack[i(2)], 1), "LABEL", "-", "-");
            if(token.flags.test(13))
		printTuple(itoa("L", sStack[i(2)], 1), "LABEL", "-", "-");
	}
    }
    else if(lhs=="ifthen")   {            // 75
	    //  ifhead statlist ELSE
	    genTuple(itoa("L", sStack[i(2)], 1), "JUMP", "-", "-");
	    genTuple("L$" + sStack[i(2)], "LABEL", "-", "-");
            if(token.flags.test(13))   {
		printTuple(itoa("L", sStack[i(2)], 1), "JUMP", "-", "-");
		printTuple("L$" + sStack[i(2)], "LABEL", "-", "-");
	    }
    }
    else if(lhs=="ifhead")   {            // 76
	    //  IF ( bexpr ) THEN
	    genTuple(itoa("L", L), "CJUMP", sStack[i(2)], "-");
            if(token.flags.test(13))
		printTuple(itoa("L", L), "CJUMP", sStack[i(2)], "-");
	    sStack[i(4)] = itoa(L);
	    L+=2;
    }
    else if(lhs=="whilestat")   {            // 77
	    //  whiletest statlist END
	    genTuple("L$" + sStack[i(2)], "JUMP", "-", "-");
	    genTuple(itoa("L", sStack[i(2)], 1), "LABEL", "-", "-");
            if(token.flags.test(13))   {
		printTuple("L$" + sStack[i(2)], "JUMP", "-", "-");
		printTuple(itoa("L", sStack[i(2)], 1), "LABEL", "-", "-");
	    }
    }
    else if(lhs=="whiletest")   {            // 78
	    //  whilehead ( bexpr ) DO
	    nonL=false;
	    genTuple(itoa("L", sStack[i(4)], 1), "CJUMP", sStack[i(2)], "-");
            if(token.flags.test(13))
		printTuple(itoa("L", sStack[i(4)], 1),"CJUMP",sStack[i(2)],"-");
    }
    else if(lhs=="whilehead")   {            // 79
	    nonL=true;
	    //  WHILE
	    genTuple(itoa("L", L), "LABEL", "-", "-");
            if(token.flags.test(13))
		printTuple(itoa("L", L), "LABEL", "-", "-");
	    sStack[i()] = itoa(L);
	    L+=2;
    }
    else if(lhs=="assignstat")   {            // 80
//        popItems(numPops);
//     	return;                         // these are empty
    }
    else if(lhs=="astat-")   {            // 81, 82, 83
	if(rhs=="var <- aexpr"){		//81
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "-");		
		}
		sStack[i()] = itoa("R", R);
 	        genTuple(sStack[i(2)],"SUBASSIGN", sStack[i()], itoa("R", R));
                if(token.flags.test(13))   {
		    printTuple(sStack[i(2)],"SUBASSIGN", sStack[i()], 
			itoa("R", R));		
		}
		sStack[i(2)] = itoa("R", R);
		R++;
	    }
	    else if(!t2 && t1)   {
//		cout << "\t\tType conversion from Integer to Real done on argument
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
		if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		}	
		sStack[i(2)] = itoa("R", R);
 	        genTuple(sStack[i(2)],"SUBASSIGN", sStack[i()], itoa("R", R));
                if(token.flags.test(13))   {
		    printTuple(sStack[i(2)],"SUBASSIGN", sStack[i()], 
			itoa("R", R));		
		}	
		sStack[i(2)] = itoa("R", R);
		R++;
	    }
	    else   {
 	        genTuple(sStack[i(2)],"SUBASSIGN", sStack[i()], itoa("I", I+1));
                if(token.flags.test(13))
		    printTuple(sStack[i(2)],"SUBASSIGN", sStack[i()], 
			itoa("I", I+1));	
	        sStack[i(2)] = itoa("I", I+1);
		I++;
	    }
	}
	if(rhs=="var [ aexpr ] <- aexpr"){		//82
 bool t3 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t3 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t3 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t3 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t3){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    bool t1 = true, t2 = true;
	    if(sStack[i(5)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(5)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(5)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(5)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(5)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		    		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;	
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "-");		
		}
		sStack[i()] = itoa("R", R);
 	        genTuple(sStack[i(5)],"SUBASSIGN", sStack[i()], itoa("R", R));
                if(token.flags.test(13))   {
		    printTuple(sStack[i(5)],"SUBASSIGN", sStack[i()], 
			itoa("R", R));		
		}
		sStack[i(5)] = itoa("R", R);		
		R++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(5)], "");
		cout << "\t\t CONVERTING "<<sStack[i(5)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(5)], "");		
		}	
		sStack[i(5)] = itoa("R", R);
 	        genTuple(sStack[i(5)],"SUBASSIGN", sStack[i()], itoa("R", R));
                if(token.flags.test(13))   {
		    printTuple(sStack[i(5)],"SUBASSIGN", sStack[i()], 
			itoa("R", R));		
		}	
		sStack[i(5)] = itoa("R", R);
		R++;
	    }
	    else   {
 	        genTuple(sStack[i(5)],"SUBASSIGN", sStack[i()], itoa("I", I));
                if(token.flags.test(13))
		    printTuple(sStack[i(5)],"SUBASSIGN", sStack[i()], 
			itoa("I", I));
	        sStack[i(5)] = itoa("I", I);
		I++;
	    }
	}
	if(rhs=="var [ aexpr : aexpr ] <- aexpr"){		//83
	    int STlvl = checkST(sStack[i(7)]);
	    if(STlvl == -1)   cout << sStack[i(7)]<<" :VAR NOT IN ST!" << endl;
  bool t3 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t3 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t3 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t3 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t3){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }
bool t4 = true; 
	    if(sStack[i(5)].substr(0, 2)=="R$")
		t4 = false;
	    else if(sStack[i(5)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(5)]);
	        if(STl != -1)
		t4 = (ST[STl][sStack[i(5)]]->varType == "INTEGER") ? true : false;
		else
		    t4 = (sStack[i(5)].find('.') == string::npos) ? true : false;
	    }
	    if(!t4){
	      cout << "		ERROR:  Using " << sStack[i(5)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I),"MULTI", itoa(ST[STlvl][sStack[i(7)]]->cols),
		     sStack[i(5)]);
	    genTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(3)]);
            if(token.flags.test(13))   {
		printTuple(itoa("I", I),"MULTI", 
			itoa(ST[STlvl][sStack[i(7)]]->cols), sStack[i(5)]);
		printTuple(itoa("I", I+1), "ADD", itoa("I", I), sStack[i(3)]);
	    }	
	    bool t1 = true, t2 = true;
	    if(sStack[i(7)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(7)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(7)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(7)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(7)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		    
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");		
		}	
		sStack[i()] = itoa("R", R);
 	        genTuple(sStack[i(7)],"SUBASSIGN", sStack[i()], itoa("R", R));
                if(token.flags.test(13))   {
		    printTuple(sStack[i(7)],"SUBASSIGN", sStack[i()], 
			itoa("R", R));		
		}	
		sStack[i(7)] = itoa("R", R);
		R++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(7)], "");
		cout << "\t\t CONVERTING "<<sStack[i(7)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(7)], "");	
		}	
		sStack[i(7)] = itoa("R", R);
 	        genTuple(sStack[i(7)],"SUBASSIGN", sStack[i()], itoa("R", R));
                if(token.flags.test(13))   {
		    printTuple(sStack[i(7)],"SUBASSIGN", sStack[i()], 
			itoa("R", R));		
		}	
		sStack[i(7)] = itoa("R", R);
		R++;
	    }
	    else   {
 	        genTuple(sStack[i(7)],"SUBASSIGN", sStack[i()], itoa("I", I+1));
                if(token.flags.test(13))
  		    printTuple(sStack[i(7)],"SUBASSIGN", sStack[i()], 
			itoa("I", I+1));		
	        sStack[i(7)] = itoa("I", I+1);
		I+=2;
	    }
//	    genTuple(sStack[i(7)], "SUBASSIGN", sStack[i()], itoa("I", I+1));
//	    I+=2;
	}
    }
    else if(lhs=="bexpr")   {            // 84
//        popItems(numPops);
//     	return;                         // these are empty
    }
    else if(lhs=="orexpr")   {            // 85, 86
	if(rhs=="or || andexpr"){		//85
//            popItems(numPops);		// ????????????????
//     	    return;                     // ?????????
	}
	if(rhs=="andexpr"){		//86
//            popItems(numPops);
//     	    return;                         // these are empty
	}
    }
    else if(lhs=="andexpr")   {            // 87
//        popItems(numPops);
//     	return;                         // these are empty
    }
    else if(lhs=="andexpr-")   {            // 88, 89
	if(rhs=="andexpr- && notexpr"){		//88
//            popItems(numPops);		// ????????????????
//     	    return;                     // ?????????
	}
	if(rhs=="notexpr"){		//89
//            popItems(numPops);
//     	   return;                         // these are empty
	}
    }
    else if(lhs=="notexpr")   {            // 90, 91
	if(rhs=="! relexpr"){		//90
//            popItems(numPops);		// ????????????????
//     	    return;                     // ?????????
	}
	if(rhs=="relexpr"){		//91
//            popItems(numPops);
//     	    return;                         // these are empty
	}
    }
    else if(lhs=="relexpr")   {            // 92, 93, 94, 95, 96, 97, 98
	if(rhs=="aexpr < aexpr"){		//92
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("B", B), "LESS", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "LESS", sStack[i(2)], sStack[i()]);
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;	
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("B", B), "LESS", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "LESS", sStack[i(2)], sStack[i()]);
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else   {
	        genTuple(itoa("B", B), "LESS", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("B", B), "LESS", sStack[i(2)], sStack[i()]);
	        sStack[i(2)] = itoa("B", B);
		B++;
	    }
	}
	if(rhs=="aexpr <= aexpr"){		//93
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;	
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;	
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");
		}	
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("B", B), "LESSEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "LESSEQUAL", sStack[i(2)], 
			sStack[i()]);
		}	
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
		if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("B", B), "LESSEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "LESSEQUAL", sStack[i(2)], 
			sStack[i()]);
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else   {
	        genTuple(itoa("B", B), "LESSEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("B", B), "LESSEQUAL", sStack[i(2)], 
			sStack[i()]);	
	        sStack[i(2)] = itoa("B", B);
		B++;
	    }
	}
	if(rhs=="aexpr > aexpr"){		//94
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;	
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("B", B), "GREATERL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "GREATERL", sStack[i(2)], 
			sStack[i()]);
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;	
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("B", B), "GREATER", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B),"GREATER",sStack[i(2)],sStack[i()]);
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else   {
	        genTuple(itoa("B", B), "GREATER", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("B", B), "GREATER", sStack[i(2)],
			sStack[i()]);	
	        sStack[i(2)] = itoa("B", B);
		B++;
	    }
	}
	if(rhs=="aexpr >= aexpr"){		//95
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;	
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("B",B),"GREATEREQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B",B),"GREATEREQUAL", sStack[i(2)], 
			sStack[i()]);		
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}	
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("B",B),"GREATEREQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B",B),"GREATEREQUAL", sStack[i(2)], 
			sStack[i()]);		
		}	
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else   {
	        genTuple(itoa("B",B),"GREATEREQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("B",B),"GREATEREQUAL", sStack[i(2)], 
			sStack[i()]);		
	        sStack[i(2)] = itoa("B", B);
		B++;
	    }
	}
	if(rhs=="aexpr == aexpr"){		//96
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("B", B), "EQUALEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "EQUALEQUAL", sStack[i(2)], 
			sStack[i()]);		
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("B", B), "EQUALEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "EQUALEQUAL", sStack[i(2)], 
			sStack[i()]);		
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else   {
	        genTuple(itoa("B", B), "EQUALEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("B", B), "EQUALEQUAL", sStack[i(2)], 
			sStack[i()]);
	        sStack[i(2)] = itoa("B", B);
		B++;
	    }
	}
	if(rhs=="aexpr != aexpr"){		//97
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("B", B), "NOTEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "NOTEQUAL", sStack[i(2)],
			sStack[i()]);		
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("B", B), "NOTEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("B", B), "NOTEQUAL", sStack[i(2)], 
			sStack[i()]);		
		}		
		sStack[i(2)] = itoa("B", B);
		R++;
		B++;
	    }
	    else   {
	        genTuple(itoa("B", B), "NOTEQUAL", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("B", B), "NOTEQUAL", sStack[i(2)],
			sStack[i()]);	
	        sStack[i(2)] = itoa("B", B);
		B++;
	    }
	}
	if(rhs=="aexpr"){		//98
if(nonL)
cout << "\t\tERROR: NON-LOGICAL EXPRESSION STATEMENT CONDITION" << endl;
 //       popItems(numPops);
//     	return;                         // these are empty
	}
    }
    else if(lhs=="aexpr")   {            // 99
//        popItems(numPops);
//     	return;                         // these are empty
    }
    else if(lhs=="aexpr-")   {            // 100, 101, 102, 103
	if(rhs=="aexpr- + term"){		//100
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("R", R+1), "ADD", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "ADD", sStack[i(2)],sStack[i()]);
		}		
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		}	
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("R", R+1), "ADD", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "ADD", sStack[i(2)],sStack[i()]);
		}	
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else   {
	        genTuple(itoa("I", I), "ADD", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("I", I), "ADD", sStack[i(2)], sStack[i()]);	
	        sStack[i(2)] = itoa("I", I);
		I++;
	    }
	}
	if(rhs=="aexpr- - term"){		//101
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(sStack[i(2)][0] == 'R' && sStack[i()][0] != 'R')   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("R", R+1), "SUB", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "SUB", sStack[i(2)],sStack[i()]);
		}		
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else if(sStack[i()][0] == 'R' && sStack[i(2)][0] != 'R')   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("R", R+1), "SUB", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "SUB", sStack[i(2)],sStack[i()]);
		}		
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else   {
	        genTuple(itoa("I", I), "SUB", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("I", I), "SUB", sStack[i(2)], sStack[i()]);	
	        sStack[i(2)] = itoa("I", I);
		I++;
	    }
	}
	if(rhs=="- term"){		//102
	    if(sStack[i()][0] == 'R')   {
		genTuple(itoa("R", R), "MULT", sStack[i(1)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("R", R), "MULT", sStack[i(1)], sStack[i()]);
	        sStack[i(1)] = itoa("R", R);
		R++;
	    }
	    else   {
		genTuple(itoa("I", I), "MULT", sStack[i(1)], sStack[i()]);
                if(token.flags.test(13))
  		    printTuple(itoa("I", I), "MULT", sStack[i(1)], sStack[i()]);
	        sStack[i(1)] = itoa("I", I);
		I++;
	    }
	}
	if(rhs=="term"){		//103
 //           popItems(numPops);
 //    	    return;                         // these are empty
	}	
    }
    else if(lhs=="term")   {            // 104
//        popItems(numPops);
//     	return;                         // these are empty
    }
    else if(lhs=="term-")   {            // 105, 106, 107
	if(rhs=="term- * primary"){		//105
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }		
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		}		
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("R", R+1), "MULT", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "MULT", sStack[i(2)], 
			sStack[i()]);
		}		
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("R", R+1), "MULT", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "MULT", sStack[i(2)], 
			sStack[i()]);
		}		
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else   {
	        genTuple(itoa("I", I), "MULT", sStack[i(2)], sStack[i()]);
	        sStack[i(2)] = itoa("I", I);
                if(token.flags.test(13))
  		    printTuple(itoa("I", I), "MULT", sStack[i(2)], sStack[i()]);
		I++;
	    }
	}
	if(rhs=="term- / primary"){		//106
	    bool t1 = true, t2 = true;
	    if(sStack[i(2)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(2)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(2)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(2)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(2)].find('.') == string::npos) ? true : false;
	    }
	    if(sStack[i()].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i()].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i()]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i()]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i()].find('.') == string::npos) ? true : false;
	    }
	    if(!t1 && t2)   {
		genTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		cout << "\t\t CONVERTING "<<sStack[i()]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i()], "-");
		}	
		sStack[i()] = itoa("R", R);
	        genTuple(itoa("R", R+1), "DIV", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "DIV", sStack[i(2)],sStack[i()]);
		}	
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else if(!t2 && t1)   {
		genTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		cout << "\t\t CONVERTING "<<sStack[i(2)]<< " TO REAL" << endl;
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R), "ITOR", sStack[i(2)], "-");
		}		
		sStack[i(2)] = itoa("R", R);
	        genTuple(itoa("R", R+1), "DIV", sStack[i(2)], sStack[i()]);
                if(token.flags.test(13))   {
		    printTuple(itoa("R", R+1), "DIV", sStack[i(2)],sStack[i()]);
		}		
		sStack[i(2)] = itoa("R", R+1);
		R+=2;
	    }
	    else   {
	        genTuple(itoa("I", I), "DIV", sStack[i(2)], sStack[i()]);
	        sStack[i(2)] = itoa("I", I);
                if(token.flags.test(13))
  		    printTuple(itoa("I", I), "DIV", sStack[i(2)], sStack[i()]);	
		I++;
	    }
	}
	if(rhs=="primary"){		//107
	}
    }
    else if(lhs=="primary")   {            // 108, 109, 110, 111, 112, 113
	if(rhs=="( bexpr )"){		//108
	    sStack[i(2)] = sStack[i(1)];
	}
	if(rhs=="integer"){		//109
//	    cout << "PROD 109 " << sStack[i()] << endl;
	}
	if(rhs=="real"){		//110
//	    cout << "PROD 110 " << sStack[i()] << endl;
	}
	if(rhs=="var") {		//111
//	    sStack[i()] = ST[j()][sStack[i()]].STEntry;
//	    genTuple(itoa("I", I+2), "SUBLOAD1", sStack[i()], "0");
	}
	if(rhs=="var [ aexpr ]") {		//112
 bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I), "SUBLOAD", sStack[i(3)], sStack[i(1)]);
            if(token.flags.test(13))
		printTuple(itoa("I", I), "SUBLOAD", sStack[i(3)],sStack[i(1)]);
	    sStack[i(3)] = itoa("I", I);
	    I++;
	    sStack[i(5)] = itoa("I", I);
	}
	if(rhs=="var [ aexpr : aexpr ]") {		//113
	    int STlvl = checkST(sStack[i(5)]);
	    if(STlvl == -1)   cout << sStack[i(5)]<<" :VAR NOT IN ST!" << endl;
  bool t1 = true; 
	    if(sStack[i(1)].substr(0, 2)=="R$")
		t1 = false;
	    else if(sStack[i(1)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(1)]);
	        if(STl != -1)
		t1 = (ST[STl][sStack[i(1)]]->varType == "INTEGER") ? true : false;
		else
		    t1 = (sStack[i(1)].find('.') == string::npos) ? true : false;
	    }
	    if(!t1){
	      cout << "		ERROR:  Using " << sStack[i(1)] <<  " as an Integer!" << endl;
	      cout << "		ERROR:  Using a Real as an Integer!" << endl;
	    }
bool t2 = true; 
	    if(sStack[i(3)].substr(0, 2)=="R$")
		t2 = false;
	    else if(sStack[i(3)].substr(0, 2) != "I$")   {
		int STl = checkST(sStack[i(3)]);
	        if(STl != -1)
		t2 = (ST[STl][sStack[i(3)]]->varType == "INTEGER") ? true : false;
		else
		    t2 = (sStack[i(3)].find('.') == string::npos) ? true : false;
	    }
	    if(!t2){
	      cout << "		ERROR:  Using " << sStack[i(3)] <<  " as an Integer!" << endl;
	    }

	    genTuple(itoa("I", I),"MULTI", itoa(ST[STlvl][sStack[i(5)]]->cols),
		     sStack[i(3)]);
	    genTuple(itoa("I", I+1), "ADD",itoa("I", I) , sStack[i(1)]);
	    genTuple(itoa("I", I+2), "SUBLOAD", sStack[i(5)], itoa("I", I+1));
                if(token.flags.test(13))   {
		    printTuple(itoa("I", I),"MULTI", 
			itoa(ST[STlvl][sStack[i(5)]]->cols), sStack[i(3)]);
		    printTuple(itoa("I", I+1), "ADD",itoa("I", I) , 
			sStack[i(1)]);
		    printTuple(itoa("I", I+2), "SUBLOAD", sStack[i(5)], 
			itoa("I", I+1));
		}
	    sStack[i(5)] = itoa("I", I+2);
	    I+=3;
	}
    }
    popItems(numPops);
}

void Parser::popItems(int n)   {
    for(int i = 0; i < n; i++)
        sStack.pop_back();
}

void Parser::printTuple(string s1, string s2, string s3, string s4)   {
    string tmp = "tuple (" + s1 +", "+ s2 +", "+ s3 +", "+ s4 +")";
    cout << setw(80) << tmp << endl;
}
void Parser::printTuple(string s1, string s2, string s3, int s4)   {
    ostringstream os;
    os << s4;
    string tmp = "tuple (" +s1+", "+s2+", "+s3+", "+ os.str() +")";
    cout << setw(80) << tmp << endl;
}
void Parser::printTuple(string s1, string s2, int s3, int s4)   {
    ostringstream os;
    os << s3 <<", "<<s4;
    string tmp = "tuple (" +s1+", "+s2+", "+ os.str() +")";
    cout << setw(80) << tmp << endl;
}

void STElem::print()   {
/*string tmp[15] {"PARAM", "MEMORY", "NOPARAM", "BEGINPARAM", "ENDPARAM",
    "BEGINPROC", "ENDPROC", "BEGINPROGRAM", "ENDPROGRAM", "MATRIX",
    "VECTOR", "SCALAR", "VALUE", "REFERENCE", "NONE"};*/

    cout << "\t\tSymbol Table Entry Data===" << endl;
    cout << "\t\t  Entry Name: " << STEntry << endl;
    cout << "\t\t  Tuple Type: " << tupletype << endl;
    cout << "\t\t  Call Type : " << calltype << endl;

// *****TAKE ME OUT!
    cout << "\t\t  VAR Type : " << varType << endl;
// *****************

//    cout << "\t\t  Parse Code: " << parsecode << endl;
    cout << "\t\t  Shape     : " << shape << endl;
    cout << "\t\t  Rows      : " << rows << endl;
    cout << "\t\t  Columns   : " << cols << endl;
    cout << "\t\t  Size      : " << size << endl;
}

bool Parser::checkST(string token, int loc)   {
  //****************************************************************************
  // This function checks if the passed in token is in the FGTable.
  //****************************************************************************
    if(ST[j(loc)].empty())
        return false;
    return ST[j(loc)].find(token) == ST[j(loc)].end() ? false : true;
}

int Parser::checkST(string token)   {
  //****************************************************************************
  // This function checks if the passed in token is in the FGTable and returns
  //  the scope level from which it was found.
  //****************************************************************************

    if(ST.empty())
	return false;
    for(int i = ST.size() - 1; i >= 0; i--)    {
        if(ST[i].empty())
	    continue;
        if(ST[i].find(token) != ST[i].end())
	    return i;
    }
    return -1;
}

void Parser::printST(int p, string pname)   {
     cout <<"\tENTRIES FOR SYMBOL TABLE: " << pname << endl;
     for(int i = p; i < ST.size(); i++)   {
         SymbolTable::iterator it = ST[i].begin();
         if(p == 0 && i > 0)
             cout <<"\tENTRIES FOR NEXT SYMBOL TABLE" << endl;
         for(it; it != ST[i].end(); ++it)   {
             cout <<"\tTABLE ENTRY :"<<it->first << endl;
             it->second->print();
         }
         cout << "\tEND OF ENTRTIES FOR THIS TABLE" << endl;
     }
}

string itoa(int val)   {
    ostringstream i;
    i << val;
    return i.str();
}

string itoa(string vt, int val)   {
    ostringstream i;
    i << vt << "$" << val;
    return i.str();
}

string itoa(string vt, string sval, int val)   {
    ostringstream i;
    i << vt << "$" << (atoi(sval.c_str()) + val);
    return i.str();
}

void Parser::genTuple(string s1, string s2, string s3, string s4)   {
    //out << "(" << s1 << ", " << s2 << ", " << s3 << ", " << s4 << ")" << endl;
    tuples.push_back("(" + s1 + ", " + s2 + ", " + s3 + ", " + s4 + ")");
}

void Parser::genTuple(string s1, string s2, int s3, int s4)   {
    //cout << "(" << s1 << ", " << s2 << ", " << s3 << ", " << s4 << ")" << endl;
    tuples.push_back("(" + s1 = ", " + s2 + ", " + itoa(s3)+ ", " + itoa(s4)+ ")");
}

void Parser::genTuple(string s1, string s2, string s3, int s4)   {
    //cout << "(" << s1 << ", " << s2 << ", " << s3 << ", " << s4 << ")" << endl;
    tuples.push_back("(" + s1 + ", " + s2 + ", " + s3 + ", " + itoa(s4) + ")");
}

