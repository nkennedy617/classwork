#include "tokenizer.h"


LexicalAnalyzer::LexicalAnalyzer(string file_name)   {
  //******************************************************************
  // Opens file given when Token is declared
  // If file not there, error is set and user is prompeted
  //******************************************************************
    infile.open(file_name.c_str());
    if(!infile)
        cout << "Tokenizer could not open file" << endl;
    //setiosflags(ios::right);
    ptr = 0; col = 1; line = 0; error = false; stateReal = false;
    flags.set(1);
    flagging = false;
    printHeader();
}


LexicalAnalyzer::~LexicalAnalyzer()   {
  //******************************************************************
  // Closes the input file
  //******************************************************************
    infile.close();
}


string LexicalAnalyzer::Next_Token()   {
  //******************************************************************
  // Next_Token tests each token for validity, tokens are removed until
  //  the next good token is found which is then returned to user.
  //******************************************************************
    if(!infile)  {
        infile.close();
        error = true;
        return "";
    }
    nextToken();
    if(flags.test(3) && !flagging)
        executeDebugFlag(3);

    while(type == Error || type == Integer || type == Real ||type==Identifier) {
    // Validity check for Integer, Real and Identifier types
        if(type != Error)
            if(testToken())                 // Valid digit found
                break;
        nextToken();
    }
    if(type == Flag)   {                    // Case for flag found in file
        setFlag();
        Next_Token();
    }
    if(type == BeginComment)   {       // Case for Comment
        clearComment();
        Next_Token();
    }
    else if(flags.test(5) && !flagging)   {
        string t = "LEXICAL TOKEN = " + token + " : CODE = ";
        cout << setw(78) << t << type << endl;
        }
        if(type == end_of_file && flags.test(2))
            printFsaTable();
    return token;
}


Reserved_Word LexicalAnalyzer::Type () const   {
  //******************************************************************
  // Returns the type of token found.
  //******************************************************************
    return type;
}
string LexicalAnalyzer::Text () const   {
  //******************************************************************
  // Returns the text of the token.
  //******************************************************************
    return token;
}
unsigned int LexicalAnalyzer::Line () const   {
  //******************************************************************
  // Returns line number.
  //******************************************************************
    return line;
}
unsigned int LexicalAnalyzer::Column () const   {
  //******************************************************************
  // Returns column number.
  //******************************************************************
    return col;
}
bool LexicalAnalyzer::Token_Error ()   {
  //******************************************************************
  // Returns the value set in error.
  //******************************************************************
    return error;
}


void LexicalAnalyzer::nextToken ()   {
  //******************************************************************
  // nextToken gets new buffer lines and throws away spaces and empty
  //  lines found in file.  The column and line values are set
  //  accordingly.  If end of file is found, error is set to true.
  //******************************************************************
    if(infile && ptr >= endPtr || line == 0)   {        // Grabs new line
        getline(infile, buffer);
        ptr = 0; col = 1; line++;
            executeDebugFlag(1);
        endPtr = buffer.length();
    }
    if(infile)    {
        while((ptr == endPtr || isspace(buffer[ptr])) && infile)  {
            if(ptr >= endPtr)   {               // Passes spaces and
                ptr = 0; col = 1; line++;       //  empty lines
                    getline(infile, buffer);
                        if(flags.test(1))
                            executeDebugFlag(1);
                endPtr = buffer.length();
                }
            while(ptr < endPtr && isspace(buffer[ptr]) && infile)
                        ptr++;
            if(ptr >= endPtr)   {
                    ptr = 0; col = 1; line++;
                    getline(infile, buffer);
                        if(flags.test(1))
                            executeDebugFlag(1);
                    endPtr = buffer.length();
                }
            }
            col = ptr + 1;
            if(infile)   {                      // Gets token if file
            if (flags.test(4) && !flagging) //  is still open
                        cout << setw(80) << "Start state, input, to Test State" << endl;
            getToken();
            }
        else   {                                            // Else error Flag set
            token = " ";                                //  and type set to
            col = 1; type = end_of_file;        //  end of file
        }
    }
    else   {                                            // If end of file, type
        token = " ";                                    //  is set to e/o/f
        col = 1; type = end_of_file; error = true;
    }
}


void LexicalAnalyzer::getToken ()   {
  //******************************************************************
  // Checks current ptr location in buffer.  Depending on the value
  //  found, the token a found and set.
  //******************************************************************
    error = false;
    if(ispunct(buffer[ptr]))   {                // Punct found
            if(flags.test(4) && !flagging)
            cout << setw(80) << "Test State, ascii, going to State D" << endl;
        token = getPunct();
        ptr += token.length();
    }
    else if(isdigit(buffer[ptr]))   {       // Number found
            if(flags.test(4) && !flagging)
            cout << setw(80) << "Test State, digit, going to State B" << endl;
        token = getDigit(ptr);
        int tmptr = token.length();
        if(buffer[ptr + tmptr] == '.' && isdigit(buffer[ptr + tmptr + 1]))   {
        // Check for float type
            if(flags.test(4) && !flagging)   {
                    cout << setw(80) << "State C, period, going to State C" << endl;
                cout << setw(80) << "State C, digit, going to Stats C" << endl;
                    stateReal = true;
                }
                token += buffer[ptr + tmptr] + getDigit(ptr + (tmptr+1));
                stateReal = false;
            }
        ptr += token.length();
    }
    else if(isalpha(buffer[ptr]))   {           // Identifier found
        if(flags.test(4) && !flagging)
                cout << setw(80) << "Test State, alpha, going to State F" << endl;
            int tmptr = 0;
        token = buffer[ptr];
        token = "";
            while(isalpha(buffer[ptr + tmptr]) || isdigit(buffer[ptr + tmptr]) ||
                  buffer[ptr + tmptr]=='_')   {
                token += buffer[ptr];
                string tmp = getIdentifier(ptr + 1);
                token += tmp;
            tmptr += tmp.length() + 1;
            if(ptr + tmptr >= 80)   {
                ptr = 0; col = 1; line++; tmptr = 0;
                getline(infile, buffer);
                    executeDebugFlag(1);
                endPtr = buffer.length();
            }
        }
        ptr += tmptr;
    }
    else   {                                // No good token found
            if(flags.test(4) && !flagging)
                cout<<setw(80) << "Test State , error, going to error state"<< endl;
        error = true;
        token = buffer[ptr];
    }
    if(token == "")                                 // If no token found
        nextToken();                                //  retry and set token
    else   {                                            //  to new value
        if(error)
            type = Error;
        else
            setType();
    }
}


string LexicalAnalyzer::getPunct()   {
  //******************************************************************
  // Gets all forms of puncuation.
  //******************************************************************
    string temp, blank;
    string pun[27] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                      "]", ":", ";", "<", ",", ">", "/", "==", "!=", "<=",
                      ">=", "<-" , "||", "&&", "##", "/*", "*/"};
    temp = buffer[ptr];
    if(ptr < endPtr - 1 && ispunct(buffer[ptr + 1]))   {
        temp.assign(buffer, ptr, 2);
        for(int i = 17; i < 27; i++)   {        // Checks for double punctuation
            if(temp == pun[i]) {
                        if(flags.test(4) && !flagging)
                            cout <<setw(80)<<"State D, ascii, going to state D" << endl;
                return pun[i];
            }
        }
        temp.erase(1);
    }
    for(int i = 0; i < 17; i++)             // Checks for single punctuation
            if(temp == pun[i])
            return pun[i];
    error = true;
    if(!flagging)   {
        cout << "\t\t***ASCII ERROR: INVALID ASCII CHARACTER FOUND : ";
        cout << line << ":" << col << endl;
    }
    return temp;
}


string LexicalAnalyzer::getDigit(int i)   {
  //******************************************************************
  // Grab all digits recersively and return as string.
  //******************************************************************
    string blank;
    if(!infile)
            return blank;
    if(isdigit(buffer[i]))    {
        if(flags.test(4) && !flagging)   {
            if(stateReal)
                        cout << setw(80) << "State C, digit, going to state C" << endl;
            else
                        cout << setw(80) << "State B, digit, going to state B" << endl;
            }
        return buffer[i] + getDigit(i + 1);
    }
    return blank;
}


string LexicalAnalyzer::getIdentifier(int i)   {
  //******************************************************************
  // Grab an identifier recersively until a digit or alpha or
  //  underscore is not found.  Value is then returned as a string.
  //******************************************************************
    string blank;
    if(!infile)
            return blank;
    if(isdigit(buffer[i]) || isalpha(buffer[i]) || buffer[i] == '_')   {
        if(flags.test(4) && !flagging)
                cout << setw(80)<<"Input is identifiable, going to state F" << endl;
        return buffer[i] + getIdentifier(i + 1);
    }
    return blank;
}


void LexicalAnalyzer::setType()   {
  //******************************************************************
  // Sets the type of the token from the token currently grab from
  //  file.
  //******************************************************************
    string pun[43] = {"!", "*", "(", ")", "+", "-", "=", "{", "}", "[",
                      "]", ":", ";", "<", ",", ">", "/", "==", "!=", "<=",
                      ">=", "<-", "||", "&&", "/*", "*/", "END", "PROGRAM",
                      "DECLARE", "INTEGER", "REAL", "PROCEDURE", "VALUE",
                      "REFERENCE", "COMPUTE", "INPUT", "OUTPUT", "CALL", "IF",
                      "ELSE", "THEN", "WHILE", "DO"};
    if(type != end_of_file)   {
        bool tmp = false;
        int i;
        for(i = 0; i < 43; i++)   {             // Checks for reserved
            if(token == pun[i])   {             //  words
                tmp = true;
                break;
                }
            }
        if(tmp)                                     // If res word found,
                type = Reserved_Word(i);        //  set type
        else   {
                if(token == "##")
                    type = Flag;
                else if(isdigit(token[0]))
                    type = token.find('.') != string::npos ? Real : Integer;
            else if(isalpha(token[0]))  // Set as identifier
                    type = Identifier;
            }
    }
}


bool LexicalAnalyzer::testToken()   {
  //******************************************************************
  // testDigit test the REAL or Integer type token for the correct
  //  number of significant digits.
  //******************************************************************
    if(type == Integer)   {                     // Test for Integer
            if(token.size() > 9)   {
            if(!flagging)   {
                        cout << "\t\t***NUMERIC ERROR: TOO MANY DIGITS FOUND FOR ";
                        cout << "INTEGER : " << line << ":" << col << endl;
                }
            return false;
        }
    }
    else if(type == Real)   {                   // Case for Real
        while(token[token.size() - 1] == '0')
                token.erase(token.size() - 1);
            if(token.size() > 8)   {
            if(!flagging)   {
                        cout<<"\t\t***NUMERIC ERROR: TOO MANY DIGITS FOUND FOR REAL : ";
                        cout << line << ":" << col << endl;
            }
                return false;
            }
    }
    else   {
        if(!isupper(token[0]))   {
            if(!flagging)   {
                    cout << "\t\t***IDENTIFIER ERROR: INVALID IDENTIFIER FOUND : ";
                cout << line << ":" << col << endl;
            }
                return false;
            }
    }
    return true;
}


void LexicalAnalyzer::clearComment()   {
  //******************************************************************
  // When a comment is found, this function grabs the whole comment.
  //******************************************************************
    nextToken();
    flagging = true;
    while(type != EndComment)
        nextToken();
//    nextToken();
    flagging = false;
}


void LexicalAnalyzer::setFlag()   {
  //******************************************************************
  // When a flag token is found, this function will set all the flags
  //  found between the flag tags and then grab the next available
  //  token for the user
  //******************************************************************
    bool fstate;                                // true = + : false = -
    nextToken();
    flagging = true;
    while(type != Flag)   {
        if(type != Minus && type != Plus)   { // Eats none flag information
            nextToken();
            continue;
        }
        fstate = type == Minus ? false : true;
        nextToken();
        if(fstate)                                  // Sets flag on
            flags.set(atoi(token.c_str()));
        else                                            // Sets flag off
            flags.reset(atoi(token.c_str()));
        nextToken();
    }
//    nextToken();
    flagging = false;
}
void LexicalAnalyzer::executeDebugFlag(int i)   {
  //******************************************************************
  // If a flag is set, the tokenizer will call this function based on
  //  checks set throughout the code and execute the required flag.
  //******************************************************************
    switch(i)   {
        case 1:
            cout << "\tSource Line :" << line << ":" << endl;
            cout << buffer << endl;
            break;
        case 3:
            cout << setw(80) << "Lexical Token : ";
            for(int i = 0; i <= token.length(); i++)
                cout << setw(80) << token.substr(0, i) << endl;
            break;
    }
}


void LexicalAnalyzer::printFsaTable()   {
  //******************************************************************
  // This function simply prints the FSA table for this grammer to the
  // screen upon termination of file being read.
  //******************************************************************
    cout << "===FSA TABLE===" << endl;
    system("cat fsatable");
}


void LexicalAnalyzer::printHeader()   {
  //******************************************************************
  // Prints program description.
  //******************************************************************
    system("cat headerinfo.txt");
}
