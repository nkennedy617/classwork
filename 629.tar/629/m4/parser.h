#ifndef PARSER_H
#define PARSER_H

#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <stack>
#include <map>
#include <vector>
#include <stdlib.h>
#include "tokenizer.h"

//******************************************************************************
// Programmers  : Nell Beatty : nell@cs.clemson.edu
//              : Leonard D. Holman Jr. : ldholma@cs.clemson.edu
// Date & Time  : March 08 2003; 5:44PM
// Program      : Semantics II : Milestone 4
// Due Date     : April 03 2003
// Program Description : This is a parser and sematic class to check for
//      semantically correct sentences based upon Grammar.Spring.2003. The
//      Parser component uses the previously developed Lexical Analyzer.  The
//      newly added semantic portion works in tandum with the parser, added
//      elements found in the code to a symbol table.  Informations is also
//      produced in the form of a four tuple to help generate the assembly code
//      needed to create an executable.  The semanic portion of code checks for
//      previous declarations of variables or procedures and generates messages
//      if any are found.  Upon completion, the parser and semanic checker
//      gracefully terminates.
// *****************************************************************************
// Semantic flags
//  12 - print the semantic stack before and after reductions (symbolically)
//  13 - print the 4-tuples produced (this flag will initially be turned on)
//  14 - print the variable symbol table for each procedure just before it is
//      popped from your symbol table stack
//  15 - print the variable symbol table entry immediately after updating
//      information for a variable
//  16 - print the symbol tables at program termination
//  17 - trace symbol table insertions
// *****************************************************************************

using namespace std;

#define SIZE   	    1
#define F	    0
#define G	    1
enum check {LES, GRT, EQT};
//enum shapedef{MATRIX, VECTOR, SCALAR, NONE};
//enum tuple_Type {PARAM, MEMORY, NOPARAM, BEGINPARAM, ENDPARAM, BEGINPROC, //ENDPROC, BEGINPROGRAM, ENDPROGRAM};
//enum call_Type {Value, Reference, None};

struct tableStruct   {
    int x[2];
    int &operator[](int i) {return x[i];}
};

class stkStrct   {
public:
    stkStrct(string i){item = i;}
    stkStrct(string i, check c){item = i; eq = c;}
    string item;
    check eq;
};

class STElem;
typedef map<string, tableStruct> Table;
typedef map<string, string> Grammar;
typedef map<string, STElem*> SymbolTable;
typedef vector<STElem> semanticStack;

class Parser   {
friend string itoa(string vt, string sval, int val);
friend string itoa(string vt, int val);
friend string itoa(int val);
public:
    Parser(string filename, string tfile, string gfile):token(filename){
        getFGTable(tfile);
        getGrammar(gfile);
        SymbolTable tmp;
        ST.push_back(tmp);
	I = B = R = L = 0;
        nonL=false;
    }
    void startSemantics();
    void start();
private:
    LexicalAnalyzer token;
    Table FGtable;
    Grammar grammar;
    //stack<stkStrct> pStack;
    vector<stkStrct> pStack;
    int I;
    int B;
    int R;
    int L;
    bool nonL;

    string reduceStack();
    void fixStack();
    void getFGTable(string filename);
    void getGrammar(string filename);
    bool checkGrammar(string token);
    bool checkHandle(string temp);
    void printStack();
    void flagCall(int i, string temp, string temp2);
    vector<string> sStack;
    bool checkST(string token, int loc);
    int checkST(string token);
    void popItems(int n);
    void genTuple(string s1, string s2, string s3, string s4); // NEW!
    void genTuple(string s1, string s2, string s3, int s4); // NEW
    void genTuple(string s1, string s2, int s3, int s4); // NEW
    void printTuple(string s1, string s2, string s3, string s4);
    void printTuple(string s1, string s2, string s3, int s4);
    void printTuple(string s1, string s2, int s3, int s4);
    void printST(int p, string pname);
    void checkReduction(string lhs, string rhs, int numPops);
    void printSemanticStack();
    int i(int n = 0) { return sStack.size() == 0 ? 0 : sStack.size() - 1 - n; }
    int j(int n = 0) { return ST.size() == 0 ? 0 : ST.size() - 1 - n; }
    vector<SymbolTable> ST;
    vector<string> tuples;
};

class STElem   {
public:
//    STElem();
    STElem(string en, string t, string s, string tt, string ct,
           int r = 0, int c = 0)   {
        STEntry = en;
        varType = t;
        shape = s;
        tupletype = tt;
        calltype = ct;
        rows = r;
        cols = c;
        size = SIZE * (r<0?1:r) * (c<=0?1:c);
    }
    STElem(const STElem &tmp)   {
        STEntry = tmp.STEntry;
        varType = tmp.varType;
        tupletype = tmp.tupletype;
        calltype = tmp.calltype;
//        parsecode = tmp.parsecode;
        shape = tmp.shape;
        rows = tmp.rows;
        cols = tmp.cols;
        size = tmp.size;
    }
    STElem(string en)   {
        STEntry = en;
    }
    const STElem &operator=(const STElem &tmp)   {
        STEntry = tmp.STEntry;
        varType = tmp.varType;
        tupletype = tmp.tupletype;
        calltype = tmp.calltype;
//        parsecode = tmp.parsecode;
        shape = tmp.shape;
        rows = tmp.rows;
        cols = tmp.cols;
        size = tmp.size;
        return *this;
    }

    string STEntry;
    string tupletype;
    string varType;
    string calltype;
//    string parsecode;
    string shape;
    int rows;
    int cols;
    int size;
    void print();
private:
};

#endif
