/****************************************************************************
** Form interface generated from reading ui file 'frmMain.ui'
**
** Created: Tue Feb 24 18:16:05 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FRMMAIN_H
#define FRMMAIN_H

#include <qvariant.h>
#include <qmainwindow.h>
#include "contact.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
class QListView;
class QListViewItem;

class frmMain : public QMainWindow
{
    Q_OBJECT

public:
    frmMain( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~frmMain();

    QListView* lvContacts;
    QMenuBar *MenuBar;
    QPopupMenu *PopupMenu;
    QPopupMenu *PopupMenu;
    QAction* aExit;
    QAction* aAddContact;
    QAction* aEditContact;
    QAction* aRemoveContact;

public slots:
    virtual void editContact();
    virtual void addContact();
    virtual void removeContact();

protected:
    QValueList<Contact> m_contacts;

    QGridLayout* frmMainLayout;

protected slots:
    virtual void languageChange();

private slots:
    virtual void init();

};

#endif // FRMMAIN_H
