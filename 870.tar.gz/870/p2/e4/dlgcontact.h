/****************************************************************************
** Form interface generated from reading ui file 'dlgcontact.ui'
**
** Created: Tue Feb 24 18:16:05 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef DLGCONTACT_H
#define DLGCONTACT_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QFrame;
class QSplitter;
class QLabel;
class QLineEdit;
class QPushButton;

class dlgContact : public QDialog
{
    Q_OBJECT

public:
    dlgContact( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~dlgContact();

    QFrame* frame4;
    QSplitter* splitter2;
    QLabel* txLabel1;
    QLabel* txLabel2;
    QLabel* txLabel3;
    QSplitter* splitter1;
    QLineEdit* leName;
    QLineEdit* leEMail;
    QLineEdit* lePhone;
    QSplitter* splitter3;
    QPushButton* pbOK;
    QPushButton* pbCancel;

protected:

protected slots:
    virtual void languageChange();

};

#endif // DLGCONTACT_H
