/****************************************************************************
** Form interface generated from reading ui file 'cfconvmainform.ui'
**
** Created: Fri Feb 6 16:17:38 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef CFCONVMAINFORM_H
#define CFCONVMAINFORM_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QLabel;
class QLineEdit;
class QPushButton;

class cfconvMainForm : public QDialog
{
    Q_OBJECT

public:
    cfconvMainForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~cfconvMainForm();

    QLabel* textLabel1;
    QLabel* textLabel2;
    QLineEdit* celsiusLineEdit;
    QLineEdit* fahrenheitLineEdit;
    QPushButton* quitPushButton;
    QPushButton* convertPushButton;

public slots:
    virtual void convert();

protected:

protected slots:
    virtual void languageChange();

};

#endif // CFCONVMAINFORM_H
