/****************************************************************************
** Form implementation generated from reading ui file 'cfconvmainform.ui'
**
** Created: Fri Feb 6 16:17:53 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "cfconvmainform.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "../cfconvmainform.ui.h"
/*
 *  Constructs a cfconvMainForm as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
cfconvMainForm::cfconvMainForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "cfconvMainForm" );

    textLabel1 = new QLabel( this, "textLabel1" );
    textLabel1->setGeometry( QRect( 10, 60, 131, 41 ) );

    textLabel2 = new QLabel( this, "textLabel2" );
    textLabel2->setGeometry( QRect( 0, 120, 151, 51 ) );

    celsiusLineEdit = new QLineEdit( this, "celsiusLineEdit" );
    celsiusLineEdit->setGeometry( QRect( 170, 50, 131, 51 ) );

    fahrenheitLineEdit = new QLineEdit( this, "fahrenheitLineEdit" );
    fahrenheitLineEdit->setGeometry( QRect( 170, 110, 131, 51 ) );
    fahrenheitLineEdit->setReadOnly( TRUE );

    quitPushButton = new QPushButton( this, "quitPushButton" );
    quitPushButton->setGeometry( QRect( 0, 190, 70, 31 ) );

    convertPushButton = new QPushButton( this, "convertPushButton" );
    convertPushButton->setGeometry( QRect( 90, 190, 80, 31 ) );
    languageChange();
    resize( QSize(524, 576).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( quitPushButton, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( convertPushButton, SIGNAL( clicked() ), this, SLOT( convert() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
cfconvMainForm::~cfconvMainForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void cfconvMainForm::languageChange()
{
    setCaption( tr( "Celsius to Fahrenheilt Converter" ) );
    textLabel1->setText( tr( "Celsius" ) );
    textLabel2->setText( tr( "Fahrenheit" ) );
    quitPushButton->setText( tr( "Quit" ) );
    convertPushButton->setText( tr( "Convert" ) );
}

