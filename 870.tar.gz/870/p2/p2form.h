/****************************************************************************
** Form interface generated from reading ui file 'p2form.ui'
**
** Created: Mon Mar 1 21:19:24 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef P2FORM_H
#define P2FORM_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QPushButton;
class QTable;

class p2Form : public QDialog
{
    Q_OBJECT

public:
    p2Form( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~p2Form();

    QPushButton* loadPushButton;
    QPushButton* helpPushButton;
    QPushButton* quitPushButton;
    QTable* bookTable;

protected:

protected slots:
    virtual void languageChange();

};

#endif // P2FORM_H
