/****************************************************************************
** Form implementation generated from reading ui file 'dlgmain.ui'
**
** Created: Tue Feb 24 17:03:03 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "dlgmain.h"

#include <qvariant.h>
#include <qsplitter.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "dlgmain.ui.h"
/*
 *  Constructs a dlgMain as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
dlgMain::dlgMain( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "dlgMain" );

    splitter5 = new QSplitter( this, "splitter5" );
    splitter5->setGeometry( QRect( 0, 20, 392, 366 ) );
    splitter5->setOrientation( QSplitter::Vertical );

    groupBox1 = new QGroupBox( splitter5, "groupBox1" );

    splitter4 = new QSplitter( groupBox1, "splitter4" );
    splitter4->setGeometry( QRect( 210, 20, 172, 278 ) );
    splitter4->setOrientation( QSplitter::Vertical );

    leItem = new QLineEdit( splitter4, "leItem" );

    pbAdd = new QPushButton( splitter4, "pbAdd" );
    pbAdd->setDefault( TRUE );

    pbRemove = new QPushButton( splitter4, "pbRemove" );

    lbItems = new QListBox( groupBox1, "lbItems" );
    lbItems->setGeometry( QRect( 10, 20, 191, 281 ) );

    splitter3 = new QSplitter( splitter5, "splitter3" );
    splitter3->setOrientation( QSplitter::Horizontal );

    pbOK = new QPushButton( splitter3, "pbOK" );
    languageChange();
    resize( QSize(600, 480).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( pbAdd, SIGNAL( clicked() ), this, SLOT( addItem() ) );
    connect( pbRemove, SIGNAL( clicked() ), this, SLOT( removeItem() ) );
    connect( pbOK, SIGNAL( clicked() ), this, SLOT( close() ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
dlgMain::~dlgMain()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void dlgMain::languageChange()
{
    setCaption( tr( "Simple Dialog Example" ) );
    groupBox1->setTitle( QString::null );
    pbAdd->setText( tr( "Add" ) );
    pbRemove->setText( tr( "Remove" ) );
    lbItems->clear();
    lbItems->insertItem( tr( "New Item" ) );
    pbOK->setText( tr( "OK" ) );
}

