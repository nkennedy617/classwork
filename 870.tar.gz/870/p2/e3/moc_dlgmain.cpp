/****************************************************************************
** dlgMain meta object code from reading C++ file 'dlgmain.h'
**
** Created: Tue Feb 24 17:03:19 2004
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.2.0b1   edited May 9 11:19 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "dlgmain.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.2.0b1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *dlgMain::className() const
{
    return "dlgMain";
}

QMetaObject *dlgMain::metaObj = 0;
static QMetaObjectCleanUp cleanUp_dlgMain( "dlgMain", &dlgMain::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString dlgMain::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "dlgMain", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString dlgMain::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "dlgMain", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* dlgMain::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"addItem", 0, 0 };
    static const QUMethod slot_1 = {"removeItem", 0, 0 };
    static const QUMethod slot_2 = {"languageChange", 0, 0 };
    static const QUMethod slot_3 = {"init", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "addItem()", &slot_0, QMetaData::Public },
	{ "removeItem()", &slot_1, QMetaData::Public },
	{ "languageChange()", &slot_2, QMetaData::Protected },
	{ "init()", &slot_3, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"dlgMain", parentObject,
	slot_tbl, 4,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_dlgMain.setMetaObject( metaObj );
    return metaObj;
}

void* dlgMain::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "dlgMain" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool dlgMain::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: addItem(); break;
    case 1: removeItem(); break;
    case 2: languageChange(); break;
    case 3: init(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool dlgMain::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool dlgMain::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool dlgMain::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
