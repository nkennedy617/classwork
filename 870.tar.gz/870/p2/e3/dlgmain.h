/****************************************************************************
** Form interface generated from reading ui file 'dlgmain.ui'
**
** Created: Tue Feb 24 17:02:51 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef DLGMAIN_H
#define DLGMAIN_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSplitter;
class QGroupBox;
class QLineEdit;
class QPushButton;
class QListBox;
class QListBoxItem;

class dlgMain : public QDialog
{
    Q_OBJECT

public:
    dlgMain( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~dlgMain();

    QSplitter* splitter5;
    QGroupBox* groupBox1;
    QSplitter* splitter4;
    QLineEdit* leItem;
    QPushButton* pbAdd;
    QPushButton* pbRemove;
    QListBox* lbItems;
    QSplitter* splitter3;
    QPushButton* pbOK;

public slots:
    virtual void addItem();
    virtual void removeItem();

protected:

protected slots:
    virtual void languageChange();

private slots:
    virtual void init();

};

#endif // DLGMAIN_H
