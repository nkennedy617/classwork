// Header for the QApplication class
#include <qapplication.h>

// Header for our dialog
#include "dlgmain.h"

// Remember the ( int, char** ) part as the QApplication needs them
int main( int argc, char **argv )
{
  // We must always have an application
  QApplication a( argc, argv );

  dlgMain *m = new dlgMain();   // We create our dialog
  a.setMainWidget( m );         // It is our main widget
  m->show();                    // Show it...

  return a.exec();              // And run!
}
