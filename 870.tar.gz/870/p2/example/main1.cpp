#include <qapplication.h>
#include "dlgMain.h"

int main ( int argc, char **argv){
 
    Qapplication a(argc, argv);
    dlgMain *m = new dlgMain();
    a.setMainWidget(m);
    m->show();
    
    return a.exec();
}
