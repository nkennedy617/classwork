/****************************************************************************
** Form interface generated from reading ui file 'simpledialog.ui'
**
** Created: Tue Feb 24 16:28:22 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef DLGMAIN_H
#define DLGMAIN_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QListBox;
class QListBoxItem;
class QSplitter;
class QPushButton;
class QLineEdit;

class dlgMain : public QDialog
{
    Q_OBJECT

public:
    dlgMain( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~dlgMain();

    QListBox* lbItems;
    QSplitter* splitter1;
    QPushButton* pbOK;
    QLineEdit* leEdit;
    QPushButton* pbAdd;
    QPushButton* pbRemove;

public slots:
    virtual void addItem();
    virtual void removeItem();

protected:
    QVBoxLayout* layout1;

protected slots:
    virtual void languageChange();

    virtual void init();


};

#endif // DLGMAIN_H
