#include "database.h"
#include <string>
using std::string;

//void find_and_modify(vector<Binary> & vec, int x) {
  //movie tmp;
  ////const vector<Binary>::const_iterator ptr = vec.begin(); 
     //find_if(vec.begin(), vec.end(), x);
  //if ( ptr == vec.end() ) {
     //cout <<"Not Found"<<endl;
  //}
  //else{
    //tmp = *ptr;
    //tmp.setName(
  //}
//}

      
int main() {
  string animal="kitty";
   //Movie ring("LOTR: Return of the King", "Jackson, P", 183);
   Database db("book.dat");
   db.load();
   db.print();
   //find_and_modify(vec, animal);
   db.modfirst();
   db.print();
   db.magicsort();
   db.print();
   return 0;
}
