#include <fstream>
#include <iostream>
#include "book.h"
using std::getline;

ostream & operator<<(ostream &out, const Book &book) {
   out << book.getName() << '\t'
       << book.getDirector() << '\t'
       << book.getLength();
   return out;
}

istream & operator>>(istream & input, Book & book) {
   // Initialize at the point of declaration; always safer
   //string name = getline(input);
   //string director = getline(input);
   //string length = getline(input);
   string tname, tdirector, tlength;
   getline(input, tname);
   getline(input, tdirector);
   getline(input, tlength);
   int l = atoi(tlength.c_str());
   book = Book(tname, tdirector, l);
   return input;
}

