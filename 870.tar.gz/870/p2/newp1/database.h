#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "book.h"
// MOVE THESE!!
using std::vector;
using std::cout; using std::endl;
using std::ios;

class Database {
public:
   Database(const string f) : filename(f) {}
   void load();
   void print() const;
   void magicsort() ;
   void modfirst();
private:
   Database();
   vector<Book> books;
   string filename;
};
