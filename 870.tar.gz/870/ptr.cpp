#include <iostream>

using std::cout; using std::endl;

int main() {
  int x = 1;
  int k;
  int y[4];
  int i;
  for(i=0; i<4; i++){
   y[i]=i;
  }
 int *ptr ;
  ptr=&x;
  k=*ptr;
  cout << y[k] <<endl;
}
