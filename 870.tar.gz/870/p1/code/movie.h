#include "String.h"

class Movie {
public:
   Movie() : name(""), director(""), length(0) {}
   Movie(const String &n, const String &d, int l) 
      : name(n), director(d), length(l) {}
   Movie(const Movie &m) 
      : name(m.name), director(m.director), length(m.length) {}
   const String & getName() const { return name; }
   const String & getDirector() const { return director; }
   const int & getLength() const { return length; }
private:
   String name;
   String director;
   int length;
};

ostream & operator<<(ostream &out, const Movie &);

