#include "String.h"

String & String::operator=(const String& str) {
   if ( this == & str ) return *this;
   delete [] buf;
   buf = new char[strlen(str.buf)+1];
   strcpy(buf, str.buf);
   return *this;
}

ostream & operator<<(ostream & out, const String & str) {
   out << str.getBuf();
   return out;
}
