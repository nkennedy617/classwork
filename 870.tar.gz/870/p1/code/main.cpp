#include "database.h"

int main() {
   //Movie ring("LOTR: Return of the King", "Jackson, P", 183);
   Database db("movies.dat");
   db.load();
   db.print();
   return 0;
}
