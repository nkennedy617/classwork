#include "database.h"
#include <iostream>
#include <fstream>
#include <algorithm>

using std::fstream; using std::sort;

void Database::load() {
   Book book;
   fstream input;
   input.open(filename.getBuf(), ios::in);
   input >> book;
   while ( !input.eof() ) {
      books.push_back( book );
      input >> book;
   }
}
void Database::print() const {
   vector<Book>::const_iterator ptr = books.begin();
   if ( books.size() == 0 ) {
      cout << "No books to read, bummer!" << endl;
      return;
   }
   cout << "The books:" << endl;
   while ( ptr != books.end() ) {
      cout << *ptr << endl;
      ++ptr;
   }
}

void Database::modfirst() {
  Book tmp;
  String animal("kitty");
  tmp = books[1];
  tmp.setName(animal);
  books[1]=tmp;
  return;
}

void Database::magicsort() {
  sort(books.begin(), books.end());
  return;
}
//Movie & Database::find(const String &field) {
//   vector<Movie>::const_iterator ptr = movies.begin();
//   if ( movies.size() == 0 ) {
//      cout << "No movies found, bummer!" << endl;
//      return;
//   }
//   while ( ptr != movies.end() ) {
//      if(field==movies.getName(){
//        cout << "Found it!" << field <<endl;
//      }
//      ++ptr;
//   }
   
//}
