#include <iostream>
#include <fstream>
#include <vector>
#include "book.h"
// MOVE THESE!!
using std::vector;
using std::cout; using std::endl;
using std::ios;

class Database {
public:
   Database(const String &f) : filename(f) {}
   void load();
   void print() const;
   void magicsort() ;
//   Movie & find(const String &field);
   void modfirst();
private:
   Database();
   vector<Book> books;
   String filename;
};
