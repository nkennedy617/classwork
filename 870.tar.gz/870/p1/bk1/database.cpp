#include "database.h"
#include <iostream>
#include <fstream>
#include <algorithm>

using std::fstream; using std::sort;

void Database::load() {
   Movie movie;
   fstream input;
   input.open(filename.getBuf(), ios::in);
   input >> movie;
   while ( !input.eof() ) {
      movies.push_back( movie );
      input >> movie;
   }
}
void Database::print() const {
   vector<Movie>::const_iterator ptr = movies.begin();
   if ( movies.size() == 0 ) {
      cout << "No movies to watch, bummer!" << endl;
      return;
   }
   cout << "The movies:" << endl;
   while ( ptr != movies.end() ) {
      cout << *ptr << endl;
      ++ptr;
   }
}

void Database::modfirst() {
  Movie tmp;
  String animal("kitty");
  tmp = movies[1];
  tmp.setName(animal);
  movies[1]=tmp;
  return;
}

void Database::magicsort() {
  sort(movies.begin(), movies.end());
  return;
}
//Movie & Database::find(const String &field) {
//   vector<Movie>::const_iterator ptr = movies.begin();
//   if ( movies.size() == 0 ) {
//      cout << "No movies found, bummer!" << endl;
//      return;
//   }
//   while ( ptr != movies.end() ) {
//      if(field==movies.getName(){
//        cout << "Found it!" << field <<endl;
//      }
//      ++ptr;
//   }
   
//}
