#include <iostream>
#include <cstring>

//Move this
using std::ostream; using std::istream;

class String {
public:
   String() : buf(new char[1]) { buf[0] = '\0'; }
   String(const char * b) : buf(new char[strlen(b)+1]) { 
      strcpy(buf, b);
   }
   String(const String & s) : buf(new char[strlen(s.buf)+1]) { 
      strcpy(buf, s.buf);
   }
   ~String() { delete [] buf; }
   const char * getBuf() const { return buf; }
   String & operator=(const String&);
   //int  operator==(const String&, const String&);
   friend istream & operator>>(istream & in, const String & str) {
      in >> str.buf;
      return in;
   }

private:
   char * buf;
};
ostream & operator<<(ostream &, const String &);
