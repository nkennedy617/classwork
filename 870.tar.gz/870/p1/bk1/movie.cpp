#include "movie.h"


ostream & operator<<(ostream &out, const Movie &movie) {
   out << movie.getName() << '\t'
       << movie.getDirector() << '\t'
       << movie.getLength();
   return out;
}
