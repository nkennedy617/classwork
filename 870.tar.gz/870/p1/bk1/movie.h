#include "String.h"

class Movie {
public:
   Movie() : name(""), director(""), length(0) {}
   Movie(const String &n, const String &d, int l) 
      : name(n), director(d), length(l) {}
   Movie(const Movie &m) 
      : name(m.name), director(m.director), length(m.length) {}
   const String & getName() const { return name; }
   const String & getDirector() const { return director; }
   const int & getLength() const { return length; }
   friend istream & operator>>(istream &in, Movie &movie) {
      in >> movie.name >> movie.director >> movie.length ;
      return in;
   }
   bool operator<(const Movie &m1) const {
      return (length < m1.length);
//      if(length < m1.length)
      //  return *this;
      //else
       // return m1; 
   }
   void setName(const String &n){
     name = n;
     return;
   } 
private:
   String name;
   String director;
   int length;
};

ostream & operator<<(ostream &out, const Movie &);

