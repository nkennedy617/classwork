#include "String.h"

String & String::operator=(const String& str) {
   if ( this == & str ) return *this;
   delete [] buf;
   buf = new char[strlen(str.buf)+1];
   strcpy(buf, str.buf);
   return *this;
}

//int  String::operator==(const String& str1, const String& str2) {
//   char * t1, t2;
//   int result;
//   strcpy(t1, str1.buf);
//   strcpy(t2, str2.buf);
//   result = strcmp(t1, t2);
//   return result;
//}
ostream & operator<<(ostream & out, const String & str) {
   out << str.getBuf();
   return out;
}
String String::getLine(istream & input) {
   char * buf = new char[80];
   char ch;
   unsigned index = 0;
   input.get(ch);
   while ( !input.eof() && ch != '\n' ) {
      buf[index++] = ch;
      input.get(ch);
   }
   buf[index] = '\0';
   String tmp(buf);
   delete [] buf;
   return tmp;
}

