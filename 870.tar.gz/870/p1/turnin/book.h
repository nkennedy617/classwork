#include "String.h"

class Book {
public:
   Book() : name(""), director(""), length(0) {}
   Book(const String &n, const String &d, int l) 
      : name(n), director(d), length(l) {}
   Book(const Book &m) 
      : name(m.name), director(m.director), length(m.length) {}
   const String & getName() const { return name; }
   const String & getDirector() const { return director; }
   const int & getLength() const { return length; }
//      in >> book.name >> book.director >> book.length ;
   bool operator<(const Book &m1) const {
      return (length < m1.length);
//      if(length < m1.length)
      //  return *this;
      //else
       // return m1; 
   }
   void setName(const String &n){
     name = n;
     return;
   } 
private:
   String name;
   String director;
   int length;
};

ostream & operator<<(ostream &out, const Book &);
istream & operator>>(istream &in, Book &); 

