#include "book.h"


ostream & operator<<(ostream &out, const Book &book) {
   out << book.getName() << '\t'
       << book.getDirector() << '\t'
       << book.getLength();
   return out;
}

istream & operator>>(istream & input, Book & book) {
   // Initialize at the point of declaration; always safer
   String name = String::getLine(input);
   String director = String::getLine(input);
   String length = String::getLine(input);
   int l = atoi(length.getBuf());
   book = Book(name, director, l);
   return input;
}

