// Finding the type of an item, from first principles
// Feb 17, 2004
#include <iostream>

class NullList {};

template <class T, class U>
class Typelist {
   typedef T Head;
   typedef U Tail;
};

template <class TList, int index>
struct TypeAt;

template <class Head, class Tail>
struct TypeAt< Typelist<Head, Tail>, 0> {
   typedef Head Result;
};

template <class Head, class Tail, int index>
struct TypeAt< Typelist<Head, Tail>, index> {
   typedef typename TypeAt<Tail, index-1>::Result Result;
};

int main() {
   typedef Typelist<char,
      Typelist<short,
         Typelist<int,
            Typelist<long, NullList> > > > mytypes;
   TypeAt< mytypes, 0 >::Result ch = 'A';
   std::cout << ch << std::endl;
   return 0;
}
