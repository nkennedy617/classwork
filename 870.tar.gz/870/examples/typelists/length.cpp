// Length of a typelist, from first principles
// Feb 17, 2004

#include <iostream>

class NullList {};

template <class T, class U>
class Typelist {
   typedef T Head;
   typedef U Tail;
};

template <class TList>
struct Length {};

template <class T, class U>
struct Length< Typelist<T, U> > {
   enum { value = 1 + Length<U>::value };
};
struct Length<NullList> {
   enum { value = 0 };
};

int main() {
   typedef Typelist<char,
      Typelist<short,
         Typelist<int,
            Typelist<long, NullList> > > > mytypes;
   std::cout << Length< mytypes >::value << std::endl;
   return 0;
}
