// Compile-time computation of factorial
// Feb 17, 2004

#include <iostream>

template <int n>
struct fact {
   enum { value = n * fact<n-1>::value };
};

template <>
struct fact<0> {
   enum { value = 1 };
};

int main() {
   fact<512> f;
   std::cout << f.value << std::endl;
   return 0;
}
