// Loki, from first principles
// Feb 17, 2004

#include <iostream>

int main() {
   return 0;
}
