#ifndef PERSON__H
#define PERSON__H
#include <iostream>
#include <string>

class person {
public:
   person(const std::string& f, const std::string& l, unsigned long i)
		: first_(f), last_(l), id_(i) {}
   const std::string& getFirst() const { return first_; }
   const std::string& getLast() const { return last_; }
   unsigned long getId() const { return id_; }
private:
   std::string first_;
   std::string last_;
   unsigned long id_;
};
std::ostream& operator<<(std::ostream&, const person&);

struct less_first {
   bool operator()(person const &lhs, person const &rhs) const {
      return lhs.getFirst() < rhs.getFirst();
   }
};

struct less_last {
   bool operator()(person const &lhs, person const &rhs) const {
      return lhs.getLast() < rhs.getLast();
   }
};

struct less_id {
   bool operator()(person const &lhs, person const &rhs) const {
      return lhs.getId() < rhs.getId();
   }
};

struct less_last_first_id {
   bool operator()(person const &lhs, person const &rhs) const {
      return ((lhs.getLast() < rhs.getLast())?(true):
             ((lhs.getLast() > rhs.getLast())?(false):
             ((lhs.getFirst() < rhs.getFirst())?(true):
             ((lhs.getFirst() > rhs.getFirst())?(false):
             ((lhs.getId() < rhs.getId())?(true):
             ((lhs.getId() > rhs.getId())?(false):
             (false)))))));
   }
};

#endif
