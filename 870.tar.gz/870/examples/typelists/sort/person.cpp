
#include "person.h"
std::ostream& operator<<(std::ostream& out, const person& p) {
   out << p.getFirst() << ",\t" 
       << p.getLast() << ",\t" 
       << p.getId();
   return out;
}

