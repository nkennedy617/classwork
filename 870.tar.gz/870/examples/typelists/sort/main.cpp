// Problem: sort the array by last name, first name, then id
#include <vector>
#include <string>
#include "person.h"
#include "order_by.h"

void print(const std::string& description, const std::vector<person> &vec) {
   std::cout << description << std::endl;
   typedef std::vector<person>::const_iterator iter;
   iter ptr = vec.begin(); 
   while ( ptr != vec.end() ) {
      std::cout << "\t" << *ptr << "\n";
      ++ptr;
   }
}

int main() {
   std::vector<person> vec;
   vec.push_back( person("Saruman", "The White", 1) );
   vec.push_back( person("Gandalf", "The Gray", 3) );
   vec.push_back( person("Frodo", "Baggins", 1) );
   vec.push_back( person("Aragorn", "Baggins", 1) );
   vec.push_back( person("Aragorn", "Arathorn", 1) );
   vec.push_back( person("Bilbo", "Baggins", 2) );
   print("Original list", vec);

   order_by<std::vector<person>, Typelist<less_first, NullType> >
            o(vec.begin(), vec.end());

   //order_by<std::vector<person>, 
       //Typelist<less_last, 
          //Typelist<less_first, 
             //Typelist<less_id, NullType> > > >
            //o(vec.begin(), vec.end());

   print("sorted last/first/id", vec);
}
