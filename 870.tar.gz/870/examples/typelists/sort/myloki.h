
class NullType {};

template <class T, class U>
class Typelist {
   typedef T Head;
   typedef U Tail;
};

template <class TList>
struct Length;

template <class T, class U>
struct Length< Typelist<T, U> > {
   enum { value = 1 + Length<U>::value };
};

template <>
struct Length<NullType> {
   enum { value = 0 };
};


template <class TList, int index>
struct TypeAt;

template <class Head, class Tail>
struct TypeAt < Typelist<Head, Tail>, 0 > {
   typedef Head Result;
};

template <class Head, class Tail, int index>
struct TypeAt < Typelist<Head, Tail>, index > {
   typedef typename TypeAt< Tail, index-1>::Result Result;
};
