#ifndef ORDER_BY__H
#define ORDER_BY__H
// The constant, 0xFFFF, is used as a marker value to end recursion

#include <iostream>
#include <algorithm>
#include <iterator>
#include "myloki.h"

template <typename CONT, typename TLIST, int i = 0>
class order_by {
private:
   typedef typename CONT::iterator iter;
   enum { n = Length<TLIST>::value };
   typedef typename TypeAt<TLIST, i>::Result comp_type;
public:
   order_by(iter begin, iter end) {
      std::cout << "Constructor" << std::endl;
      std::sort(begin, end, comp_type());
      std::pair<iter, iter> range;
      while (true) {
         range = std::equal_range(begin, end, *begin, comp_type());
         if (range.first == end) {
            return;
         }
         order_by<CONT, TLIST, ((i+1==n)?(0xFFFF):(i+1))>
            o(range.first, range.second);
         begin = range.second;
      }
   }
};

//Specialized object to end template recursion:
template <typename CONT, typename TLIST>
class order_by<CONT, TLIST, 0xFFFF> {
private:
   typedef typename CONT::iterator iter;
public:
   order_by(iter begin, iter end) {}
};
#endif
