#include <qapplication.h>
#include <qdialog.h>
#include <qlabel.h>
#include <qtextedit.h>
#include <qlineedit.h>
#include <qcheckbox.h>

#include "database/Book.h"

class insertDialog : public QDialog {

Q_OBJECT

private slots:
  void dataChanged();
  

public:
  insertDialog(Book * e);
  inline bool isValid() const { return validInsert; }
 
private:
  QWidget   *layoutWidget;
  QLineEdit *title;
  QLineEdit *author;
  QLineEdit *published;
  Book      *entry;
  bool       validInsert;

};


