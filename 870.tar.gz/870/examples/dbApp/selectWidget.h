#include <qtable.h>
#include <qstatusbar.h>

class selectDialog : public QDialog {

Q_OBJECT

private slots:
   void fileOpen();
   void insertItem();
   void modifyItem(int,int);
   void newDB();
   void dataChanged();

public:
   selectDialog();
   inline bool isValid() const { return validSelect; }

private:
    QTable                 *mainTable;
    QStatusBar             *statusBar;
    std::vector<Book>      items;
    Command *              cmd;
    std::string            loadedDBFilename;
    bool                   validSelect;
    
    void displayDB() const;
};

