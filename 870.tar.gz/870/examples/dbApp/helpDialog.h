#include <qapplication.h>
#include <qdialog.h>
#include <qlabel.h>
#include <qtextedit.h>
#include <qcheckbox.h>

class helpDialog : public QDialog {
  /*
Q_OBJECT

private slots:
   void fileOpen();
   void saveFile(); 
   void defaultLoad();
   void sortDB();
   void displayHelp();
  */

public:
  helpDialog();

 
private:
  QWidget   *layoutWidget;
  QTextEdit *text;

};

