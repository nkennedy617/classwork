#include <qdialog.h>
#include <qtable.h>
#include <qstatusbar.h>
#include <vector>
#include <map>

#include "database/Book.h"

class selectDialog : public QDialog {

Q_OBJECT

private slots:
   void selected();

public:
   selectDialog(std::vector<Book> b,int m);
   inline bool isValid() const { return validSelect; }
   int getCentSelection() const { return centSelect; }
   std::string getAuthSelection() const { return authorSelect; }
   

private:
   void fillTable();

   QTable                     *mainTable;
   QStatusBar                 *statusBar;
   std::map<std::string,int>  itemMap;
   std::string                loadedDBFilename;
   int                        mode;
   int                        centSelect;
   std::string                authorSelect;
   bool                       validSelect;

};

