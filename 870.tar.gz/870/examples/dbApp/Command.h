#include <string>
#include <stack>

#include "dbSingleton.h"

class Command {
 public:
  Command(const std::string & n) : name(n) { }
  virtual ~Command() { }
  virtual void execute(database<Book> &) /*= 0*/ { };
  virtual void execute() /*= 0*/ { };
  virtual void undo(database<Book> &) { } ;
  virtual void undo() { };
  std::string getName() const { return name; }
  
 private:
  std::string name;

 protected:
  static std::stack< Command* > commandHistory;

};

//######################## loadDBCommand ###########################//
class loadDBCommand : public Command { 
 public:
  loadDBCommand(const std::string & f) : 
    Command("loadDBCommand"),
    filename(f) { }
  virtual void execute(/*database<Book> &*/);
 private:
  std::string filename;
};

//#########################  newDBCommand ##########################//
class newDBCommand : public Command {
 public:
  newDBCommand () : Command("newDBCommand"){ } ;
  virtual void execute(/*database<Book> &*/);
 private:
  std::string filename;
};


//######################### saveDBCommand ##########################//
class saveDBCommand : public Command {
 public:
  saveDBCommand(const std::string & f) : 
    Command("saveDBCommand"),
    filename(f) { }
  virtual void execute(/*database<Book> &*/);
 private:
  std::string filename;
};


//###################### modifyEntryCommand ########################//
class modifyEntryCommand : public Command {
 public:
  
  modifyEntryCommand(const Book & b, const int & r) : 
    Command("modifyEntry"), 
    modEntry(b),
    row(r) { }
  
  virtual void execute(/*database<Book> &*/);
  virtual void undo(/*database<Book> &*/);
  
 private:
  Book modEntry;
  Book origEntry;
  int row;
  
};

//###################### insertEntryCommand ########################//

class insertEntryCommand : public Command {
 public:
  insertEntryCommand(const Book & b) : 
    Command("insertEntryCommand"),
    newEntry(b) { }
  virtual void execute(/*database<Book> &*/);
  virtual void undo(/*database<Book> &*/);
 private:
  Book newEntry;
};

//###################### deleteEntryCommand ########################//

class deleteEntryCommand : public Command {
 public:
  deleteEntryCommand(int r) :
    Command("deleteEntryCommand"),
    row(r) { }
  virtual void execute(/*database<Book> &*/);
  virtual void undo(/*database<Book> &*/);
 private:
  int row;
  Book delEntry;
}; 

//########################## undoCommand ###########################//

class undoCommand : public Command {
 public:
  undoCommand () : Command("undoCommand"){ } ;
  virtual void execute(database<Book> &);
  virtual void execute();

};

//######################### sorting commands #######################//
class sortADBCommand : public Command {
 public:
  sortADBCommand() : Command("sortADBCommand") { }
  virtual void execute(/*database<Book> &*/);
  virtual void undo(/*database<Book> &*/);
 private:
  database<Book> oldDB;
};

class sortATDBCommand : public Command {
 public:
  sortATDBCommand() : Command("sortATDBCommand") { }
  virtual void execute(/*database<Book> &*/);
  virtual void undo(/*database<Book> &*/);
 private:
  database<Book> oldDB;

};

class sortATPDBCommand : public Command {
 public:
  sortATPDBCommand() : Command("sortATPDBCommand") { }
  virtual void execute(/*database<Book> &*/);
  virtual void undo(/*database<Book> &*/);
 private:
  database<Book> oldDB;

};

