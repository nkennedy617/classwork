#include <qapplication.h>
#include <qtable.h>

#include <string>
#include <vector>
#include <stack>
#include <sstream>

#include "mainWidget.h"
#include "helpDialog.h"

dbSingleton * dbSingleton::instance = 0;

std::stack< Command* > Command::commandHistory;

int main( int argc, char* argv[] ) {

    QApplication app( argc, argv );

    mainWidget* mainWindow = new mainWidget();
    app.setMainWidget(mainWindow);
    mainWindow->setCaption("Book Database");
    mainWindow->resize(615,500);
    mainWindow->show();

    int retValue = app.exec();
    delete mainWindow;

    return retValue;
}
