#include <iostream>
#include <fstream>
#include <string>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qrect.h>
#include <qlabel.h>
#include <qtextedit.h>
#include <qlineedit.h>
#include <qcolor.h>

#include "insertDialog.h"

insertDialog::insertDialog(Book * e): QDialog(0,"Insert Dialog",true) {

  setCaption("Insert Dialog");
  resize(400,200);

  // Creat top-level layout
  entry = e;
  layoutWidget = new QWidget(this,"layout");
  layoutWidget->resize(400,200);
  QVBoxLayout *layout  = new QVBoxLayout(layoutWidget,1,1,"layout" );
  QHBoxLayout *layout2 = new QHBoxLayout(QBoxLayout::LeftToRight,"sub Layout");
  
  title = new QLineEdit(layoutWidget,"title");
  QLabel* tLabel = new QLabel("Title:",layoutWidget,"Title");

  author = new QLineEdit(layoutWidget,"author");
  QLabel* aLabel = new QLabel("Author:",layoutWidget,"Author");

  published = new QLineEdit(layoutWidget,"published");
  QLabel* pLabel = new QLabel("Published:",layoutWidget,"Published");

  title->setReadOnly(false);
  layout->addWidget(tLabel,0,0);
  layout->addWidget(title,0,0);

  layout->addWidget(aLabel,0,0);
  layout->addWidget(author,0,0);

  layout->addWidget(pLabel,0,0);
  layout->addWidget(published,0,0);

  layout->addLayout(layout2);
  layout2->setAlignment(Qt::AlignBottom);

  // Create Buttons
  QPushButton *insertBtn = new QPushButton(layoutWidget);
  insertBtn->setText("Insert");
  insertBtn->setFixedWidth(400);
  insertBtn->setFixedHeight(30);
  
  QToolTip::add(insertBtn,"Insert Item");
  layout2->addWidget(insertBtn,1,0);

  // Connect Buttons to slots
  
  //connect (closeBtn,SIGNAL(clicked()),this,SLOT(accept()));
  connect (insertBtn,SIGNAL(clicked()),this,SLOT(dataChanged()));

}

void insertDialog::dataChanged() {

  if ( (title->text().length() > 0) &&
       (author->text().length() > 0) &&
       (published->text().length() > 0) ) {

    entry->setTitle(title->text().stripWhiteSpace().ascii());
    entry->setAuthor(author->text().stripWhiteSpace().ascii());
    entry->setPublished(published->text().stripWhiteSpace().ascii());

    validInsert = true;
  }
  else
    validInsert = false;

 
  accept();

}
