#include <iostream>
#include <fstream>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qrect.h>
#include <qlabel.h>
#include <qtextedit.h>
#include <qcolor.h>

#include "helpDialog.h"

helpDialog::helpDialog():QDialog(0,"Help Dialog",true) {

  setCaption("Help Dialog");
  resize(400,200);

  // Creat top-level layout
  layoutWidget = new QWidget(this,"layout");
  layoutWidget->resize(400,200);
  QVBoxLayout *layout  = new QVBoxLayout(layoutWidget,1,1,"layout" );
  QHBoxLayout *layout2 = new QHBoxLayout(QBoxLayout::LeftToRight,"sub Layout");
  
  text = new QTextEdit(layoutWidget,"text");
  text->setWordWrap(QTextEdit::WidgetWidth);

  std::string readme,temp;
  std::fstream fin("README",std::ios::in);

  fin >> temp;
  while (!fin.eof()) {
    readme += " " + temp;
    fin >> temp;
  }

  text->setText(readme.c_str());
  text->setReadOnly(true);
  layout->addWidget(text,0,0);
  layout->addLayout(layout2);
  layout2->setAlignment(Qt::AlignBottom);

  // Create Buttons
  QPushButton *closeBtn = new QPushButton(layoutWidget);
  closeBtn->setText("Close");
  closeBtn->setFixedWidth(400);
  closeBtn->setFixedHeight(30);

  QToolTip::add(closeBtn,"Close Help");
  layout2->addWidget(closeBtn,1,0);

  // Connect Buttons to slots
  
  connect (closeBtn,SIGNAL(clicked()),SLOT(accept()));

}
