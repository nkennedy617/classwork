#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtable.h>
#include <qstatusbar.h>
#include <qfiledialog.h>
#include <qaction.h>
#include <qtooltip.h>
#include <qframe.h>
#include <qfont.h>

#include <sstream>
#include <string>
#include <vector>

#include "mainWidget.h"
#include "helpDialog.h"
#include "insertDialog.h"
#include "dbSingleton.h"
#include "selectDialog.h"

// mainWidget Constructor

mainWidget::mainWidget(QWidget *parent, const char *name )
  : QWidget( parent, name ),loadedDBFilename("") {

  // Creat top-level layout
  QBoxLayout *topLayout = new QVBoxLayout( this, 10 );
  
  // Create menu bar
  QMenuBar *menubar = new QMenuBar(this);
  menubar->setSeparator(QMenuBar::InWindowsStyle);
  QPopupMenu *fileMenu = new QPopupMenu(this);
  QPopupMenu *editMenu = new QPopupMenu(this);
  QPopupMenu *sortMenu = new QPopupMenu(this);
  QPopupMenu *viewMenu = new QPopupMenu(this);
  QPopupMenu *helpMenu = new QPopupMenu(this);
  menubar->insertItem("&File",fileMenu);
  menubar->insertItem("&Edit",editMenu);
  menubar->insertItem("&Sort",sortMenu);
  menubar->insertItem("&View",viewMenu);
  menubar->insertItem("&Help",helpMenu);
  topLayout->setMenuBar(menubar);

  // Define actions for menu items

  QAction* newDBAction       = new QAction("New DB","&New",CTRL+Key_N,this,"New DB");
  QAction* loadDBAction      = new QAction("Load DB","&Load",CTRL+Key_L,this,"Load DB");
  QAction* saveDBAction      = new QAction("Save DB","&Save",CTRL+Key_S,this,"Save DB");

  QAction* insertDBAction      = new QAction("Insert Item","&Insert",CTRL+Key_I,this,"Insert Item");
  QAction* deleteDBAction      = new QAction("Delete Item","&Delete",CTRL+Key_D,this,"Delete Item");
  QAction* undoDBAction        = new QAction("Undo Last","Undo Last",CTRL+Key_Z,this,"Undo Last");
  QAction* viewAuthorDBAction  = new QAction("Author View","Author &View",CTRL+Key_V,this,"Author View");
  QAction* viewCenturyDBAction = new QAction("Century View","&Century View",CTRL+Key_C,this,"View Century");
  QAction* viewStandardDBAction = new QAction("Standard View","Standard Vie&w",CTRL+Key_W,this,"Standard View");

  QAction* exitProgramAction = new QAction("Quit","&Quit",CTRL+Key_Q,this,"Quit");
  QAction* helpAction        = new QAction("Show Help","&Help",CTRL+Key_H,this,"Show Help");

  QAction* sortADBAction     = new QAction("Compound Sort By: Author",
					   "&Author",CTRL+Key_A,this,"Sort DB");
  QAction* sortATDBAction    = new QAction("Compound Sort By: Author -> Title",
					   "Author, &Title",CTRL+Key_T,this,"Sort DB");
  QAction* sortATPDBAction   = new QAction("Compound Sort By: Author -> Title -> Published   ",
					   "&Author, Title, &Published",CTRL+Key_P,this,"Sort DB");


  connect (newDBAction, SIGNAL(activated()),this,SLOT(newDB()));
  connect (loadDBAction,SIGNAL(activated()),this,SLOT(fileOpen()));
  connect (saveDBAction,SIGNAL(activated()),this,SLOT(saveFile()));
  connect (exitProgramAction,SIGNAL(activated()),qApp,SLOT(quit()));

  connect (insertDBAction,SIGNAL(activated()),this,SLOT(insertItem()));
  connect (deleteDBAction,SIGNAL(activated()),this,SLOT(deleteItem()));
  connect (undoDBAction,SIGNAL(activated()),this,SLOT(undoLast()));
  connect (viewAuthorDBAction,SIGNAL(activated()),this,SLOT(authorViewDB()));
  connect (viewCenturyDBAction,SIGNAL(activated()),this,SLOT(centuryViewDB()));
  connect (viewStandardDBAction,SIGNAL(activated()),this,SLOT(standardViewDB()));
  
  connect (sortADBAction,SIGNAL(activated()),this,SLOT(ASort()));
  connect (sortATDBAction,SIGNAL(activated()),this,SLOT(ATSort()));
  connect (sortATPDBAction,SIGNAL(activated()),this,SLOT(ATPSort()));
  connect (helpAction,SIGNAL(activated()),this,SLOT(displayHelp()));


  // Add Actions to menu
  newDBAction->addTo(fileMenu);
  loadDBAction->addTo(fileMenu);
  saveDBAction->addTo(fileMenu);
  exitProgramAction->addTo(fileMenu);
  fileMenu->insertSeparator(2);

  insertDBAction->addTo(editMenu);
  deleteDBAction->addTo(editMenu);
  undoDBAction->addTo(editMenu);

  sortADBAction->addTo(sortMenu);
  sortATDBAction->addTo(sortMenu);
  sortATPDBAction->addTo(sortMenu);

  viewAuthorDBAction->addTo(viewMenu);
  viewCenturyDBAction->addTo(viewMenu);
  viewStandardDBAction->addTo(viewMenu);
  helpAction->addTo(helpMenu);

  // Create table
  mainTable = new QTable(0,3,this);
  mainTable->setTopMargin( 25 );
  setCaption("Book Management Database");
  
  QHeader *header = mainTable->horizontalHeader();

  header->setLabel( 0, QObject::tr( "Author" ), 185 );
  header->setLabel( 1, QObject::tr( "Title" ), 265 );
  header->setLabel( 2, QObject::tr( "Published" ), 80 );

  mainTable->setColumnWidth(0,185);
  mainTable->setColumnWidth(1,265);
  mainTable->setColumnWidth(2,90);

  topLayout->addWidget(mainTable);

  // Add Buttons
  QBoxLayout *buttons = new QHBoxLayout(topLayout);

  //##################//
  //# Create Buttons #//
  //##################//

  QPushButton* loadBtn = new QPushButton(this);
  QPushButton* helpBtn = new QPushButton(this);
  QPushButton* quitBtn = new QPushButton(this);

  // Setup Buttons
  loadBtn->setText("Load Default");
  helpBtn->setText("Help");
  quitBtn->setText("Quit");

  loadBtn->setFixedWidth(110);
  helpBtn->setFixedWidth(110);
  quitBtn->setFixedWidth(110);

  loadBtn->setFixedHeight(20);
  helpBtn->setFixedHeight(20);
  quitBtn->setFixedHeight(20);

  // Add Tooltips
  QToolTip::add(loadBtn,"Load Default DB");
  QToolTip::add(helpBtn,"Show Help");
  QToolTip::add(quitBtn,"Exit");  

  buttons->addWidget(loadBtn,10);
  buttons->addWidget(helpBtn,10);
  buttons->addWidget(quitBtn,10);

  // Connect Buttons to slots

  connect (loadBtn,SIGNAL(clicked()),SLOT(defaultLoad()));
  connect (helpBtn,SIGNAL(clicked()),SLOT(displayHelp()));
  connect (quitBtn,SIGNAL(clicked()),qApp,SLOT(quit()));
  connect (mainTable,SIGNAL(valueChanged(int,int)),this,SLOT(modifyItem(int,int)));

  //Create status bar

  QFrame *frame = new QFrame(this);
  frame->setFrameStyle(QFrame::HLine | QFrame::Raised);
  frame->setLineWidth(4);

  statusBar = new QStatusBar(this);

  QFont f("Helvetica",8,QFont::Normal);
  statusBar->setFont(f);

  statusBar->setFixedHeight(10);
  topLayout->addWidget(frame);
  topLayout->addWidget(statusBar);

}

void mainWidget::displayDB() const{

  dbSingleton * dba = dbSingleton::Instance();
  database<Book> db = dba->getDB();
  std::vector<Book> books = db.getDB();
  mainTable->setNumRows(0);
  std::vector<Book>::const_iterator ptr = books.begin();
  int numRow = 0;

  while (ptr != books.end()) {
    mainTable->setNumRows(mainTable->numRows()+1);
    Book first = *ptr;
    mainTable->setText( numRow, 0, first.getAuthor().c_str() );
    mainTable->setText( numRow, 1, first.getTitle().c_str() );
    mainTable->setText( numRow++, 2, first.getPublished().c_str() );
    ptr++;
  }

  /*

  std::vector<Book> test = db.get19Century();

  std::vector<Book>::iterator ptr2 = test.begin();
  while (ptr2 != test.end()) {
    std::cout << *ptr2 << std::endl;
    ptr2++;
  }

  
  std::vector<Book> test2 = db.getAuthor("Miller, Arthur");

  std::vector<Book>::iterator ptr3 = test2.begin();
  while (ptr3 != test2.end()) {
    std::cout << *ptr3 << std::endl;
    ptr3++;
  }
  */

}

// Private Signal Implementations

void mainWidget::fileOpen() {

  QString filename = 
    QFileDialog::getOpenFileName(QString::null,"Book Database Files (*.dat)",this,
				 "Open Database File","Choose a File");

  if ( !filename.isEmpty() ) {
    cmd = new loadDBCommand(filename.ascii());
    cmd->execute();
    delete cmd;
    displayDB();
    loadedDBFilename = filename.ascii();
  }

}

void mainWidget::defaultLoad() {

  statusBar->message("Loading Default DB");
  cmd = new loadDBCommand("files/books2.dat");
  cmd->execute();
  delete cmd;
  displayDB();
  statusBar->message("Default DB Loaded",2000);
  loadedDBFilename = "files/books2.dat";

}

void mainWidget::saveFile() {

  if (loadedDBFilename.length() == 0) {

    QString filename = 
      QFileDialog::getSaveFileName(QString::null,"Book Database Files (*.dat)",this,
				   "Save Database File","Choose a File");
    if ( !filename.isEmpty() ) {    
      loadedDBFilename = filename.ascii();
      statusBar->message("Need filename to save");
      statusBar->clear();
    }

  }
  
  if (loadedDBFilename.length() > 0) {
    cmd = new saveDBCommand(loadedDBFilename);
    cmd->execute();
    delete cmd;
    std::string messg = "Saved DB to " + loadedDBFilename;
    statusBar->message(messg.c_str(),5000);
  }
  else statusBar->message("No file defined",5000);

}

void mainWidget::newDB() {

  cmd = new newDBCommand();
  cmd->execute();
  mainTable->setNumRows(0);
  loadedDBFilename = "";
  displayDB();
  delete cmd;

}


void mainWidget::deleteItem() {
 
  int cRow = mainTable->currentRow();
  if (cRow >= 0) {
    cmd = new deleteEntryCommand(cRow);
    cmd->execute();
    displayDB();
  }

}

void mainWidget::undoLast() {

  cmd = new undoCommand();
  cmd->execute();
  displayDB();
  delete cmd;

}


void mainWidget::modifyItem(int row,int col) {
  
  std::string author      = ((mainTable->item(row,0))->text()).ascii();
  std::string title       = ((mainTable->item(row,1))->text()).ascii();
  std::string published   = ((mainTable->item(row,2))->text()).ascii();
  
  Book modEntry(author,title,published);
  cmd = new modifyEntryCommand(modEntry,row);
  cmd->execute();

}


void mainWidget::insertItem() {

  Book * newEntry = new Book();
  
  insertDialog* inserter = new insertDialog(newEntry);
  statusBar->message("Displaying Insert Dialog");
  inserter->exec();
  statusBar->clear();
  
  if (inserter->isValid()) {
    cmd = new insertEntryCommand(*newEntry);
    cmd->execute();
    displayDB();
  }
  
  delete inserter;
  delete newEntry;
}

void mainWidget::displayHelp() const{

  helpDialog* helper = new helpDialog();
  statusBar->message("Displaying Help");
  helper->exec();
  delete helper;
  statusBar->clear();

}

void mainWidget::ASort() {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();

  if (db.numItems() > 0) {
    cmd = new sortADBCommand();
    cmd->execute();
    displayDB();
    statusBar->message("Performed Sort on Author",3000);
  }
  else statusBar->message("No DB Loaded",2000);

}


void mainWidget::ATSort() {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();

  if (db.numItems() > 0) {
    cmd = new sortATDBCommand();
    cmd->execute();
    displayDB();
    statusBar->message("Performed Compound Sort: Author -> Title",3000);
  }
  else statusBar->message("No DB Loaded",2000);

}

void mainWidget::ATPSort() {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();

  if (db.numItems() > 0) {
    cmd = new sortATPDBCommand();
    cmd->execute();
    displayDB();
    statusBar->message("Performed Compound Sort: Author -> Title -> Published",3000);
  }
  else statusBar->message("No DB Loaded",2000);

}

void mainWidget::authorViewDB() {

  if (mainTable->numRows() > 0) {
    dbSingleton * dbs = dbSingleton::Instance();
    database<Book> db = dbs->getDB();
    
    selectDialog* selecter = new selectDialog(db.getDB(),1);
    statusBar->message("Selecting Author View");
    selecter->exec();
    statusBar->clear();
    
    if (selecter->isValid()) {
      View = db.getAuthor(selecter->getAuthSelection());
      displayView();    
    }
    
    delete selecter;
  }
  else statusBar->message("No DB Loaded",2000);
}

void mainWidget::displayView() const {

  mainTable->setNumRows(0);
  mainTable->setReadOnly(true);
  statusBar->message("--- READ ONLY VIEW ---");
  myMap::const_iterator ptr = View.begin();
  while (ptr != View.end()) {
    mainTable->setNumRows((ptr->first).getVal()+1);
    Book first = ptr->second;
    mainTable->setText( (ptr->first).getVal(), 0, first.getAuthor().c_str() );
    mainTable->setText( (ptr->first).getVal(), 1, first.getTitle().c_str() );
    mainTable->setText( (ptr->first).getVal(), 2, first.getPublished().c_str() );
    ptr++;
  }

}

void mainWidget::standardViewDB() {

  displayDB();
  mainTable->setReadOnly(false);
  statusBar->clear();
}

void mainWidget::centuryViewDB() {

  if (mainTable->numRows() > 0) {
    dbSingleton * dbs = dbSingleton::Instance();
    database<Book> db = dbs->getDB();
    
    selectDialog* selecter = new selectDialog(db.getDB(),2);
    statusBar->message("Selecting Century View");
    selecter->exec();
    statusBar->clear();
    
    if (selecter->isValid()) {
      View = db.getCentury(selecter->getCentSelection());
      displayView();    
    }
  
    delete selecter;
    
  }

}
