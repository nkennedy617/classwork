#include <qtable.h>
#include <qstatusbar.h>

#include "Command.h"
#include "database/visitor.h"

class mainWidget : public QWidget {

Q_OBJECT

private slots:
   void fileOpen();
   void saveFile();
   void newDB();
   void insertItem();
   void authorViewDB();
   void centuryViewDB();
   void standardViewDB();
   void deleteItem();
   void undoLast();
   void displayHelp() const;
   void defaultLoad();
   void modifyItem(int,int);
   void ASort();
   void ATSort();
   void ATPSort();

public:
   mainWidget( QWidget *parent = 0, const char *name = 0 );
    
private:
    QTable                 *mainTable;
    QStatusBar             *statusBar;
    std::vector<Book>      items;
    Command *              cmd;
    std::string            loadedDBFilename;
    myMap                  View;

    void displayDB() const;
    void displayView() const;
};

