#include <iostream>
#include "Command.h"

using std::cout;
using std::endl;

//####################### loadDBCommand Methods ####################//

void loadDBCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  while (commandHistory.size() > 0) commandHistory.pop();
  db.load(filename);
  std::cout << "Filename = " << filename << std::endl;
  dbs->setDB(db);
}

//######################## newDBCommand Methods ####################//
void newDBCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  while (commandHistory.size() > 0) commandHistory.pop();
  db.close();
  db.load(filename);
  std::cout << "NEWING" << std::endl;
  dbs->setDB(db);   
}
//##################################################################//


//####################### saveDBCommand Methods ####################//
void saveDBCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  std::cout << "SINGLETON SAVE" << std::endl;
  //db.saveFile(db.getFilename());
  db.saveFile(filename);
}
//##################################################################//



//################### modifyEntryCommand Methods ###################//
void modifyEntryCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  origEntry = db.lookupItem(row);
  db.modify(modEntry,row);
  commandHistory.push(this);
  dbs->setDB(db);
}

void modifyEntryCommand::undo(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  db.modify(origEntry,row);
  dbs->setDB(db);
}
//##################################################################//

//################## insertEntryCommand Methods ####################//

void insertEntryCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  db.addItem(newEntry);
  commandHistory.push(this);
  dbs->setDB(db);

}

void insertEntryCommand::undo(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  int size = db.numItems();
  db.deleteItemIndex(size-1);
  dbs->setDB(db);
}

//##################################################################//

//###################### deleteEntryCommand ########################//

void deleteEntryCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  delEntry = db.lookupItem(row);
  db.deleteItemIndex(row);
  commandHistory.push(this);
  dbs->setDB(db);
}

void deleteEntryCommand::undo(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  db.addItemIndex(delEntry,row);
  dbs->setDB(db);
}


//####################### sorting commands #######################//

void sortADBCommand::execute(/*database<Book> & db*/) { 
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  oldDB = db;
  db.ASort();
  commandHistory.push(this);
  dbs->setDB(db);
}

void sortADBCommand::undo(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  dbs->setDB(oldDB);
}

void sortATDBCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  oldDB = db;
  db.ATSort();
  commandHistory.push(this);
  dbs->setDB(db);
}

void sortATDBCommand::undo(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  dbs->setDB(oldDB);
}


void sortATPDBCommand::execute(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  database<Book> db = dbs->getDB();
  oldDB = db;
  db.ATPSort();
  commandHistory.push(this);
  dbs->setDB(db);
}

void sortATPDBCommand::undo(/*database<Book> & db*/) {
  dbSingleton * dbs = dbSingleton::Instance();
  dbs->setDB(oldDB);
}

//##################################################################//
void undoCommand::execute(database<Book> & db) {
  
  if (Command::commandHistory.size() == 0) return;

  Command* cmd  = commandHistory.top();
  std::cout << "Undoing last command: " << cmd->getName() << std::endl;
  cmd->undo(db);
  commandHistory.pop();
  
  delete cmd;
  
}

void undoCommand::execute() {
  
  if (Command::commandHistory.size() == 0) return;

  Command* cmd  = commandHistory.top();
  std::cout << "Undoing last command: " << cmd->getName() << std::endl;
  cmd->undo();
  commandHistory.pop();
  
  delete cmd;
  
}

