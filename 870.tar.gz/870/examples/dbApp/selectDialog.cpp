#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtable.h>
#include <qstatusbar.h>
#include <qfiledialog.h>
#include <qaction.h>
#include <qtooltip.h>
#include <qframe.h>
#include <qfont.h>

#include <sstream>
#include <iostream>
#include <string>
#include <vector>

#include "selectDialog.h"
#include "dbSingleton.h"

// authorWidget Constructor

selectDialog::selectDialog(std::vector<Book> b,int m) : QDialog(0, "Select Dialog", true),
							mode(m),
							validSelect(false) {

  // Creat top-level layout
  QBoxLayout *topLayout = new QVBoxLayout( this, 10 );
  
  // Create menu bar
  QMenuBar *menubar = new QMenuBar(this);
  menubar->setSeparator(QMenuBar::InWindowsStyle);

  // Create table
  mainTable = new QTable(0,1,this);
  mainTable->setTopMargin( 25 );
  if (mode == 1) setCaption("Select Author...");
  else setCaption("Select Century...");
  
  QHeader *header = mainTable->horizontalHeader();

  if (mode == 1) header->setLabel( 0, QObject::tr( "Author" ), 185 );
  else header->setLabel( 0, QObject::tr( "Century" ), 185 );

  mainTable->setColumnWidth(0,185);
  topLayout->addWidget(mainTable);

  // Add Buttons
  QBoxLayout *buttons = new QHBoxLayout(topLayout);

  //##################//
  //# Create Buttons #//
  //##################//

  QPushButton* quitBtn = new QPushButton(this);

  // Setup Buttons
  if (mode == 1) quitBtn->setText("View Author's Books");
  else quitBtn->setText("View Books from Century");
  quitBtn->setFixedWidth(183);
  quitBtn->setFixedHeight(20);

  // Add Tooltips
  QToolTip::add(quitBtn,"View");  
  buttons->addWidget(quitBtn,10);

  // Connect Buttons to slots

  connect (quitBtn,SIGNAL(clicked()),this,SLOT(selected()));

  // Fill in map with authors
  
  vector<Book>::const_iterator ptr = b.begin();
  int row = 0;
  while (ptr != b.end()) {
    switch (mode) {
    case 1: itemMap.insert(std::map<std::string,int>::value_type(ptr->getAuthor(),row++));    break;
    case 2: 
      std::string temp = ptr->getPublished();  

      if (temp.length() == 4) temp = temp.substr(0,2);
      else if (temp.length() == 3) temp = temp.substr(0,1);
      else if (temp.length()  < 3) temp = "0";

      itemMap.insert(std::map<std::string,int>::value_type(temp,row++)); 
      break;
    }
    ptr++;
  }

  fillTable();

}

void selectDialog::fillTable() {
  // Fill in table

  std::map<std::string,int>::const_iterator ptr = itemMap.begin();
  int row = 0;

  while (ptr != itemMap.end()) {
    mainTable->setNumRows(mainTable->numRows() + 1);
    switch(mode) {
    case 1: 
      mainTable->setText( row++, 0, (ptr->first).c_str() ); 
      break;
    case 2: 
      std::string cent = ptr->first;
      int temp = 1 + QString(cent.c_str()).toInt();
      std::stringstream strm;
      strm << temp;
      std::string text;
      strm >> text;
      mainTable->setText( row++, 0, text.c_str() );
      break;
    }
    ptr++;
  }

}


void selectDialog::selected() {

  int row = mainTable->currentRow();
  if (row >= 0) {
    if (mode == 1) authorSelect    = ((mainTable->item(row,0))->text()).ascii();
    else if (mode == 2) centSelect = ((mainTable->item(row,0))->text()).toInt();
    validSelect = true;
  }

  accept();
}
