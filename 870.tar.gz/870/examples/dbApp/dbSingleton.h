#ifndef DBS_CLASS
#define DBS_CLASS 1

#include "database/Book.h"
#include "database/Database.h"

class dbSingleton {
 public:
  static dbSingleton * Instance();
  ~dbSingleton() { }
  const database<Book> & getDB() const { return db; }
  void setDB(const database<Book> & newDB) { db = newDB; }
  
 protected:
  dbSingleton() { }
  dbSingleton(const dbSingleton & ) { }

 private:
  static dbSingleton * instance;  
  database<Book> db;
  

};


#endif
