#include "dbSingleton.h"


dbSingleton * dbSingleton::Instance() {

  if (instance == 0)
    instance = new dbSingleton();

  return instance;

}
