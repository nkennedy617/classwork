//###########################################################################//
// Book.cpp                                                                  //
//                                                                           //
// Implementation of some of the methods for the Book class                  //
//###########################################################################//

#include "Book.h"
#include "visitor.h"
#include <string>

std::ostream & operator<<(std::ostream & out, const Book & bk) {
  
  out << bk.getAuthor() << " \"" << bk.getTitle() << "\" " 
      << bk.getPublished() << std::flush;

  return out;
}


std::istream & operator>>(std::istream & in, Book & bk) {
  
  int x,y,z = 0;
  char * line = new char[256];
  char * temp = new char[256];

  in.getline(line,256);
  
  if (strlen(line) > 1) {
    // Extract author's name
    x = 0;
    memset(temp,'\0',256);
    while (line[x] != '\"') temp[x] = line[x++];
    temp[x-1] = '\0';
    bk.setAuthor(temp);
    
    // Extract book title
    ++x;
    y = 0;
    memset(temp,'\0',256);
    while (line[x] != '\"') temp[y++] = line[x++];
    bk.setTitle(temp);
    
    // Extract published date
    x+=2;
    z = 0;
    memset(temp,'\0',256);
    while (line[x] != '\0') temp[z++] = line[x++];
    //bk.setPublished(atoi(temp));
    bk.setPublished(temp);
    
  }
  
  delete [] line;
  delete [] temp;
  
  return in;

}

bool operator==(const Book & bk1, const Book & bk2) {    

  
  if ( (bk1.getAuthor() == bk2.getAuthor()) && 
       (bk1.getTitle() == bk2.getTitle()) &&
       (bk1.getPublished() == bk2.getPublished()))
    return true;

  return false;
}


bool operator<(const Book & bk1, const Book & bk2) {    
  
  int aComp(strcmp((bk1.getAuthor()).c_str(),(bk2.getAuthor()).c_str()));
  int tComp(strcmp((bk1.getTitle()).c_str(),(bk2.getTitle()).c_str()));
  
  if (aComp < 0) return true;
  else if ( (aComp == 0) && (tComp < 0)) return true;
  else if ( (aComp == 0) && (tComp == 0) && 
	    (bk1.getPublished() < bk2.getPublished() )) return true;
  
  return false;
}

void Book::accept (Visitor & v) { v.visit(this); }
