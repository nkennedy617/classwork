#ifndef TL_CLASS 
#define TL_CLASS 1

template<class T,class U>
struct Typelist {
  typedef T Head;
  typedef U Tail;
};

class NullType { };


template<class tList, int index>
struct typeAt;

template <class Head, class Tail>
struct typeAt <Typelist<Head, Tail>, 0> {
   typedef Head Result;
};

template <class Head, class Tail, int index>
struct typeAt <Typelist<Head, Tail>, index> {
   typedef typename typeAt<Tail, index-1>::Result Result;
};


template <class tList>
struct Length;

template <class T, class U>
struct Length<Typelist<T, U> > {
   enum { value = 1 + Length<U>::value };
};

template <>
struct Length<NullType> {
   enum { value = 0 };
};


#endif
