#ifndef VISITOR_C
#define VISITOR_C 1

#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include "Book.h"

using std::vector;
using std::string;


class Integer {
 public:
  Integer(const int & i) : value(i) { }
  int getVal() const { return value; }
  void setVal(const int i) { value = i; }
 private:
  int value;
};

bool operator<(const Integer &, const Integer &);


typedef std::map<Integer,Book> myMap;

class Visitor {
public:
   virtual ~Visitor() {}
   virtual void visit(Book *) = 0;
};

class CenturyVisitor : public Visitor {
 public:
  CenturyVisitor(const int & c) : targCent(c),count(0) { };
  virtual void visit(Book *);
  myMap getCentury() { return centMap; }
 private:
  myMap centMap;
  int targCent;
  int count;
};


class spAuthor : public Visitor {
 public:
  spAuthor(string a) : key(a),count(0) { };
  virtual void visit(Book *);
  myMap getAuthor() { return authorMap; }
 private:
  string key;
  myMap authorMap;
  int count;

};

#endif
