//###########################################################################//
// Book.h                                                                    //
//                                                                           //
// Header file for my Book class. This class is used in this program as the  //
// object type stored in the database.                                       //
//                                                                           //
// Implementation for some methods are in Book.cpp                           //
//###########################################################################//
//#include "String.h"

#ifndef BOOK_CLASS 
#define BOOK_CLASS 1

#include <iostream>
#include <string>

class Visitor;

class Book {

 public:  
  Book() {}
  virtual ~Book() {}
  //Book(std::string A,std::string T,int P) : Author(A),Title(T),Published(P) { }
  Book(std::string A,std::string T,std::string P) : Author(A),Title(T),Published(P) { }

  std::string getAuthor()    const { return Author;    }
  std::string getTitle()     const { return Title;     }
  std::string getPublished() const { return Published; }

  void setAuthor    (const std::string & auth) { Author    = auth; }
  void setTitle     (const std::string & titl) { Title     = titl; }
  void setPublished (const std::string & publ) { Published = publ; }

  void accept (Visitor & v);

 private:
  std::string Author;
  std::string Title;
  std::string Published;

};

std::ostream & operator<<(std::ostream &, const Book &);
std::istream & operator>>(std::istream &, Book &);
bool operator==(const Book &, const Book &);
bool operator<(const Book &, const Book &);       

struct sort_author {
   bool operator()(const Book & lhs,const Book & rhs) const {
     if (lhs.getAuthor() < rhs.getAuthor()) return true;
     return false;
   }
};

struct sort_title {
   bool operator()(const Book & lhs,const Book & rhs) const {
     if (lhs.getTitle() < rhs.getTitle()) return true;
     return false;
   }
};

struct sort_published {
   bool operator()(const Book & lhs,const Book & rhs) const {
     if (lhs.getPublished() < rhs.getPublished()) return true;
     return false;
   }
};


#endif
