#ifndef OB_CLASS
#define OB_CLASS 1

#include <algorithm>
#include <iterator>
#include "typelist.h"

template <typename CONTAINER, typename tLIST, int i = 0>
class orderBy {

  private:
  
  typedef typename CONTAINER::iterator ptr;
  enum { n = Length<tLIST>::value };
  typedef typename typeAt<tLIST,i>::Result compareType;

  public:

  orderBy(ptr begin, ptr end) {

    std::stable_sort (begin,end, compareType());
    std::pair<ptr,ptr> range;

    while (true) {
      range = std::equal_range(begin,end,*begin,compareType());
      if (range.first == end) return;
      orderBy<CONTAINER,tLIST,((i+1 == n)?(0xFFFF):(i+1))> order(range.first,range.second);
      begin = range.second;
    }//end while true

  }//orderBy constructor

};


template <typename CONTAINER, typename tLIST>
class orderBy<CONTAINER,tLIST,0xFFFF> {

 private:
  typedef typename CONTAINER::iterator ptr;

 public:
  orderBy(ptr begin,ptr end) { }
};

#endif
