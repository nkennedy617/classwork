#include <sstream>

#include "visitor.h"

bool operator<(const Integer & i1, const Integer & i2) { 
  return (i1.getVal() < i2.getVal());
}

void CenturyVisitor::visit(Book * b) {
  
  std::string published = b->getPublished();
  std::stringstream strm;
  strm << published;
  int number;
  strm >> number;
  
  int start = (targCent - 1) * 100;
  int end   = start + 99;

  if ( (number >= start) &&
       (number <= end) ) 
    centMap.insert(myMap::value_type(Integer(count++),*b));
}

void spAuthor::visit(Book * b) {
  if (b->getAuthor() == key) authorMap.insert(myMap::value_type(Integer(count++),*b));
}


