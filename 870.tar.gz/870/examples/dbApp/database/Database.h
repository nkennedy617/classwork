//###########################################################################//
// Database.h                                                                //
//                                                                           //
// Header file for database class. This is a templated class that uses       //
// a vector to store items of type DT.                                       //
//###########################################################################//

#include <vector>
#include <fstream>
#include <string>
#include "orderBy.h"
#include "visitor.h"

#ifndef DB_CLASS
#define DB_CLASS 1

template <class DT>
class database {

 public:     
  //database(const String & file) : filename(file) { } 
  database(const std::string & file) : filename(file),isNew(false) { }
 
  database() : isNew(true) { } 

  void load       ();  
  void load       (const std::string & file);
  void load       (const std::vector<DT> & newItems);
  void sort       ();
  void close      ();
  int  numItems   () const;
  void saveFile   () const;
  void print      () const;
  DT   lookupItem (const int & index) { return items[index]; }
  //void ATPSort    ();
  //  void TAPSort    ();
  //void PATSort    ();
  
  void ASort();
  void ATSort();
  void ATPSort();

  void addItem         (const DT &);
  void addItemIndex    (const DT &, const int &);
  void deleteItem      (const DT &);
  void deleteItemIndex (const int &);
  void saveFile        (const std::string &) const;
  void modify          (const DT &,const unsigned int &);
  void setFilename     (const std::string &);

  std::vector<DT>     getDB       () const;
  std::string const & getFilename () const;

  myMap getCentury (const int &);
  myMap getAuthor  (const std::string & key);

 private:    
  void save       (const std::string &) const;
  void visitAll   (Visitor &);
  void empty      ();
  
  std::vector<DT> items;
  std::string filename;
  bool isNew;

};            
             
//###########################################################################//
//           Implementations of templated database class methods             //
//###########################################################################//

template<class DT>
void database<DT>::load() {

  std::fstream input;
  DT item;
  empty();
  //  std::cout << "--- LOADING DATABASE ---" << std::endl;  
  input.open(filename.c_str(),std::ios::in);
  
  input >> item;  

  while (!input.eof()){
    items.push_back(item);    
    input >> item;
  }

  //std::cout << " --- FINISHED LOADING ---" << std::endl;

}

template<class DT>
void database<DT>::load (const std::string & file){
  filename = file;
  if (filename.length() > 0) load();
}


template<class DT>
void database<DT>::close(){
  empty();
  filename = "";
}


template<class DT>
void database<DT>::load(const std::vector<DT> & newItems) {
  
  typename std::vector<DT>::const_iterator ptr = newItems.begin();

  empty();
  while (ptr != newItems.end()) {
    items.push_back(*ptr);
    ptr++;
  }
    
}


template<class DT>
void database<DT>::empty() {
  items.clear();
}


template<class DT>
void database<DT>::sort() {
  //std::cout << "--- SORTING DATABASE ---\n" << std::endl;
  std::sort(items.begin(),items.end());
}

template<class DT>
void database<DT>::ASort() {

  typedef 
    Typelist<sort_author, NullType > AS;
  
  orderBy<std::vector<Book>, AS> ATPOrder(items.begin(),items.end());

}

template<class DT>
void database<DT>::ATSort() {

  typedef 
    Typelist<sort_author,
    Typelist<sort_title, NullType > > ATS;
  
  orderBy<std::vector<Book>, ATS> ATPOrder(items.begin(),items.end());

}

template<class DT>
void database<DT>::ATPSort() {

  typedef 
    Typelist<sort_author,
    Typelist<sort_title,
    Typelist<sort_published, NullType> > > ATPS;
  
  orderBy<std::vector<Book>, ATPS> ATPOrder(items.begin(),items.end());

}

/*
template<class DT>
void database<DT>::TAPSort() {

  typedef 
    Typelist<sort_title,
    Typelist<sort_author,
    Typelist<sort_published, NullType> > > TAPS;
  
  orderBy<std::vector<Book>, TAPS> TAPOrder(items.begin(),items.end());

}


template<class DT>
void database<DT>::PATSort() {

  typedef 
    Typelist<sort_published,
    Typelist<sort_author,
    Typelist<sort_title, NullType> > > PATS;
  
  orderBy<std::vector<Book>, PATS> PATOrder(items.begin(),items.end());

}
*/

template<class DT>
int database<DT>:: numItems () const { return items.size(); }


template<class DT>
void database<DT>::saveFile(const std::string & saveFile) const{

  // Commented out so that saving occurs automatically
  /*
  if (saveFile == filename) {
    std::cout << "!!! - This will overwrite the original file - !!!" << std::endl;
    std::cout << "\nAre you sure you want to do this? [y/n] " << std::flush;
    String response;
    std::cin >> response;

    if (response.isPositive()) save(saveFile);
  }
  else
    save(saveFile);
  */

  save(saveFile);
}


template<class DT>
void database<DT>::print() const {

  typename std::vector<DT>::const_iterator ptr = items.begin();

  std::cout << "--- PRINTING DATABASE ---" << std::endl;
  if (items.size() == 0) 
    std::cout << "Database Empty!" << endl;
  else {
    while (ptr != items.end())
      std::cout << *ptr++ << std::endl;
  }
  std::cout << "--- END OF DATABASE ---\n" << std::endl;

}


template<class DT>
void database<DT>::addItem (const DT & item) { items.push_back(item); }


template<class DT>
void database<DT>::addItemIndex (const DT & item,const int & row) { 

  typename std::vector<DT>::iterator result = items.begin();
  for (int i=0;i<row;i++) if (result != items.end()) ++result;
  if (result != items.end()) items.insert(result,item);
  else items.push_back(item);

}


template<class DT>
void database<DT>::deleteItem(const DT & item) {

  typename std::vector<DT>::iterator result = find(items.begin(),items.end(),item);  
  if (result != items.end()) items.erase(result,result+1);

}


template<class DT>
void database<DT>::deleteItemIndex(const int & index) {

  typename std::vector<DT>::iterator result = items.begin();
  for (int i=0;i<index;i++) if (result != items.end()) ++result;
  if (result != items.end()) items.erase(result,result+1);

}


template<class DT>
void database<DT>::saveFile() const {

  std::cout << "!!! - This will overwrite the original file - !!!" << std::endl;
  std::cout << "\nAre you sure you want to do this? [y/n] " << std::flush;
  std::string response;
  std::cin >> response;
  if ((response == "y") || (response == "Y") || (response == "Yes" ))
    save(filename);

}

template<class DT>
void database<DT>::modify(const DT & mod,const unsigned int & index) {

  if (index < items.size()) {
    items[index] = mod;
  }

}


template<class DT>
void database<DT>::save(const std::string & saveFile) const{

  std::fstream outfile;
  typename std::vector<DT>::const_iterator ptr = items.begin();

  outfile.open(saveFile.c_str(),std::ios::out);

  while (ptr != items.end()) {
    outfile << *ptr << std::endl;
    *ptr++;
  }

  outfile.close();

}

template<class DT>
std::vector<DT> database<DT>::getDB() const {

  return items;

}

template<class DT>
std::string const & database<DT>::getFilename () const {

  return filename;

}

template<class DT>
void database<DT>::setFilename (const std::string & f) {

  filename = f;

}

template<class DT>
void database<DT>::visitAll (Visitor & v){  
   typename vector<DT>::iterator ptr = items.begin();
   while ( ptr != items.end() ) {
      ptr->accept(v);
      ++ptr;
   }

}

template<class DT>
myMap database<DT>::getCentury (const int & c){
  CenturyVisitor visitor(c);
  visitAll(visitor);
  return visitor.getCentury();
}


template<class DT>
myMap database<DT>::getAuthor (const std::string & key){
  spAuthor visitor(key);
  visitAll(visitor);
  return visitor.getAuthor();
}


#endif
