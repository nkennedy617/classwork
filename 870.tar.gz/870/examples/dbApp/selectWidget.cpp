#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtable.h>
#include <qstatusbar.h>
#include <qfiledialog.h>
#include <qaction.h>
#include <qtooltip.h>
#include <qframe.h>
#include <qfont.h>

#include <sstream>
#include <string>
#include <vector>

#include "selectDialog.h"

// authorWidget Constructor

selectDialog::selectDialog() : QDialog(0, "Select Dialog", true) {

  // Creat top-level layout
  QBoxLayout *topLayout = new QVBoxLayout( this, 10 );
  
  // Create menu bar
  QMenuBar *menubar = new QMenuBar(this);
  menubar->setSeparator(QMenuBar::InWindowsStyle);

  // Define actions for menu items

  QAction* exitProgramAction = new QAction("Quit","&Quit",CTRL+Key_Q,this,"Quit");
  QAction* helpAction        = new QAction("Show Help","&Help",CTRL+Key_H,this,"Show Help");

  connect (exitProgramAction,SIGNAL(activated()),qApp,SLOT(quit()));
  connect (helpAction,SIGNAL(activated()),this,SLOT(displayHelp()));


  // Create table
  mainTable = new QTable(0,1,this);
  mainTable->setTopMargin( 25 );
  setCaption("Select Author...");
  
  QHeader *header = mainTable->horizontalHeader();

  header->setLabel( 0, QObject::tr( "Author" ), 185 );

  mainTable->setColumnWidth(0,185);
  topLayout->addWidget(mainTable);

  // Add Buttons
  QBoxLayout *buttons = new QHBoxLayout(topLayout);

  //##################//
  //# Create Buttons #//
  //##################//

  QPushButton* loadBtn = new QPushButton(this);
  QPushButton* helpBtn = new QPushButton(this);
  QPushButton* quitBtn = new QPushButton(this);

  // Setup Buttons
  loadBtn->setText("Load Default");
  helpBtn->setText("Help");
  quitBtn->setText("Quit");

  loadBtn->setFixedWidth(110);
  helpBtn->setFixedWidth(110);
  quitBtn->setFixedWidth(110);

  loadBtn->setFixedHeight(20);
  helpBtn->setFixedHeight(20);
  quitBtn->setFixedHeight(20);

  // Add Tooltips
  QToolTip::add(loadBtn,"Load Default DB");
  QToolTip::add(helpBtn,"Show Help");
  QToolTip::add(quitBtn,"Exit");  

  buttons->addWidget(loadBtn,10);
  buttons->addWidget(helpBtn,10);
  buttons->addWidget(quitBtn,10);

  // Connect Buttons to slots

  connect (quitBtn,SIGNAL(clicked()),qApp,SLOT(quit()));
  connect (mainTable,SIGNAL(valueChanged(int,int)),this,SLOT(modifyItem(int,int)));

  //Create status bar

  QFrame *frame = new QFrame(this);
  frame->setFrameStyle(QFrame::HLine | QFrame::Raised);
  frame->setLineWidth(4);

  statusBar = new QStatusBar(this);

  QFont f("Helvetica",8,QFont::Normal);
  statusBar->setFont(f);

  statusBar->setFixedHeight(10);
  topLayout->addWidget(frame);
  topLayout->addWidget(statusBar);

}

void selectDialog::displayDB() const{

  dbSingleton * dba = dbSingleton::Instance();
  database<Book> db = dba->getDB();
  std::vector<Book> books = db.getDB();
  mainTable->setNumRows(0);
  std::vector<Book>::const_iterator ptr = books.begin();
  int numRow = 0;
  while (ptr != books.end()) {
    mainTable->setNumRows(mainTable->numRows()+1);
    Book first = *ptr;
    mainTable->setText( numRow, 0, first.getAuthor().c_str() );
    mainTable->setText( numRow, 1, first.getTitle().c_str() );
    int published = first.getPublished();
    std::stringstream strm;
    strm << published;
    std::string number;
    strm >> number;
    mainTable->setText( numRow++, 2, number.c_str() );
    ptr++;
  }
  
  std::vector<Book> test = db.get19Century();

  std::vector<Book>::iterator ptr2 = test.begin();
  while (ptr2 != test.end()) {
    std::cout << *ptr2 << std::endl;
    ptr2++;
  }

  
  std::vector<Book> test2 = db.getAuthor("Miller, Arthur");

  std::vector<Book>::iterator ptr3 = test2.begin();
  while (ptr3 != test2.end()) {
    std::cout << *ptr3 << std::endl;
    ptr3++;
  }
  
}

// Private Signal Implementations

void selectDialog::fileOpen() {

  QString filename = 
    QFileDialog::getOpenFileName(QString::null,"Book Database Files (*.dat)",this,
				 "Open Database File","Choose a File");

  if ( !filename.isEmpty() ) {
    cmd = new loadDBCommand(filename.ascii());
    cmd->execute();
    delete cmd;
    displayDB();
    loadedDBFilename = filename.ascii();
  }

}

void selectDialog::newDB() {

  cmd = new newDBCommand();
  cmd->execute();
  mainTable->setNumRows(0);
  loadedDBFilename = "";
  displayDB();
  delete cmd;

}

void selectDialog::modifyItem(int row,int col) {
  
  std::string author = ((mainTable->item(row,0))->text()).ascii();
  std::string title  = ((mainTable->item(row,1))->text()).ascii();
  int    published   = ((mainTable->item(row,2))->text()).toInt();
  
  Book modEntry(author,title,published);
  cmd = new modifyEntryCommand(modEntry,row);
  cmd->execute();

}


void selectDialog::insertItem() {

  Book * newEntry = new Book();
  
  insertDialog* inserter = new insertDialog(newEntry);
  statusBar->message("Displaying Insert Dialog");
  inserter->exec();
  statusBar->clear();
  
  if (inserter->isValid()) {
    cmd = new insertEntryCommand(*newEntry);
    cmd->execute();
    displayDB();
  }
  
  delete inserter;
  delete newEntry;
}

