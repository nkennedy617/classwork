#include "visitor.h"
#include "lego.h"

bool PriceRangeEqual::operator()( const Lego & lego ) const {
    return lego.getPrice( ) >= minimum && lego.getPrice( ) <= maximum;
}

void SearchPricesVisitor::visit(Lego * lego) {
    legos.push_back(*lego);
}

void AveragePiecesVisitor::visit(Lego * lego) {
   ++count;
   totalPieces += lego->getPieces();
   
}
