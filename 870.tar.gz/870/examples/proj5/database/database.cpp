/* Seth Christie */

#include "database.h"
using std::fstream;

template < class T >
void Database< T >::modifyEntry( int index, const T& element ) {
  typename std::vector< T >::iterator ptr = data.begin( );
  if( index >= data.size( ) ) {
    std::cout << "Attempted to modify an entry out-of-bounds\n" << std::endl;
    exit( -1 );

  }
  for( int i = 0; i < index; i++ ) {
    ++ptr;

  }
  /* Our pointer should be at the element we need to modify */
  *ptr = element;
  
}

template < class T >
void Database< T >::load() {
   T element;
   fstream input;
   data.clear( );
   input.open(filename.c_str( ), fstream::in);
   input >> element;
   while ( !input.eof() ) {
      data.push_back( element );
      input >> element;

   }
 
}

template < class T >
void Database< T >::sort() {
   std::cout << "Calling sort\n";
   std::sort(data.begin(), data.end());

}

template < class T >
void Database< T >::print() const {
   typename std::vector< T >::const_iterator ptr = data.begin();
   if ( data.size() == 0 ) {
      std::cout << "No data in the set." << std::endl;
      return;
   }
   std::cout << "The data:" << std::endl;
   while ( ptr != data.end() ) {
      std::cout << *ptr << std::endl;
      ++ptr;
   }
}

template < class T >
void Database< T >::insertEntry( int index, const T& value ) {
    typename std::vector< T >::iterator ptr = data.begin( );
    if( index > data.size( ) ) {
        std::cout << "Attempted to insert an entry out-of-bounds\n" << std::endl;
        exit( -1 );

    }
    for( int i = 0; i < index; i++ ) {
        ++ptr;

    } 
    data.insert( ptr, value );
   
}

template < class T >
void Database< T >::deleteEntry( int index ) {
  typename std::vector< T >::iterator ptr = data.begin( );
  if( index >= data.size( ) ) {
    std::cout << "Attempted to delete an entry out-of-bounds\n" << std::endl;
    exit( -1 );

  }
  for( int i = 0; i < index; i++ ) {
    ++ptr;

  }
  /* Our pointer should be at the element we need to modify */
  data.erase( ptr, ptr + 1 );
  
}

template< class T >
Database< T > * DatabaseSingleton< T >::Instance( ) {
    if( _instance == 0 ) 
        _instance = new Database< T >( );
    return _instance;
    
}

template class Database< Lego >;
template class DatabaseSingleton< Lego >;
