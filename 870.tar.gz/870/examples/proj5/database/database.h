/* Seth Christie */
#ifndef DATABASE_H
#define DATABASE_H

#include <iostream>
#include <fstream>
#include "lego.h"

// MOVE THESE!!
using std::ios;

template< class T >
class Database {
public:
   Database( ) {}
   Database(const std::string &f) : filename(f) {}
   void setFilename( const std::string &f ) {
     filename = f;
   }

   void load();
   void sort();
   void clear() { filename = ""; data.clear( ); }
   void print() const;
   void modifyEntry( int index, const T& values );
   void insertEntry( int index, const T& values );
   void deleteEntry( int index );
   int size() const { return data.size( ); }
   const T& getEntry( int index ) { return data[ index ]; }
      
   Database< T >& operator=( const Database< T >* rhs ) {
     data = rhs->data;
     filename = rhs->filename;
     return *this;
     
   }
   std::vector< T > data;   
   
private:
   std::string filename;
};

template< class T >
class DatabaseSingleton {
  public:
    static Database< T > * Instance( );
    ~DatabaseSingleton( ) {};

  protected:
    DatabaseSingleton( ) { }
    DatabaseSingleton( const DatabaseSingleton & ) { }

  private:
    static Database< T > * _instance;

};

#endif
