#ifndef _VISITORH
#define _VISITORH

#include <algorithm>
#include <vector>
using std::vector;

class Lego;

class Visitor {
public:
   virtual ~Visitor() {}
   virtual void visit(Lego *) = 0;
};

class AveragePiecesVisitor : public Visitor {
public:
   AveragePiecesVisitor() : totalPieces(0), count(0) {}
   virtual void visit(Lego *);
   float getAveragePieces() const {
      if ( count > 0 ) {
         return totalPieces / count;
      }
      return 0.0;
   }
private:
   float totalPieces;
   unsigned int count;
};

class PriceRangeEqual {
public:
    PriceRangeEqual( float min, float max ) : minimum( min ), maximum( max ) { }
    bool operator()( const Lego & lego ) const;
private:
    float minimum;
    float maximum;
};

class SearchPricesVisitor : public Visitor {
public:
    SearchPricesVisitor( float min, float max ) : minimum( min ), maximum( max ) { }
    virtual void visit(Lego *);
    const vector< Lego > & getPriceRange( ) {
        std::vector< Lego > return_list;
        PriceRangeEqual pre( minimum, maximum );
        vector< Lego >::iterator ptr = find_if(legos.begin(), legos.end(), pre);
        while( ptr != legos.end( ) ) {
            return_list.push_back( *ptr );
            ++ptr;
            ptr = find_if(ptr, legos.end( ), pre);
        }
        legos = return_list;
        return legos;
    }
    private:
        float minimum, maximum;
        std::vector< Lego > legos;
};

#endif
