/* Seth Christie */

#include "lego.h"
#include "visitor.h"

ostream & operator<<(ostream &out, const Lego &lego) {
   out << lego.getItem() << '\t'
       << lego.getTitle() << '\t'
       << lego.getPieces() << '\t'
       << lego.getPrice();
   return out;
}

fstream & operator>>(fstream &in, Lego &lego) {
   std::string s;
   getline( in, s );
   lego.setItem( atoi( s.c_str( ) ) );
   getline( in, s );
   lego.setTitle(s);
   getline( in, s );
   lego.setPieces( atoi( s.c_str( ) ) );
   getline( in, s );
   lego.setPrice( atof( s.c_str( ) ) );
   lego.print( );
   return in;

}

void Lego::print( ) const {
  std::cout << item << '\t'
            << title << '\t'
            << pieces << '\t'
            << price << '\t';
  std::cout << std::endl;

}
 
void Lego::update( const std::vector<std::string>& values ) {
  setItem( atoi( values[0].c_str( ) ) );
  setTitle(values[1]);
  setPieces( atoi( values[2].c_str( ) ) );
  setPrice( atof( values[3].c_str( ) ) );
  std::cout << "Updated to:" << std::endl;
  print();

}

void Lego::accept( Visitor & v ) { v.visit(this); }

bool Lego::operator==( const Lego &rhs ) const {
  return( (item == rhs.getItem()) && (title == rhs.getTitle()) &&
          (pieces == rhs.getPieces()) && (price == rhs.getPrice()) );

}
