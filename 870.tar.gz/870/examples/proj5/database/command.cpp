#include <fstream>
#include <ctime>
#include "command.h"


void ExitCommand::execute( ) {
   // Nothing to do!
}

void LoadCommand::execute( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Received a load request" << std::endl;
    db->setFilename( filename );
    db->load( );
    delete this;
    
}

void SaveCommand::execute( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Received a save request" << std::endl;
    std::fstream output;
    output.open( filename.c_str( ), std::fstream::out );
    db->setFilename( filename );
    
    for( unsigned int i = 0; i < database_entries.size( ); i++ ) {
        output << database_entries[ i ] << std::endl;
    }
    delete this;
    
}

void UndoCommand::execute( ) {
    std::cout << "Received an undo request" << std::endl;
    if( commandStack.empty( ) ) {
        std::cout << "Command stack is empty: Cannot undo!" << std::endl;
        return;
    }
    Command * cmd = commandStack.top();
    cmd->undo( );
    delete cmd;
    commandStack.pop();
    delete this;
    
}

void InsertCommand::execute( ) { 
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Executing insert command." << std::endl;
    commandStack.push( this );
    Lego item;
    db->insertEntry( index, item );
    
}

void InsertCommand::undo( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Undoing insert command." << std::endl;
    std::vector< Lego >::iterator ptr = db->data.begin( );
    if( index >= db->data.size( ) ) {
        std::cout << "Attempted to undo a insert that resulted in out-of-bounds" << std::endl;
        exit( -1 );
	
    }
    for( int i = 0; i < index; i++ )
        ++ptr;

     db->data.erase( ptr, ptr + 1 );
     
}

void InsertEntryCommand::execute( ) { 
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing insert entry command." << std::endl;
    commandStack.push( this );
    db->insertEntry( index, value );
    
}

void InsertEntryCommand::undo( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Undoing insert entry command." << std::endl;
    std::vector< Lego >::iterator ptr = db->data.begin( );
    if( index >= db->data.size( ) ) {
        std::cout << "Attempted to undo a insert that resulted in out-of-bounds" << std::endl;
        exit( -1 );
	
    }
    for( int i = 0; i < index; i++ )
        ++ptr;

     db->data.erase( ptr, ptr + 1 );
     
}

void ModifyCommand::execute( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing modify command." << std::endl;
    commandStack.push( this );
    db->modifyEntry( index, newValue );
 
}

void ModifyCommand::undo( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Undoing modify command." << std::endl;    
    db->data[ index ] = oldValue;
    
}


void DeleteCommand::execute( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing delete command." << std::endl;    
    value = db->getEntry( index );
    commandStack.push( this );
    db->deleteEntry( index );   
    
}

void DeleteCommand::undo( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Undoing delete command." << std::endl;
    db->insertEntry( index, value );
    
}

void ClearCommand::execute( ) {  
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing clear command." << std::endl;    
    tempDB = db;    
    commandStack.push( this );    
    db->clear( );
    
}

void ClearCommand::undo( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Undoing clear command." << std::endl;    
    *db = tempDB;
    
}

void SortCommand::undo( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::cout << "Undoing sort command." << std::endl;    
    *db = tempDB;
    
}

void ItemSortCommand::execute( ) {  
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing sort on item command." << std::endl;    
    tempDB = db;    
    commandStack.push( this );    
    order_by< std::vector< Lego >, Typelist< less_item, NullType > >
            o( db->data.begin( ), db->data.end( ) );
    
}

void ItemNameSortCommand::execute( ) {  
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing sort on item and name command." << std::endl;    
    tempDB = db;
    commandStack.push( this );    
    order_by< std::vector< Lego >, Typelist< less_item, Typelist< less_title, NullType > > >
            o( db->data.begin( ), db->data.end( ) );
    
}

void ItemNamePriceSortCommand::execute( ) {  
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Executing sort on item, name, and price command." << std::endl;    
    tempDB = db;    
    commandStack.push( this );    
    order_by< std::vector< Lego >, Typelist< less_item, 
                                                      Typelist< less_title, 
                                                          Typelist< less_price, NullType > > > >
            o( db->data.begin( ), db->data.end( ) );
    
}
