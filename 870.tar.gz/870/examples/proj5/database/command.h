#ifndef COMMAND_H
#define COMMAND_H

#include <fstream>
#include <string>
#include <list>
#include <stack>
#include "database.h"
#include "order_by.h"

using std::list;
using std::string;
using std::stack;
using std::fstream;
using std::ios;

class Command {
public:
    Command( ) { }
    virtual ~Command( ) { }
    virtual void execute( ) = 0;
    virtual void undo( ) { }
protected:
   static stack< Command *> commandStack;
};

class ExitCommand : public Command {
public:
   ExitCommand( ) : Command( ) {}
   void execute( );
private:
};

class UndoCommand : public Command {
public:
   UndoCommand( ) : Command( ) {}
   void execute( );
};

class LoadCommand : public Command {
public:
    LoadCommand( const std::string& f ) : Command( ), filename( f ) {}
    void execute( );
private:
    std::string filename;   
};

class SaveCommand : public Command {
public:
    SaveCommand( const std::string& f, std::vector< std::string >& de) : Command( ),
                            filename( f ), database_entries( de ) {}
   void execute( );
private:
   std::string filename;
   std::vector< std::string > database_entries;
};

class InsertCommand : public Command {
public:
   InsertCommand( int i ) : Command( ), index( i ) {}
   void execute( );
   virtual void undo( );
private:
   int index; 
};

class InsertEntryCommand : public Command {
public:
   InsertEntryCommand( int i, Lego v ) : Command( ), index( i ), value( v ) {}
   void execute( );
   virtual void undo( );
private:
   int index; 
   Lego value;
};

class ModifyCommand : public Command {
public:
   ModifyCommand( int i, const Lego & ov, const Lego &nv ) : 
	   Command( ), index( i ), oldValue( ov ), newValue( nv )  {}
   void execute( );
   virtual void undo( );
private:
   int index;
   Lego oldValue;
   Lego newValue;
};

class DeleteCommand : public Command {
public:
    DeleteCommand( int i ) : Command( ), index( i ) {}
   void execute( );
   virtual void undo( );
private:
   int index;
   Lego value;
};

class ClearCommand : public Command {
public:
   ClearCommand( ) : Command( ) {}
   void execute( );
   void undo( );
protected:
   Database< Lego > tempDB;
};

class SortCommand : public Command {
public:
    SortCommand( ) : Command( ) {}
   virtual void execute( ) = 0;
   virtual void undo( );
protected:
   Database< Lego > tempDB;
};

class ItemSortCommand : public SortCommand {
public:
    ItemSortCommand( ) : SortCommand( ) { }
    void execute( );
private:
};    

class ItemNameSortCommand : public SortCommand {
public:
    ItemNameSortCommand( ) : SortCommand( ) { }
    void execute( );
private:
};

class ItemNamePriceSortCommand : public SortCommand {
public:
    ItemNamePriceSortCommand( ) : SortCommand( ) { }
    void execute( );
private:
};

#endif
