/* Seth Christie */

#ifndef LEGO_H
#define LEGO_H

#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <algorithm>
#include <string>

using std::ostream;
using std::fstream;

class Visitor;

class Lego {
public:
   Lego() : item(0), title(""), pieces(0), price(0.0) {}
   Lego(const int newItem, const std::string &newTitle, 
      const int newPieces, const float newPrice) 
      : item(newItem), title(newTitle), pieces(newPieces), price(newPrice) {}
   Lego(const Lego &l) 
      : item(l.item), title(l.title), pieces(l.pieces), price(l.price) {}

   const int & getItem() const { return item; }
   const std::string & getTitle() const { return title; }
   const int & getPieces() const { return pieces; }
   const float & getPrice() const { return price; }
   void setItem(const int newItem) { item = newItem; }
   void setTitle(const std::string &newTitle) { title = newTitle; }
   void setPieces(const int newPieces) { pieces = newPieces; }
   void setPrice(const float newPrice) { price = newPrice; }

   bool operator<( const Lego &rhs ) const {  return item < rhs.item; }
   bool operator==( const Lego &rhs ) const; 
   Lego& operator=( const Lego &rhs ) { 
     item = rhs.item;
     title = rhs.title;
     pieces = rhs.pieces;
     price = rhs.price;
     return *this;

   }
   void print( ) const;
   void update( const std::vector<std::string>& values );
   void accept( Visitor& v );
private:
   int item;
   std::string title;
   int pieces;
   float price;
};

class LegoEqual {
  public:
    LegoEqual( const int newKey ) : key(newKey) {}
    bool operator() (const Lego &rhs) const {
      return key == rhs.getItem();
    }
  private:
    int key;
};

struct less_item {
    bool operator( )( const Lego &lhs, const Lego &rhs ) {
        return lhs.getItem( ) < rhs.getItem( );
    }
};

struct less_title {
    bool operator( )( const Lego &lhs, const Lego &rhs ) {
        return lhs.getTitle( ) < rhs.getTitle( );
    }
};

struct less_price {
    bool operator( )( const Lego &lhs, const Lego &rhs ) {
	return lhs.getPrice( ) < rhs.getPrice( );
    }
};

ostream & operator<<(ostream &out, const Lego &);
fstream & operator>>(fstream &in, Lego &);

#endif
