/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
#include <qfiledialog.h>
#include <qtoolbar.h>
#include <qlineedit.h>
#include <qlabel.h>
#include <sstream>
#include <string>

std::string filename;
std::stack< Command* > Command::commandStack;
QToolBar *editTools, *fileTools;

Database< Lego > * DatabaseSingleton< Lego >::_instance = 0;

void frmMain::init( ) { 
    std::cout << "Initialize" << std::endl;
    fileTools = new QToolBar( this, "file operations" );
    fileTools->setLabel( "File Operations" );
    fileNewAction->addTo( fileTools );
    fileOpenAction->addTo( fileTools );	 
    fileSaveAction->addTo( fileTools );
    
    editTools = new QToolBar( this, "edit operations" );
    editTools->setLabel( "Edit Operations" );
    editUndo->addTo( editTools );
    editTools->addSeparator( );
    editInsert->addTo( editTools );
    editDelete->addTo( editTools );
    
    tblDataview->setColumnWidth( 0, 100 );
    tblDataview->horizontalHeader()->setLabel( 0, tr( "Item" ) );
    tblDataview->setColumnWidth( 1, 200 );
    tblDataview->horizontalHeader()->setLabel( 1, tr( "Description" ) );
    tblDataview->setColumnWidth( 2, 100 );
    tblDataview->horizontalHeader()->setLabel( 2, tr( "Pieces" ) );
    tblDataview->setColumnWidth( 3, 100 );
    tblDataview->horizontalHeader()->setLabel( 3, tr( "Price" ) );
 
}

void frmMain::fileOpen()
{
    QString s =QFileDialog::getOpenFileName( "~/", "Databases (*.dat)",
                                              this, "open file dialog",
                                              "Choose a data file" );
    
    if( s == 0 )
        return;
    
    filename = s.ascii( );
    if( filename == "" ) return;

    Command* cmd_ptr = new LoadCommand( filename );
    cmd_ptr->execute( );
    
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
     
    if( database == 0 )
        std::cout << "Database is null " << std::endl;
    else {
        populate( database );
    }
    
}

void frmMain::fileSave()
{
    std::vector< std::string > database_entries;
    
    for( int i = 0; i < tblDataview->numRows( ); i++ ) {
        for( int j = 0; j < tblDataview->numCols( ); j++ ) {
            database_entries.push_back( tblDataview->text( i, j ).ascii( ) );
     
        }
        
    }
    Command* cmd_ptr = new SaveCommand( filename, database_entries );
    cmd_ptr->execute( );
       
}

void frmMain::fileSaveAs()
{
    QString s = QFileDialog::getSaveFileName(
                    "~/",
                    "Databases (*.dat)",
                    this,
                    "save file dialog"
                    "Save database as..." );
    
    if( s == 0 )
        return;
    
    filename = s.ascii( );
 
    if( filename == "" ) return;
    fileSave( );
    
}

void frmMain::about() 
{
    dummy = new frmDummy( this );
    dummy->show( );
        
}

void frmMain::clear()
{
    tblDataview->setNumCols( 4 );
    tblDataview->setNumRows( 0 );
    
}

void frmMain::clearAll()
{
    Command* cmd_ptr = new ClearCommand( );
    cmd_ptr->execute( );
    
    clear( );
    
}

void frmMain::contentsChanged( int i, int )
{
    Lego modified;
    if( tblDataview->text( i, 0 ) != 0 )
        modified.setItem( atoi( tblDataview->text( i, 0 ).ascii( ) ) );
    if( tblDataview->text( i, 1 ) != 0 )
       modified.setTitle( tblDataview->text( i, 1 ).ascii( ) );
    if( tblDataview->text( i, 2 ) != 0 )
       modified.setPieces( atoi( tblDataview->text( i, 2 ).ascii( ) ) );
    if( tblDataview->text( i, 3 ) != 0 )
       modified.setPrice( atof( tblDataview->text( i, 3 ).ascii( ) ) );
   
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
       
    Lego old = database->getEntry( i );
    Command* cmd_ptr = new ModifyCommand( i, old, modified );
    cmd_ptr->execute( );
        
}


void frmMain::sort()
{
    sortOnItem();
    
}

void frmMain::populate( Database< Lego >* database ) {
  populate( *database );
  
}

void frmMain::populate( Database< Lego >& database )
{
    clear( );
    
    tblDataview->setNumCols( 4 );
    tblDataview->setNumRows( database.size( ) );
    
    for( int i = 0; i < database.size( ); i++ ) {
        Lego current = database.getEntry( i );
        std::stringstream strm;
        string str;

        std::stringstream strm1;
        strm1 << current.getItem( ) << std::ends;
        str = strm1.str( );
        tblDataview->setText( i, 0, str.c_str( ) );
        tblDataview->setText( i, 1, current.getTitle( ).c_str( ) );

        std::stringstream strm2;
        strm2 << current.getPieces( ) << std::ends;
        str = strm2.str( );
        tblDataview->setText( i, 2, str.c_str( ) );

        std::stringstream strm3;
        strm3 << current.getPrice( ) << std::ends;
        str = strm3.str( );
        tblDataview->setText( i, 3, str.c_str( ) );

    }
    
}

void frmMain::sortOnItem()
{
    Command* cmd_ptr = new ItemSortCommand( );
    cmd_ptr->execute( );
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
    populate( database );
    
}

void frmMain::sortOnItemName()
{
    Command* cmd_ptr = new ItemNameSortCommand( );
    cmd_ptr->execute( );  
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
    populate( database );
    
}

void frmMain::sortOnItemNamePrice()
{
    Command* cmd_ptr = new ItemNamePriceSortCommand( );
    cmd_ptr->execute( );  
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
    populate( database );
    
}

void frmMain::deleteRecord()
{
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
    
    int row = tblDataview->currentRow( );
    if( tblDataview->isRowSelected( tblDataview->currentRow( ), true ) ) {
        Command* cmd_ptr = new DeleteCommand( tblDataview->currentRow( ) );
        cmd_ptr->execute( );
        populate( database );
        tblDataview->setCurrentCell( row - 1, 0 );
        return;
	
    }
    
    for( int i = 0; i < tblDataview->numRows( ); i++ ) {
        if( tblDataview->isRowSelected( i, true ) ) {
            Command* cmd_ptr = new DeleteCommand( i );
            cmd_ptr->execute( );
            populate( database );
            tblDataview->setCurrentCell( i - 1, 0 );
            return;
	   
        }

    }

}

void frmMain::insertRecord()
{
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
    
    for( int i = 0; i < tblDataview->numRows( ); i++ ) {
        if( tblDataview->isRowSelected( i, true ) ) {
            Command* cmd_ptr = new InsertCommand( i );
            cmd_ptr->execute( );
            populate( database );
            tblDataview->setCurrentCell( i, 0 );
            return;
	   
        }

    }
    Command* cmd_ptr = new InsertCommand( tblDataview->numRows( ) );
    cmd_ptr->execute( );
    populate( database );
    tblDataview->setCurrentCell( tblDataview->numRows( ) - 1, 0 );
    
}


void frmMain::undo()
{
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );    
    std::cout << "Received an undo command." << std::endl;
    int row = tblDataview->currentRow( );
    int col = tblDataview->currentColumn( );
    Command* cmd_ptr = new UndoCommand( );
    cmd_ptr->execute( );
    populate( database );
    if( row >= tblDataview->numRows( ) ) 
        tblDataview->setCurrentCell( row - 1, col );
    else 
        tblDataview->setCurrentCell( row - 1, col );
}


void frmMain::insertRecordWizard( )
{
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );    
    int index;
    add = new frmAdd( this );
    if( add->exec( ) ) {
        for( index = 0; index < tblDataview->numRows( ); index++ ) {
            if( tblDataview->isRowSelected( index, true ) ) {
                break;

            }
    
        }

        Lego modified;
        if( add->txtItem->text( ) != 0 )
            modified.setItem( atoi( add->txtItem->text( ).ascii( ) ) );
        if( add->txtName->text( ) != 0 )
           modified.setTitle( add->txtName->text( ).ascii( ) );
        if( add->txtPieces->text( ) != 0 )
           modified.setPieces( atoi( add->txtPieces->text( ).ascii( ) ) );
        if( add->txtPrice->text( ) != 0 )
           modified.setPrice( atof( add->txtPrice->text( ).ascii( ) ) );

        std::cout << modified << std::endl;
    
        Command* cmd_ptr = new InsertEntryCommand( index, modified );
        cmd_ptr->execute( );
        populate( database );

        tblDataview->setCurrentCell( index, 0 );
    }
}


void frmMain::averagePieces()
{
    AveragePiecesVisitor visitor;
    Database<Lego>* database = DatabaseSingleton< Lego >::Instance( );
    std::vector< Lego >::iterator ptr = database->data.begin( );
    while( ptr != database->data.end( ) ) {
        ptr->accept( visitor );
        ptr++;
    }
    
    std::stringstream strm;
    string str;
    strm <<  visitor.getAveragePieces( ) << std::ends;
    str = strm.str( );

    stats = new frmStats( this );
    stats->txtValue->setText( str.c_str( ) );
    stats->show( );
    std::cout << "Average pieces: " << visitor.getAveragePieces( ) << std::endl;
    
}


void frmMain::searchView()
{
    search = new frmSearch( this );
    search->show( );
}
