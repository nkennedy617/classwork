/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
#include <vector>
#include <map>
#include <string>
#include <sstream>


std::map< std::string, Lego > lookup_table;

void frmSearch::init( ) {
    Database< Lego > * db = DatabaseSingleton< Lego >::Instance( );
    std::vector< Lego >::iterator ptr = db->data.begin( );
    while( ptr != db->data.end( ) ) {
        lookup_table.insert( std::make_pair( ptr->getTitle( ), *ptr ) );
        ptr++;

    }
    tblDataview->setColumnWidth( 0, 100 );
    tblDataview->horizontalHeader()->setLabel( 0, tr( "Item" ) );
    tblDataview->setColumnWidth( 1, 200 );
    tblDataview->horizontalHeader()->setLabel( 1, tr( "Description" ) );
    tblDataview->setColumnWidth( 2, 100 );
    tblDataview->horizontalHeader()->setLabel( 2, tr( "Pieces" ) );
    tblDataview->setColumnWidth( 3, 100 );
    tblDataview->horizontalHeader()->setLabel( 3, tr( "Price" ) );
    
    std::cout << "The map has been constructed" << std::endl;

}

void frmSearch::searchDescriptions()
{
    int current_row = 0;
    
    tblDataview->setNumCols( 4 );
    tblDataview->setNumRows( 0 );
    
    std::string query = txtSearch->text( ).ascii( );
    std::map< std::string, Lego >::const_iterator ptr = lookup_table.begin( );
    while( ptr != lookup_table.end( ) ) {
        if( ptr->first.find( query ) == std::string::npos ) {
            ptr++;
            continue;
        }
        tblDataview->insertRows( current_row );
        Lego current = ptr->second;
	std::string str;

        std::stringstream strm1;
        strm1 << current.getItem( ) << std::ends;
        str = strm1.str( );
        tblDataview->setText( current_row, 0, str.c_str( ) );
        tblDataview->setText( current_row, 1, current.getTitle( ).c_str( ) );

        std::stringstream strm2;
        strm2 << current.getPieces( ) << std::ends;
        str = strm2.str( );
        tblDataview->setText( current_row, 2, str.c_str( ) );

        std::stringstream strm3;
        strm3 << current.getPrice( ) << std::ends;
        str = strm3.str( );
        tblDataview->setText( current_row, 3, str.c_str( ) );

        ptr++;
        current_row++;

    }

}


void frmSearch::searchPrices()
{
    tblDataview->setNumCols( 4 );
    tblDataview->setNumRows( 0 );  
    
    float min, max;
    int current_row = 0;
    min = atof( txtMin->text( ).ascii( ) );
    max = atof( txtMax->text( ).ascii( ) );
    
    SearchPricesVisitor visitor( min, max );
    Database< Lego > * database = DatabaseSingleton< Lego >::Instance( );
    std::vector< Lego >::iterator ptr = database->data.begin( );
    while( ptr != database->data.end( ) ) {
        ptr->accept( visitor );
        ptr++;
    }
    
    std::vector< Lego > legos = visitor.getPriceRange( );
    ptr = legos.begin( );
    while( ptr != legos.end( ) ) {
        tblDataview->insertRows( current_row );
        Lego current = *ptr;
        std::string str;

        std::stringstream strm1;
        strm1 << current.getItem( ) << std::ends;
        str = strm1.str( );
        tblDataview->setText( current_row, 0, str.c_str( ) );
        tblDataview->setText( current_row, 1, current.getTitle( ).c_str( ) );

        std::stringstream strm2;
        strm2 << current.getPieces( ) << std::ends;
        str = strm2.str( );
        tblDataview->setText( current_row, 2, str.c_str( ) );

        std::stringstream strm3;
        strm3 << current.getPrice( ) << std::ends;
        str = strm3.str( );
        tblDataview->setText( current_row, 3, str.c_str( ) );

        ptr++;
        current_row++;
	
    }
    
}
