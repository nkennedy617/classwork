#include <fstream>
#include <ctime>
#include "command.h"


void ExitCommand::execute(list<int> &) {
   // Nothing to do!
}

void InvalidCommand::execute(list<int> &) {
   cout << '\t' << "invalid command" << endl;
}

void LoadNumbersCommand::execute(list<int> & my_list) {
   tempList = my_list;
   commandStack.push(this);
   my_list.clear();
   fstream input;
   input.open("numbers.dat", ios::in);
   if ( !input) throw string("numbers.dat not found");
   int number;
   input >> number;
   while(!input.eof()) {
     my_list.push_back(number);
     input >> number;
   }
   input.close();
}

void LoadNumbersCommand::undo(list<int> & my_list) {
   my_list = tempList;
}

void SaveNumbersCommand::execute(list<int> & my_list) {
   fstream output;
   output.open("data", ios::out);
   list<int>::const_iterator ptr = my_list.begin();
   while(ptr != my_list.end()) {
     output << *ptr << endl;
     ++ptr;
   }
   output.close();
}

void GiveHelpCommand::execute(list<int> & ) {
   Menu * menu = Menu::Instance();
   menu->help();
}

void UndoCommand::execute(list<int> & my_list) {
   if ( commandStack.empty() ) return;
   Command * cmd = commandStack.top();
   cmd->undo(my_list);
   delete cmd;
   commandStack.pop();
}

void MakeNumberCommand::undo(list<int> & my_list) {
   my_list.pop_back();
}

void MakeNumberCommand::execute(list<int> & my_list) {
   commandStack.push(this);
   srand( time(0) );
   my_list.push_back(rand() % 100);
}

void PrintNumbersCommand::execute(list<int> & my_list) {
   list<int>::const_iterator ptr = my_list.begin();
   cout << "The list contains: " << endl;
   while ( ptr != my_list.end() ) {
      cout << *ptr << '\t';
      ++ptr;
   }
   cout << endl;
}

void SortNumbersCommand::execute(list<int> & my_list) {
   tempList = my_list;
   commandStack.push(this);
   my_list.sort();
}

void SortNumbersCommand::undo(list<int> & my_list) {
   my_list = tempList;
}

void NewCommand::execute(list<int> & my_list) {
   tempList = my_list;
   commandStack.push(this);
   my_list.clear();

}

void NewCommand::undo(list<int> & my_list) {
   my_list = tempList;

}
