// This main program and the include Menu class is written by
// Brian Malloy, for CpSc 360, Fall 2002.
// The program uses the Command pattern to manage a list of numbers
// The program includes an efficient "undo" command

#include "stringiterator.h"
#include "command.h"
using std::cin;

// This list of commands is flexible, provided that the list
// is terminated with the empty string:
string commands[]= {
      "exit", "help", "load", "save", "print",
      "sort", "find", "new", "make", "undo",
      "insert", "bye", "quit", "delete", "stat",
      ""};
Menu * Menu::_instance = 0;
stack< Command* > Command::commandStack;

Command* process_cmd(const string & cmd) {
   Command * cmd_ptr = NULL;
   if ( cmd == "help" ) {
      cout << "Help" << endl;
      cmd_ptr = new GiveHelpCommand("help");
   }
   else if ( cmd == "exit" ) cmd_ptr = new ExitCommand("exit");
   else if ( cmd == "quit" ) cmd_ptr = new ExitCommand("exit");
   else if ( cmd == "make" ) cmd_ptr = new MakeNumberCommand("make");
   else if ( cmd == "print" ) cmd_ptr = new PrintNumbersCommand("print");
   else if ( cmd == "sort" ) cmd_ptr = new SortNumbersCommand("sort");
   else if ( cmd == "load" ) cmd_ptr = new LoadNumbersCommand("load");
   else if ( cmd == "new" ) cmd_ptr = new NewCommand("new");
   else if ( cmd == "undo" ) cmd_ptr = new UndoCommand("undo");
   else {
      cout << "Not implemented yet!" << endl;
   }
   return cmd_ptr;
}

int main() {

   Menu * menu = Menu::Instance("cmd> ", commands);
   menu->help();
   list<int> my_list;
   Command * cmd_ptr;

   string command_line;
   // Specifying blank and tab as delimiters:
   while ( true ) {
      try {
         cout << *menu;
         getline(cin, command_line);
         StringIterator it(command_line, " \t");

         if ((*it).size()) {
            string cmd = menu->getCommand(*it);
            ++it;
            cmd_ptr = process_cmd(cmd);
            if ( cmd_ptr ) {
               if ( cmd_ptr->getName() == "exit" ) break;
               cmd_ptr->execute(my_list);
            }
         }
      }
      catch ( const string & msg ) { cout << '\t' << msg << endl; }
      catch ( ... ) { cout << "Uncaught exception!" << endl; }
   } // end of while loop
   cout << "Program terminating..." << endl;
}
