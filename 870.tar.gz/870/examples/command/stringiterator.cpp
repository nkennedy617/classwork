#include "stringiterator.h"

ostream& operator<<(ostream& out, const StringIterator& It){
   out	<< "Str = " << It.Str << endl
	<< "delim = ";
        for (int i = 0; i < 256; ++i)
           if (It.delim[i]) out << (char)i;
        out << endl;
	out << "index = " << It.index << endl;
   return out;
}

StringIterator& StringIterator::operator=(const StringIterator & it) { 
   memcpy(delim, it.delim, sizeof(it.delim));
   Str = it.Str; 
   index = it.index;
   return *this;
}

StringIterator& StringIterator::operator=(const string& S) { 
   Str = S; 
   index = 0;
   return *this;
}

string StringIterator::operator * () const {
   char buf[80];
   unsigned int buf_index = 0;
   unsigned int temp_index = index;
   while (temp_index < Str.length() && isDelim(Str[temp_index]) ) 
      temp_index++;
   while ( temp_index < Str.length() && !isDelim(Str[temp_index]) )
        buf[buf_index++] = Str[temp_index++];
   buf[buf_index] = '\0';
   string temp(buf);
   return temp;
}

void StringIterator::init(char* d){
   //memset(delim, sizeof(delim), 0);
   for (int i = 0; i < 256; ++i) delim[i] = false;
   while ( *d != 0 ) {
      delim[*d] = true;
      d++;
   }
   index = 0;
}

StringIterator::StringIterator(char* d){
   init(d);
   index = 0; 
}

StringIterator::StringIterator(const string& S, char* d) {
   init(d);
   Str = S;
   index = 0; 
}

StringIterator::StringIterator(const StringIterator & I) {
   memcpy(delim, I.delim, sizeof(delim));
   index = I.index;
   Str = I.Str;
}

inline bool StringIterator::isDelim(char ch) const {
   return delim[ch];
}

void StringIterator::operator++ () {
   while (index < Str.length() && isDelim(Str[index]) ) index++;
   while (index < Str.length() && !isDelim(Str[index]) ) index++;
   while (index < Str.length() && isDelim(Str[index]) ) index++;
}
