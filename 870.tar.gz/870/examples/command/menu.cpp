// This is file Menu.cpp

#include "menu.h"
#include <algorithm>
#include <assert.h>

Menu * Menu::Instance(const string& in_prompt, const string cmds[]) {
   if (_instance == 0) 
      _instance = new Menu(in_prompt, cmds);
   return _instance;
}

Menu * Menu::Instance() {
   if (_instance == 0) 
      throw "Need to use Instance(prompt, commands) first";
   return _instance;
}

ostream& operator<<(ostream & Out, const Menu& M){
   Out << M.prompt;
   return Out;
}

Menu::Menu(const string& in_prompt, const string cmds[]) 
   : prompt(in_prompt) {
   numberOfCommands = 0;

   while (cmds[numberOfCommands]!= "")
      commands.push_back( string(cmds[numberOfCommands++]) );    
   sort(commands.begin(), commands.end());
}

void Menu::help() { 
   cout << "The menu program only requires a unique command prefix." << endl;
   cout << "There are " << numberOfCommands << " valid commands: \n";
   vector<string>::const_iterator ptr = commands.begin();
   int count = 0;
   for ( ; ptr != commands.end(); ++ptr ) {
      cout << '\t' << (*ptr);
      if ( (++count % 6) == 0) cout << endl;
   }
   cout << endl;
}

unsigned int 
Menu::findAllMatches(vector<string> & temp, const string & cmd) {
   for (unsigned int i = 0; i < commands.size(); ++i) {
      if ( commands[i].find(cmd, 0) == 0 )
         temp.push_back(commands[i]);
   }
   return temp.size();
}


string 
Menu::getCommand(const string & cmd) {
   vector<string> temp;
   int number = findAllMatches(temp, cmd);
   if (number == 1) {
      return temp[0];
   }
   else if ( number > 1) throw string("prefix not unique");
   else if ( number == 0) {
      throw string("command not found"); 
   }
   else throw string("invalid command"); 
}
