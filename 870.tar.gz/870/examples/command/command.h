#include <fstream>
#include <string>
#include <list>
#include <stack>
#include "menu.h"
using std::list;
using std::string;
using std::stack;
using std::fstream;
using std::ios;

class Command {
public:
   Command(const string& n) : name(n) {}
   virtual ~Command() {}
   const string & getName() const { return name; }
   virtual void execute(list<int> &) = 0;
   void print() const { cout << "class: " << name << endl; }
   virtual void undo(list<int> &) {}
private:
   string name;
   Command() : name("unknown") {}
protected:
   static stack< Command *> commandStack;
};

class ExitCommand : public Command {
public:
   ExitCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
private:
};

class InvalidCommand : public Command {
public:
   InvalidCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
private:
};

class GiveHelpCommand : public Command {
public:
   GiveHelpCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
private:
};

class UndoCommand : public Command {
public:
   UndoCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
};

class MakeNumberCommand : public Command {
public:
   MakeNumberCommand(const string & name) : Command(name) {}
   virtual void undo(list<int> & );
   void execute(list<int> &);
};

class LoadNumbersCommand : public Command {
public:
   LoadNumbersCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
   virtual void undo(list<int> &);
private:
   list<int> tempList;
};

class SaveNumbersCommand : public Command {
public:
   SaveNumbersCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
};

class PrintNumbersCommand : public Command {
public:
   PrintNumbersCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
};

class SortNumbersCommand : public Command {
public:
   SortNumbersCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
   virtual void undo(list<int> &);
private:
   list<int> tempList;
};

class NewCommand : public Command {
public:
   NewCommand(const string & name) : Command(name) {}
   void execute(list<int> &);
   virtual void undo(list<int> &);
private:
   list<int> tempList;

};

