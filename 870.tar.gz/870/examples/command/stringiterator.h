
#ifndef ITERATORString_H
#define ITERATORString_H

#include <string>
#include <iostream>
using std::string;
using std::ostream;
using std::cout;
using std::endl;

class StringIterator{
public:
   StringIterator() 	{ init(""); }
   StringIterator(char * d);
   StringIterator(const string& S, char * d);
   StringIterator(const StringIterator &);
   inline string restOfLine() const 
	{ return Str.substr(index, Str.length()); }
   inline string theString() const { return Str; }
   void operator++();
   string operator * () const;
   inline void rewind() { index = 0; }
   StringIterator& operator=(const string& S);
   StringIterator& operator=(const StringIterator&);
   inline bool atEnd() const { return ( index >= Str.length() ); }
   friend 
   ostream& operator<<(ostream& Out, const StringIterator& It); 

private:
   unsigned int index;
   string  Str;
   char delim[256];
   inline bool isDelim(char ch) const;
   void init(char* d);
};

#endif
