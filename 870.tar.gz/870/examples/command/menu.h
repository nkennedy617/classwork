
// This file contains Menu.h, the definition of a singleton
// class to specify and maintain a list of commands.
// This class is used by the grade list program.

// The Singleton pattern is presented in the "Design Patterns"
// book on pages 127 through 134.

#include <string>
#include <vector>
#include <iostream>
using std::string;
using std::vector;
using std::ostream;
using std::cout;
using std::endl;

class Menu{

public:
   static Menu * Instance(const string &, const string cmds[]);
   static Menu * Instance();
   ~Menu() {};
   string getCommand(const string &);
   void help();
   unsigned int findAllMatches(vector<string> &, const string &);
   friend ostream& operator<<(ostream &, const Menu&);

protected:
   Menu(const string & inPrompt, const string cmds[]); 
   Menu();
   Menu(const Menu &);

private:
   static Menu * _instance;
   string prompt;
   vector<string> commands;
   int numberOfCommands;
};
