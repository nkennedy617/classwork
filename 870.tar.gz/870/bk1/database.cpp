#include "database.h"
#include <iostream>
#include <fstream>

using std::fstream;

void Database::load() {
   Movie movie;
   fstream input;
   input.open(filename.getBuf(), ios::in);
   input >> movie;
   while ( !input.eof() ) {
      movies.push_back( movie );
      input >> movie;
   }
}
void Database::print() const {
   vector<Movie>::const_iterator ptr = movies.begin();
   if ( movies.size() == 0 ) {
      cout << "No movies to watch, bummer!" << endl;
      return;
   }
   cout << "The movies:" << endl;
   while ( ptr != movies.end() ) {
      cout << *ptr << endl;
      ++ptr;
   }
}

