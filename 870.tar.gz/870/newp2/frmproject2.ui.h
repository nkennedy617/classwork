/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
#include "files/database.h"
#include "sstream"
using std::stringstream;
#include <qmessagebox.h>

void frmProject2::loadfile()
{
    QMessageBox::information(this, "Load WorkSpace ", "Load Workspace  Coming Up!");
   lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
  Database db("files/book.dat");
  db.load();   
  std::vector<Book> database = db.getDb();
  for (unsigned int i = 0; i < database.size(); ++i) {
     string name = database[i].getName();
     lbItem->insertItem(name.c_str());
     string author = database[i].getDirector();
     lbAuthor->insertItem(author.c_str());
     int rate = database[i].getLength();
     stringstream strm;
     strm << rate;
     string number;
     strm >> number;
     lbRate->insertItem(number.c_str());
  }
  Book book = db.getBook(0);
  string name = book.getName();
  lbItem->insertItem("test");
  lbItem->insertItem(name.c_str());
}

void frmProject2::slotNew(){
    QMessageBox::information(this, "New WorkSpace ", "New Workspace  Coming Up!");
    lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
}

void frmProject2::slotSave(){
    QMessageBox::information(this, "Oops", "Not Implemented");
}

void frmProject2::slotHelp(){

    QMessageBox::information(this, "Book Graphical Readme", 
       "Book Graphical is a landmark QT Designer Application\n "       "created by Nell Beatty, in an attempt to  master C++ via\n"
       "Assignment #2.  Save is a marker, but everything else\n"
       " should work!");
}

