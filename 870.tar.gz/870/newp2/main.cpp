#include <qapplication.h>
#include "frmproject2.h"

int main( int argc, char ** argv )
{
    QApplication a( argc, argv );
    frmProject2 *w =new frmProject2();
    a.setMainWidget(w);
    
    
    w->show();
    //a.connect( &a, SIGNAL( lastWindowClosed() ), &a, SLOT( quit() ) );
    return a.exec();
}
