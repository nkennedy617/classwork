#include "visitor.h"
#include "files/book.h"
#include <iostream>

void CountAuthorVisitor::visit(Book * r){
   string newauthor = r->getDirector();
   //bool mynew = true;
   author[newauthor] = author[newauthor] + 1;
//   for(int i; i<author.size(); ++i){
 //    if(author[i]==newauthor)
  //   {
   //      mynew=false;
        //break
    // }
     //else
     //{
      //   mynew =true; 
     //}
   //}
   //if(mynew==true)
    //  author.push_back(newauthor);
        count++;   
   //sum += (r->getWidth() * r->getHeight());
}

void CountRateVisitor::visit(Book * r){
   std::cout << "In Visitor " << r->getLength() << std::endl;
   sum += (r->getLength() );
   count++;   
}

