#include "database.h"
#include <iostream>
#include <fstream>
#include <algorithm>

using std::fstream; using std::sort;

void Database::load() {
   Book book;
   fstream input;
   input.open(filename.c_str(), ios::in);
   input >> book;
   while ( !input.eof() ) {
      books.push_back( book );
      input >> book;
   }
}

bool greater9(const Book &m1) {
	return (m1.getLength() >= 9);
   }

void Database::write(vector<Book> mybook) {
   fstream output;
   Book book;
   string tDir;
   string tName;
   int tLength;
   output.open(filename.c_str(), ios::out);
   for(unsigned int i=0; i < mybook.size(); ++i){
      book = mybook[i];
      tName = book.getName();
      tDir = book.getDirector(); 
      tLength = book.getLength();
      output << tName << std::endl;
      output << tDir << std::endl;
      output << tLength << std::endl;
   }
   output.close();
}

void Database::reload(vector<Book> mybook) {
   Book book;
   fstream input;
   input.open(filename.c_str(), ios::in);
   for(unsigned int i=0; i < mybook.size(); ++i){
      input <<book;
   }
   Database::load();
}

void Database::print() const {
   vector<Book>::const_iterator ptr = books.begin();
   if ( books.size() == 0 ) {
      cout << "No books to read, bummer!" << endl;
      return;
   }
   cout << "The books:" << endl;
   while ( ptr != books.end() ) {
      cout << *ptr << endl;
      ++ptr;
   }
}

void Database::myinsert(const Book & b) {
   books.push_back(b);
}

void Database::reinsert(const Book & b, const int & ind) {
   books.insert(books.begin() + ind, b);
}


void Database::remove(const int & index) {
   Book book;
   book=books[index] ;
   mydelete(book.getName());
}

void Database::mydelete(const string & key) {
   if(books.size() == 0 ) {
     cout << "No books in db " << endl;
     return;
   }
   BookEqual tmp(key);
   vector<Book>::iterator ptr = find_if(books.begin(), books.end(), tmp);
   if(ptr!=books.end() ) {
     books.erase(ptr);
     return;
   }
   cout << key << "not found in db " << endl;
}

void Database::modify(const string & oldKey, const string & newKey) {
  BookEqual tmp(oldKey);
  vector<Book>::iterator ptr = find_if(books.begin(), books.end(), tmp);
  if(ptr==books.end() ) {
     cout << oldKey << "not found in db" <<endl;
     return;
  }
  Book book(*ptr);
  cout << " Changing key for : " << book << endl;
  mydelete(oldKey);
  book.setName(newKey);
  myinsert(book);
}

void Database::modfirst() {
  Book tmp;
  string animal="kitty";
  tmp = books[1];
  tmp.setName(animal);
  books[1]=tmp;
  return;
}

int Database::size() {
  return books.size();
}


void Database::magicsort() {
  sort(books.begin(), books.end());
  return;
}
