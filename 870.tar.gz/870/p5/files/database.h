#ifndef __DATABASE_H__
#define __DATABASE_H__

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "book.h"
// MOVE THESE!!
using std::vector;
using std::cout; using std::endl;
using std::ios;

class Database {
public:
   static Database* Instance(const string f) {
      if (_instance == NULL) {
         _instance = new Database(f);
      }
      return _instance;
   }
   static Database* Instance() {
      if (_instance == NULL) {
         cout << "Oops, should instantiate first with filename" << endl;
      }
      return _instance;
   }
   void load();
   void write(vector<Book> mybook);
   void reload(vector<Book> mybook);
   void print() const;
   Book getBook(int index) const { return books[index]; }
   void magicsort() ;
   void modfirst();
   void remove(const int & );
   void mydelete(const string & );
   void myinsert(const Book &);
   void reinsert(const Book &, const int &);
   void modify(const string & oldKey, const string & newKey);
   int size();
   const std::vector<Book>& getDb() const { return books; }
   bool greater9(const Book &m1);
private:
   Database();
   Database(const string f) : filename(f) {}
   static Database* _instance;
   vector<Book> books;
   string filename;
};

#endif
