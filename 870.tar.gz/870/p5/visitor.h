#ifndef _VISITORH
#define _VISITORH

#include <map>
#include <string>
using std::string;

class Book;

class Visitor {
public:
   virtual ~Visitor() {}
   virtual void visit(Book *) = 0;
};

class CountAuthorVisitor : public Visitor {
public:
   CountAuthorVisitor() : sum(0), count(0) {}
   const std::map<string, int> & getAvg() const { return (author); }
   virtual void visit(Book *);
private:
   float sum;
   int count;
   //vector<string> author;
   std::map<string, int> author;
}; 

class CountRateVisitor : public Visitor {
public:
   CountRateVisitor() : sum(0), count(0) {}
   float getAvg() const { return (sum / count); }
   virtual void visit(Book *);
private:
   float sum;
   int count;
}; 

#endif
