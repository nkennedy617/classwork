#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include "files/database.h"
using std::vector;
using std::string;
using std::stack;
using std::fstream;
using std::ios;
using std::cout;
using std::endl;


class Command {
public:
   Command(const string& n) : name(n) {}
   virtual ~Command() {}
   const string & getName() const { return name; }
   //virtual void execute(list<int> &) = 0;
//   virtual void execute(vector<Book> &) = 0;
  virtual void execute()= 0 ;
//   virtual void execute() ;
   void print() const { cout << "class: " << name << endl; }
   //virtual void undo(vector<Book> &) {}
   virtual void undo() {}
private:
   string name;
   Command() : name("unknown") {}
protected:
   static stack< Command *> commandStack;
};


class UndoCommand : public Command {
public:
   UndoCommand(const string & name) : Command(name) {}
   //void execute(vector<Book> &);
   void execute();
};


class ModifyCommand : public Command {
public:
   ModifyCommand (const string & name, const string old, const string newone) : Command(name), oldkey(old), newkey(newone) {}
   //void execute(vector<Book> &);
   void execute();
   //virtual void undo(vector<Book> &);
   virtual void undo();
private:
   vector<Book> tempList;
   string oldkey;
   string newkey;
};


class InsertCommand : public Command {
public:
   InsertCommand (const string & name, const Book b) : Command(name), newbook(b) {}
   //void execute(vector<Book> &);
   void execute();
   //virtual void undo(vector<Book> &);
   virtual void undo();
private:
   vector<Book> tempList;
   Book newbook;
};


class DeleteCommand : public Command {
public:
   DeleteCommand (const string & name, const int i) : Command(name), index(i) {}
   void execute();
   virtual void undo();
private:
   vector<Book> tempList;
   int index;
   Book oldbook;
};



