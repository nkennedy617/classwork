/****************************************************************************
** Form interface generated from reading ui file 'insert_dialog.ui'
**
** Created: Fri May 7 14:34:00 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef INSERT_DIALOG_H
#define INSERT_DIALOG_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QLabel;
class QPushButton;
class QLineEdit;

class Insert_Dialog : public QDialog
{
    Q_OBJECT

public:
    Insert_Dialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~Insert_Dialog();

    QLabel* tlbRate;
    QLabel* tlbTitle;
    QLabel* tlbAuthor;
    QPushButton* pbOk;
    QLineEdit* leTitle;
    QLineEdit* leAuthor;
    QLineEdit* leRate;
    QPushButton* pbCancel;

protected:

protected slots:
    virtual void languageChange();

};

#endif // INSERT_DIALOG_H
