/****************************************************************************
** Form implementation generated from reading ui file 'insert_dialog.ui'
**
** Created: Wed May 5 20:10:46 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "insert_dialog.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a Insert_Dialog as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
Insert_Dialog::Insert_Dialog( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "Insert_Dialog" );

    tlbRate = new QLabel( this, "tlbRate" );
    tlbRate->setGeometry( QRect( 40, 280, 191, 61 ) );

    tlbTitle = new QLabel( this, "tlbTitle" );
    tlbTitle->setGeometry( QRect( 30, 40, 191, 61 ) );

    tlbAuthor = new QLabel( this, "tlbAuthor" );
    tlbAuthor->setGeometry( QRect( 30, 160, 191, 61 ) );

    pbOk = new QPushButton( this, "pbOk" );
    pbOk->setGeometry( QRect( 80, 380, 191, 61 ) );

    leTitle = new QLineEdit( this, "leTitle" );
    leTitle->setGeometry( QRect( 280, 30, 271, 41 ) );

    leAuthor = new QLineEdit( this, "leAuthor" );
    leAuthor->setGeometry( QRect( 290, 150, 261, 41 ) );

    leRate = new QLineEdit( this, "leRate" );
    leRate->setGeometry( QRect( 290, 260, 261, 51 ) );

    pbCancel = new QPushButton( this, "pbCancel" );
    pbCancel->setGeometry( QRect( 320, 370, 211, 71 ) );
    languageChange();
    resize( QSize(600, 480).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( pbOk, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( pbCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
Insert_Dialog::~Insert_Dialog()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void Insert_Dialog::languageChange()
{
    setCaption( tr( "Insert Dialog" ) );
    tlbRate->setText( tr( "Rate:" ) );
    tlbTitle->setText( tr( "Title:" ) );
    tlbAuthor->setText( tr( "Author:" ) );
    pbOk->setText( tr( "Ok" ) );
    pbCancel->setText( tr( "Cancel" ) );
}

