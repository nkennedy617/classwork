#ifndef BOOK__H
#define BOOK__H
#include <string>
#include <iostream>
using std::string; using std::ostream; using std::istream;

class Book {
public:
   Book() : name(""), director(""), length(0) {}
   Book(const string &n, const string &d, int l) 
   //Book(const string n, const string d, int l) 
      : name(n), director(d), length(l) {}
   Book(const Book &m) 
      : name(m.name), director(m.director), length(m.length) {}
   const string & getName() const { return name; }
   const string & getDirector() const { return director; }
   const int & getLength() const { return length; }
   bool operator<(const Book &m1) const {
      return (length < m1.length);
   }
   void setName(const string &n){
     name = n;
     return;
   } 
private:
   string name;
   string director;
   int length;
};

ostream & operator<<(ostream &out, const Book &);
istream & operator>>(istream &in, Book &); 

class BookEqual {
public:
   BookEqual (const string & n) : name(n) {}
   bool operator()(const Book & book) const {
     return name==book.getName();
   } 
private:
    string name;
};

struct less_first {
   bool operator()(Book const &lhs, Book const &rhs) const {
	return lhs.getName() < rhs.getName();
   }
};

struct less_last {
   bool operator()(Book const &lhs, Book const &rhs) const {
	return lhs.getDirector() < rhs.getDirector();
   }
};

struct less_id {
   bool operator()(Book const &lhs, Book const &rhs) const {
	return lhs.getLength() < rhs.getLength();
   }
};

struct less_last_first_id {
   bool operator()(Book const &lhs, Book const &rhs) const {
	return ((lhs.getDirector() < rhs.getDirector())?(true):
             ((lhs.getDirector() > rhs.getDirector())?(false):
             ((lhs.getName() < rhs.getName())?(true):
             ((lhs.getName() > rhs.getName())?(false):
             ((lhs.getLength() < rhs.getLength())?(true):
             ((lhs.getLength() > rhs.getLength())?(false):
             (false)))))));
   }
};


struct less_last_first {
   bool operator()(Book const &lhs, Book const &rhs) const {
	return ((lhs.getDirector() < rhs.getDirector())?(true):
             ((lhs.getDirector() > rhs.getDirector())?(false):
             ((lhs.getName() < rhs.getName())?(true):
             ((lhs.getName() > rhs.getName())?(false):
             (false)))));
   }
};

#endif
