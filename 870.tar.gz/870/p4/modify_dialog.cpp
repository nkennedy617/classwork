/****************************************************************************
** Form implementation generated from reading ui file 'modify_dialog.ui'
**
** Created: Wed May 5 20:11:04 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.2.0b1   edited May 5 14:15 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "modify_dialog.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a Modify_Dialog as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
Modify_Dialog::Modify_Dialog( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "Modify_Dialog" );

    tlbOldTitle = new QLabel( this, "tlbOldTitle" );
    tlbOldTitle->setGeometry( QRect( 40, 50, 191, 61 ) );

    pbOk = new QPushButton( this, "pbOk" );
    pbOk->setGeometry( QRect( 90, 390, 191, 61 ) );

    tlbNewTitle = new QLabel( this, "tlbNewTitle" );
    tlbNewTitle->setGeometry( QRect( 40, 170, 191, 61 ) );

    leOldTitle = new QLineEdit( this, "leOldTitle" );
    leOldTitle->setGeometry( QRect( 260, 50, 281, 41 ) );

    leNewTitle = new QLineEdit( this, "leNewTitle" );
    leNewTitle->setGeometry( QRect( 260, 160, 271, 41 ) );

    pbCancel = new QPushButton( this, "pbCancel" );
    pbCancel->setGeometry( QRect( 330, 380, 211, 71 ) );
    languageChange();
    resize( QSize(600, 480).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( pbOk, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( pbCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
Modify_Dialog::~Modify_Dialog()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void Modify_Dialog::languageChange()
{
    setCaption( tr( "Modify Dialog" ) );
    tlbOldTitle->setText( tr( "Old Title" ) );
    pbOk->setText( tr( "Ok" ) );
    tlbNewTitle->setText( tr( "New Title" ) );
    pbCancel->setText( tr( "Cancel" ) );
}

