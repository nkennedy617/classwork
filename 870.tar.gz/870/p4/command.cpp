#include <fstream>
#include <ctime>
#include <algorithm>
#include "command.h"

void DeleteCommand::execute() {
   Database* db = Database::Instance("files/book.dat");
   std::cout << "Here I am !" << std::endl;
   tempList=db->getDb();
   oldbook=tempList[index];
   db->remove( index );
   commandStack.push(this);
}

void DeleteCommand::undo() {
   Database* db = Database::Instance("files/book.dat");
   db->reinsert(oldbook, index);
}

void InsertCommand::execute() {
   Database* db = Database::Instance("files/book.dat");
   commandStack.push(this);
   db->myinsert(newbook) ;
}


void InsertCommand::undo() {
   Database* db = Database::Instance("files/book.dat");
   db->mydelete(newbook.getName());
}

void ModifyCommand::execute() {
   Database* db = Database::Instance("files/book.dat");
   commandStack.push(this);
   db->modify(oldkey,newkey); 
}


void ModifyCommand::undo() {
   Database* db = Database::Instance("files/book.dat");
   db->modify(newkey, oldkey);
}


void UndoCommand::execute() {
   if ( commandStack.empty() ) return;
   Command * cmd = commandStack.top();
   cmd->undo();
   delete cmd;
   commandStack.pop();
}

