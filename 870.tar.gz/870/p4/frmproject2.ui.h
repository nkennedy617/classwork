/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
#include "files/database.h"
#include "sstream"
#include "command.h"
#include "files/order_by.h"
using std::stringstream;
#include <qmessagebox.h>




void frmProject2::init()
{
   Database* db = Database::Instance("files/book.dat");
}

void frmProject2::loadfile()
{ 
    QMessageBox::information(this, "Load WorkSpace ", "Load Workspace  Coming Up!");
   lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
   Database* db = Database::Instance("files/book.dat");
   db->load();   
   std::vector<Book> database = db->getDb();
   for (unsigned int i = 0; i < database.size(); ++i) {
     string name = database[i].getName();
     lbItem->insertItem(name.c_str());
     string author = database[i].getDirector();
     lbAuthor->insertItem(author.c_str());
     int rate = database[i].getLength();
     stringstream strm;
     strm << rate;
     string number;
     strm >> number;
     lbRate->insertItem(number.c_str());
  }   
}

void frmProject2::slotNew(){
    QMessageBox::information(this, "New WorkSpace ", "New Workspace  Coming Up!");
    lbItem->clear();
    lbAuthor->clear();
    lbRate->clear();
}

void frmProject2::slotDelete(){
    QMessageBox::information(this, "Delete This Item", "Deleting This Item Now!");
    Database* db = Database::Instance("files/book.dat");
    int findex =0;
    findex =lbItem->currentItem();
    stringstream strm;
    strm << findex;
    string number;
    strm >> number;

    Command * cmd_ptr = NULL;
    cmd_ptr = new DeleteCommand("delete", findex);
    cmd_ptr->execute();
    
    std::vector<Book> database = db->getDb();

    lbItem->clear();
    lbAuthor->clear();
    lbRate->clear();
    for (unsigned int i =0; i < database.size(); ++i)
    {
      string name = database[i].getName();
      lbItem->insertItem(name.c_str());
      string author = database[i].getDirector();
      lbAuthor->insertItem(author.c_str());
      int rate = database[i].getLength();
      stringstream strm;
      strm << rate;
      string number;
      strm >> number;
      lbRate->insertItem(number.c_str());
   }
}

void frmProject2::slotInsert(){
    QMessageBox::information(this, "Insert This Item", "Inserting This Item Now!");
    Database* db = Database::Instance("files/book.dat");
    // Create a new dialog
    Insert_Dialog dlg( this );

    // Show it and wait for Ok or Cancel
    if( dlg.exec() == QDialog::Accepted )
    {
      // We got Ok

      // Extract the information from the dialog
      string name = dlg.leAuthor->text();
      string title = dlg.leTitle->text();
      string rate = dlg.leRate->text();

      Book b(title, name, atoi(rate.c_str()));
    
      //Book b("Malloy", "Great C++", 10);
      Command * cmd_ptr = NULL;
      cmd_ptr = new InsertCommand("insert",b);
      cmd_ptr->execute();

      std::vector<Book> database = db->getDb();
      lbItem->clear();
      lbAuthor->clear();
      lbRate->clear();
      for (unsigned int i =0; i < database.size(); ++i)
      {
        string name = database[i].getName();
        lbItem->insertItem(name.c_str());
        string author = database[i].getDirector();
        lbAuthor->insertItem(author.c_str());
        int rate = database[i].getLength();
        stringstream strm;
        strm << rate;
        string number;
        strm >> number;
        lbRate->insertItem(number.c_str());
      }
  }
}


void frmProject2::slotUndo(){
    QMessageBox::information(this, "Undo The Last Command", "Undoing The Last Command Now!");
    Database* db = Database::Instance("files/book.dat");
    Command * cmd_ptr = NULL;
    cmd_ptr = new UndoCommand("undo");
    cmd_ptr->execute();

    std::vector<Book> database = db->getDb();
    lbItem->clear();
    lbAuthor->clear();
    lbRate->clear();
    for (unsigned int i =0; i < database.size(); ++i)
    {
      string name = database[i].getName();
      lbItem->insertItem(name.c_str());
      string author = database[i].getDirector();
      lbAuthor->insertItem(author.c_str());
      int rate = database[i].getLength();
      stringstream strm;
      strm << rate;
      string number;
      strm >> number;
      lbRate->insertItem(number.c_str());
    }
}

void frmProject2::slotModify(){
    QMessageBox::information(this, "Modify This Item", "Modifying This Item Now!");
    Database* db = Database::Instance("files/book.dat");
     // Create a new dialog
    Modify_Dialog dlg( this );

    // Show it and wait for Ok or Cancel
    if( dlg.exec() == QDialog::Accepted )
    {
      // We got Ok
      // Extract the information from the dialog
      string modkey = dlg.leOldTitle->text();
      string nkey = dlg.leNewTitle->text();
   
    
      Command * cmd_ptr = NULL;
      cmd_ptr = new ModifyCommand("modify",modkey, nkey);
      cmd_ptr->execute();

      std::vector<Book> database = db->getDb();
      lbItem->clear();
      lbAuthor->clear();
      lbRate->clear();
      for (unsigned int i =0; i < database.size(); ++i)
      {
         string name = database[i].getName();
         lbItem->insertItem(name.c_str());
         string author = database[i].getDirector();
         lbAuthor->insertItem(author.c_str());
         int rate = database[i].getLength();
         stringstream strm;
         strm << rate;
         string number;
         strm >> number;
         lbRate->insertItem(number.c_str());
       }
  }   
}

void frmProject2::slotSave(){
    QMessageBox::information(this, "Oops", "Not Implemented");
}

void frmProject2::slotHelp(){

    QMessageBox::information(this, "Book Graphical Readme", 
       "Book Graphical is a landmark QT Designer Application\n "       "created by Nell Beatty, in an attempt to  master C++ via\n"
       "Assignment #3.  Save is a marker, but everything else\n"
       " should work! Sort Example button should sort the small test file.\n"
       " Sort Menu should sort the regular test file.");
}

void frmProject2::slotSort() {
    //read in the lbItem, lbAuthor, lbRate into a std::vector of books?
    QMessageBox::information(this, "Sort WorkSpace ", "Sort Workspace  Coming Up!");
    lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
  Database* db = Database::Instance();
  db->load();   
   std::vector<Book> database = db->getDb();
    
    
    order_by<std::vector<Book>, Typelist<less_first, NullType> >
	    o(database.begin(), database.end() );
    
    for (unsigned int i = 0; i < database.size(); ++i) {
     string name = database[i].getName();
     lbItem->insertItem(name.c_str());
     string author = database[i].getDirector();
     lbAuthor->insertItem(author.c_str());
     int rate = database[i].getLength();
     stringstream strm;
     strm << rate;
     string number;
     strm >> number;
     lbRate->insertItem(number.c_str());
  }
}


void frmProject2::slotSort2()
{
    //read in the lbItem, lbAuthor, lbRate into a std::vector of books?
    QMessageBox::information(this, "Sort WorkSpace ", "Sort Workspace  Coming Up!");
    lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
   Database * db = Database::Instance();
   db->load();   
   std::vector<Book> database = db->getDb();

    order_by<std::vector<Book>, Typelist<less_last_first, NullType> >
	    o(database.begin(), database.end() );

    for (unsigned int i = 0; i < database.size(); ++i) {
     string name = database[i].getName();
     lbItem->insertItem(name.c_str());
     string author = database[i].getDirector();
     lbAuthor->insertItem(author.c_str());
     int rate = database[i].getLength();
     stringstream strm;
     strm << rate;
     string number;
     strm >> number;
     lbRate->insertItem(number.c_str());
  }
}


void frmProject2::slotSort3()
{
    //read in the lbItem, lbAuthor, lbRate into a std::vector of books?
    QMessageBox::information(this, "Sort WorkSpace ", "Sort Workspace  Coming Up!");
    lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
  Database * db = Database::Instance();
  db->load();   
   std::vector<Book> database = db->getDb();

    order_by<std::vector<Book>, Typelist<less_last_first_id, NullType> >
	    o(database.begin(), database.end() );

    for (unsigned int i = 0; i < database.size(); ++i) {
     string name = database[i].getName();
     lbItem->insertItem(name.c_str());
     string author = database[i].getDirector();
     lbAuthor->insertItem(author.c_str());
     int rate = database[i].getLength();
     stringstream strm;
     strm << rate;
     string number;
     strm >> number;
     lbRate->insertItem(number.c_str());
  }

}


void frmProject2::slotSortExample()
{
    //read in the lbItem, lbAuthor, lbRate into a std::vector of books?
    QMessageBox::information(this, "Sort WorkSpace ", "Sort Workspace  Coming Up!");
    lbItem->clear();
   lbAuthor->clear();
   lbRate->clear();
  Database * db = Database::Instance();
  db->load();   
   std::vector<Book> database = db->getDb();

    order_by<std::vector<Book>, Typelist<less_last_first_id, NullType> >
	    o(database.begin(), database.end() );

    for (unsigned int i = 0; i < database.size(); ++i) {
     string name = database[i].getName();
     lbItem->insertItem(name.c_str());
     string author = database[i].getDirector();
     lbAuthor->insertItem(author.c_str());
     int rate = database[i].getLength();
     stringstream strm;
     strm << rate;
     string number;
     strm >> number;
     lbRate->insertItem(number.c_str());
  }

}
