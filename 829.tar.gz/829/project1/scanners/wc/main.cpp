#include <iostream>
int yylex();
extern FILE *yyin;
extern int letters;
extern int words;
extern int lines;
extern int chars;

int main(int argc, char *argv[]) {
   if ( argc == 2 ) {
      yyin = fopen(argv[1], "r");
   }
   yylex();
   std::cout << letters << " letters" << std::endl;
   std::cout << words << " words" << std::endl;
   std::cout << lines << " lines" << std::endl;
   std::cout << chars+letters << " chars" << std::endl;
}
