
/*   line 0 */

/************ 
   line 1;
   line 2;
 ************/

/* line 3;
   line 4
 */

// Where's the code?;

int main() {
   int x = 0;
   return 0;
}
