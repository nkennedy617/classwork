#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include "command.h"
#include "gmanager.h"

using std::cout;
using std::endl;

void BuildGraphCommand::printTypeInfo(
                        Container<Variable_Info>::const_iterator ptr) {
   cout << "\t\tvar: "          << ptr->getName() 
        << "\ttype: "           << ptr->getType().getName()
        << "\tcategory: "       << ptr->getType().getCategory().value()
        << "\tcategory,name: "  << ptr->getType().getCategory().getName()
        << "\tgetSignature: "   << ptr->getType().getCategory().getSignature()
        << endl;
}

bool BuildGraphCommand::isTemplate( const string & src ) const {
   return ( src.find('<', 0) < src.size() );
}

void BuildGraphCommand::printCinfoPtr() const {
  vector< Container<Class_Info>::const_iterator >::const_iterator 
  ptr = cinfoPtr.begin();
  cout << "Classes in cinfoPtr: " << endl;
  for ( ; ptr != cinfoPtr.end(); ++ptr) {
     cout << "\t" << (*ptr)->getName() << endl;
  }
}

void BuildGraphCommand::addLink( const string & src,
                                 const string & dest, int link_type ) {
   if ( link_type != header  ) {
     if ( (!isTemplate(src) && !GraphManager::Instance()->isClass(src)) ||
          (!isTemplate(dest) && !GraphManager::Instance()->isClass(dest)) ) {
         return;  // probably an enum or typedef (ugh!)
      }
   }
   //cout << "Adding link from "
        //<< src << " to " << dest
        //<< " of type: " << link_type << endl;
  Cluster& graph = GraphManager::Instance()->getGraph();
   if ( link_type == header ) {
     graph.insert( Node(src, "header", 1, 0) );
   }
   else if ( link_type == polymorphic ) {
     graph.addLink( src, dest, "polymorphic", 1, 0);
   }
   else if ( link_type == dependence ) {
     graph.addLink( src, dest, "dependence", 1, 0 );
   }
   else if ( link_type == inheritance ) {
     graph.addLink( src, dest, "inheritance", 1, 0 );
   }
   else if ( link_type == ownedElement ) {
     graph.addLink( src, dest, "ownedElement", 1, 0 );
   }
   else if ( link_type == composition || link_type == 15 ) {
     graph.addLink( src, dest, "composition", 1, 0 );
   }
   else if ( link_type == association || link_type == 115 ) {
     graph.addLink( src, dest, "association", 1, 0 );
   }
   else if ( link_type == 215 ) {
     // NOTE: This type is a second level pointer
     graph.addLink( src, dest, "association", 1, 0 );
   }
   else {
      std::stringstream buf;
      buf << link_type << '\0';
      string error("bad link_type in BuildGraphCommand::addLink");
      error += buf.str();
      throw string(error);
   }
}

void BuildGraphCommand::checkForPolymorphicLinks(const string& source,
                                                 const string& target) {
  vector< Container<Class_Info>::const_iterator >::const_iterator ptr =
    std::find_if(cinfoPtr.begin(), cinfoPtr.end(), SearchClassJar(target)); 
  if ( ptr == cinfoPtr.end() ) {
     cout << "ERROR: " << target << " NOT FOUND" << endl;
     return;
  }
  Container<Class_Info>::const_iterator cinfo_ptr = *ptr;
  const Container<Class_Info> kids_container = cinfo_ptr->children();
  for ( Container<Class_Info>::const_iterator kid = kids_container.begin();
        kid != kids_container.end();
        ++kid ) {
        addLink(source, kid->getName(), polymorphic);
        checkForPolymorphicLinks(source, kid->getName());
  }
}

void BuildGraphCommand::doNestedClassInfo(
                        const string& class_name,
                        const Container<Class_Info>& nestedClasses) {
   for ( Container<Class_Info>::const_iterator ptr = nestedClasses.begin();
         ptr != nestedClasses.end();
         ++ptr ) {
      ++nestedClassCount;
      string link_name = ptr->getName();
      GraphManager::Instance()->addClassToClassList(ptr->getName());
      // FOR NOW, CHECKING FOR TEMPLATE CLASS W/ No. Params:
      if ( ptr->templateParameters().size() > 0 ) {
         continue;
      }
      addLink(class_name, link_name, ownedElement);
   }
   buildClasses(nestedClasses);
}

void BuildGraphCommand::processFunctionLocals(
          const string& class_name,
          const Container<Variable_Info>& vars
                                            ) {
   for ( Container<Variable_Info>::const_iterator var_ptr = vars.begin();
         var_ptr != vars.end(); ++var_ptr ) {
      //cout << "\tParam: " << var_ptr->getName() << endl;
      string link_name = var_ptr->getType().getName();
      int link_type = 0;
      if ( var_ptr->getType().isUserDefined() ) {
         Container<DataType> temp = var_ptr->getType().templateArguments();
         link_type = var_ptr->getType().getCategory().value();
         if ( temp.size() > 0 ) {
            for ( Container<DataType>::const_iterator it = temp.begin();
                  it != temp.end();
                  ++it ) {
               // ERROR: If there is more than one template argument, the
               // following code will only get the last one.
               // Also, following code doesn't get transmission mode!
               link_name = var_ptr->getType().getName() +
                           "<" + it->getName() + ">";
            }
         }
         addLink( class_name, link_name, dependence );
         if ( link_type == 115 ) {
            // Actually, 115 is for pointers and reference, but both
            // are polymorphic, so we need to chec!
            // You can use getSignature to see if it's "*" or "&":
            //printTypeInfo(var_ptr);
            checkForPolymorphicLinks(class_name, link_name);
         }
      }
   }
}

void BuildGraphCommand::doClassFunctionInfo(
          const string& class_name,
          const Container<Function_Info>& vars
                                            ) {
   for ( Container<Function_Info>::const_iterator ptr = vars.begin();
         ptr != vars.end();
         ++ptr ) {
      //cout << "Function: " << ptr->getName() << endl;
      Container<Variable_Info> params = ptr->params();
      processFunctionLocals(class_name, params);
      Container<Variable_Info> locals = ptr->localVars();
      processFunctionLocals(class_name, locals);
   }
}

void BuildGraphCommand::doClassVariableInfo(
          const string& class_name,
          const Container<Variable_Info>& vars
                                            ) {
   for ( Container<Variable_Info>::const_iterator ptr = vars.begin();
         ptr != vars.end();
         ++ptr ) {
      if ( ptr->getType().isUserDefined() ) {
         Container<DataType> temp = ptr->getType().templateArguments();
         string link_name = ptr->getType().getName();
         if ( temp.size() > 0 ) {
         // It's a template instance variable; change link_name
            for ( Container<DataType>::const_iterator it = temp.begin();
                  it != temp.end();
                  ++it ) {
               string mode = it->getCategory().getSignature();
               link_name = ptr->getType().getName() +
                                  "<" + it->getName() + mode + ">";
               addLink( link_name, "", header );
               //cout << "Template for " << class_name << ": " 
                    //<< link_name << endl;
               int link_type = it->getCategory().value();
               if ( it->isUserDefined() ) {
                  addLink(link_name, it->getName(), link_type);
                  if ( link_type == 115 ) {
                     checkForPolymorphicLinks(link_name, it->getName());
                  }
               }
            }
         }
         int link_type = ptr->getType().getCategory().value();
         addLink(class_name, link_name, link_type);
         if ( link_type == 115 ) {
            // I don't think this will add polymorphic links if the
            // target(link_name) is a template instance -- need ASG!
            checkForPolymorphicLinks(class_name, link_name);
         }
      }
   }
}

void BuildGraphCommand::buildClasses( const Container<Class_Info>& classes) {
   // Have to put all of the classes in a list first, 
   // so that they're there when they are processed later:
   for ( Container<Class_Info>::const_iterator cinfo_ptr = classes.begin();
         cinfo_ptr != classes.end();
         ++cinfo_ptr ) {
      if ( cinfo_ptr->templateParameters().size() > 0 ) {
         continue; // template classes are not classes!
      }
      GraphManager::Instance()->addClassToClassList(cinfo_ptr->getName());
      cinfoPtr.push_back( cinfo_ptr );
      //Container<Class_Info> nestedClasses = cinfo_ptr->classDefsInClass();
      //if ( nestedClasses.size() > 0 ) {
         //doNestedClassInfo(class_name, nestedClasses);
      //}
   }
   //printCinfoPtr();
   for ( Container<Class_Info>::const_iterator cinfo_ptr = classes.begin();
         cinfo_ptr != classes.end();
         ++cinfo_ptr ) {
      string class_name = cinfo_ptr->getName();
      // FOR NOW, CHECKING FOR TEMPLATE CLASS W/ No. Params:
      if ( cinfo_ptr->templateParameters().size() > 0 ) {
         continue; // template classes are not classes!
      }
      // It's not a template class, so insert it
      addLink( class_name, "", header );
      Container<Class_Info> nestedClasses = cinfo_ptr->classDefsInClass();
      if ( nestedClasses.size() > 0 ) {
         doNestedClassInfo(class_name, nestedClasses);
      }
      Container<Class_Info> parents = cinfo_ptr->parents();
      if ( parents.size() > 0 ) {
         for ( Container<Class_Info>::const_iterator cinfo_ptr = parents.begin();
               cinfo_ptr != parents.end();
               ++cinfo_ptr ) {
            addLink( class_name, cinfo_ptr->getName(), inheritance );
         }
      }
      Container<Variable_Info> vars = cinfo_ptr->dataItems();
      if ( vars.size() > 0 ) {
         doClassVariableInfo(class_name, vars);
      }
      Container<Function_Info> fun = cinfo_ptr->funDefsInClass();
      if ( fun.size() > 0 ) {
         doClassFunctionInfo(class_name, fun);
      }
   }
}

void BuildGraphCommand::buildStuffInNamespace(
                        const Container<NameSpace_Info>& nsi) {
   for ( Container<NameSpace_Info>::const_iterator ptr = nsi.begin();
         ptr != nsi.end();
         ++ptr ) {
      //cout << "Namespace: " << ptr->getName() << endl;
      const Container<NameSpace_Info>& nnsi = ptr->nameSpaceDefs();
      if (nnsi.size() > 0) buildStuffInNamespace(nnsi);
      Container<Class_Info> classes = ptr->classDefs();
      buildClasses(classes);
   }
}

void BuildGraphCommand::execute() {
   Interface face(fileName);
   const Container<NameSpace_Info>& nsi = face.nameSpaces();
   buildStuffInNamespace(nsi);
}

