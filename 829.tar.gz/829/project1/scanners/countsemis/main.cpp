#include <iostream>
int yylex();
   extern int semi_colons;
   extern int comments;
   extern int comment_lines;

int main() {
   yylex();
   std::cout << comments << " comment structures" << std::endl;
   std::cout << comment_lines << " lines of comments" << std::endl;
   std::cout << semi_colons << " viable statements" << std::endl;
   return 0;
}
