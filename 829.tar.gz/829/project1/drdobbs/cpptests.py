import unittest, os, os.path, shutil, re, string

COMPILER_TYPE = 2
############################################################################
# User must specify the compiler call and link options:                    #
# 0 = keystone, 1 = gcc2.9x, 2 = gcc3.0.x, 3 = VC++, 4 = Borland, 5 = MIPS #
# 6 = edg, 7 = Portland, 8 = comeau, 9 = Intel, 10 - Watcom                #
############################################################################

class ListFailures:
   def __init__(self):
      self.failedTestList = []
   def add(self, fname):
      self.failedTestList += [ fname ]
   def __len__(self):
      return len(self.failedTestList)
   def __str__(self):
      return "\n".join(self.failedTestList)

failures = ListFailures()
class CppTestCase(unittest.TestCase):
   def __init__(self, testfun, fname):
      unittest.TestCase.__init__(self, testfun)
      #Compiler and file extensions
      self.compile = [ \
                     "/home/malloy/projects/parser/keystone/run %s.cpp",
                     "g++ -c -Wall -DGCC29x %s.cpp",
                     "g++ -Wall -w -c %s.cpp",
                     #"g++ -c -Wall -w -ansi -pedantic-errors -O0 %s.cpp",
                     "cl /Za /W4 /c -DMSVC6x %s.cpp",
                     "bcc32 -w- -q -c -DBORLAND55 %s.cpp",
                     "CC -c -DMIPS %s.cpp",
                     "/usr2/edg/release_3.2/bin/eccp --strict -c %s.cpp",
                     "pgCC -w -O0 -Xa -c %s.cpp",
                     "como -c %s.cpp",
                     "icc -ansi -w -O0 -c %s.cpp",
							"cl /Za /w /c %s.cpp"
                     ]
      self.link = [ \
                     "keystone does not link", \
                     "g++ -o %s.exe %s.o", \
                     "g++ -o %s.exe %s.o", \
                     "cl /nologo /w /Fe%s.exe %s.obj", \
                     "bcc32 -q -e%s.exe %s.obj", \
                     "CC -o %s.exe %s.o", \
                   "/usr2/edg/release_3.1/bin/eccp --strict -o %s.exe %s.cpp",\
                     "pgCC -o %s.exe %s.o",\
                     "como -o %s.exe %s.o",\
                     "icc -o %s.exe %s.o", \
							"cl /w /Fe%s.exe %s.obj"
                     ]

      #The rest are set automatically:
      self.fileName = fname
      self.toPass = not (fname[:4] == "fail")
      self.hasMain = 0
      self.directory = os.getcwd()

   def setUp(self):
      print "\n********************************************"
      print "\nTesting: %s.cpp" % self.fileName
      oldFile = open(self.fileName+".cpp", "r")
      currentline = oldFile.readline()
      while currentline:
         if re.search("main", currentline):
            self.hasMain = 1
            break;
         currentline = oldFile.readline()
      oldFile.close()

   def tearDown(self): pass

   # This function determines whether a test case conforms
   # to the ISO standard:
   def testExecute(self):
      executed = 0
      # different compilers require different combinations of calls
      compiled = (os.system(self.compile[COMPILER_TYPE] % self.fileName) == 0)
      if compiled and self.hasMain:
         linked = (os.system(self.link[COMPILER_TYPE] % \
            (self.fileName, self.fileName)) == 0)
         if linked:
            executed = (os.system("%s.exe" % self.fileName) == 0)

      if self.toPass and self.hasMain and compiled and executed:
         print "PASS: Semantics properly supported"

      elif self.toPass and self.hasMain and compiled and not executed:
         print "FAIL: did not execute properly"
         failures.add(self.fileName)

      elif self.toPass and self.hasMain and not compiled and not executed:
         print "FAIL: should have compiled"
         failures.add(self.fileName)

      elif self.toPass and not self.hasMain and compiled and not executed:
         print "PASS: compiled as expected"

      elif self.toPass and not self.hasMain and not compiled and not executed:
         print "FAIL: should have compiled"
         failures.add(self.fileName)

      elif not self.toPass and self.hasMain and compiled and executed:
         print "FAIL: executed but should't have"
         failures.add(self.fileName)

      elif not self.toPass and self.hasMain and compiled and not executed:
         print "PASS: program executed, semantics failed as expected"

      elif not self.toPass and self.hasMain and not compiled and not executed:
         print "PASS: didn't compile as expected"

      elif not self.toPass and not self.hasMain and compiled and not executed:
         print "FAIL: should not have compiled"
         failures.add(self.fileName)

      elif not self.toPass and not self.hasMain and \
         not compiled and not executed:
         print "PASS: didn't compile as expected"

      else:
         print "logic errors"
