#!/usr/bin/env python2.2
import unittest, fnmatch, os, sys, cpptests

def doTests(fullpath, directory):
   dirlist = os.listdir(fullpath)
   runner = unittest.TextTestRunner()
   suite = unittest.TestSuite()
   for fname in dirlist:
      if os.path.isfile(fullpath+'/'+fname)\
         and fnmatch.fnmatch(fname, "*.cpp"):
         gen = cpptests.CppTestCase("testExecute",\
            fname[:-4])
         suite.addTest( gen )
   runner.run(suite)

def cleanUp(fullpath):
   dirlist = os.listdir(fullpath)
   for fname in dirlist:
      if os.path.isfile(fullpath+'/'+fname) and\
         (fnmatch.fnmatch(fname, "*.o")
         or fnmatch.fnmatch(fname, "*.obj")
         or fnmatch.fnmatch(fname, "*.tds")
         or fnmatch.fnmatch(fname, "*.ti")
         or fnmatch.fnmatch(fname, "*.exe")):
         os.remove(fname)

if __name__ == "__main__":
   if len(sys.argv) < 2:
      print "usage: ", sys.argv[0], " <clause directory>"
      print "usage: ", sys.argv[0], " <clause directory>/<filename>"
   else: 
      directory = sys.argv[1]
      fullpath = os.getcwd()+'/'+directory
      if os.path.isdir(fullpath):
         os.chdir(fullpath)
         cpptests.failedTestList = []
         doTests(fullpath, directory)
         cleanUp(fullpath)
         print "\nFailures:\n"
         print cpptests.failures
         print len(cpptests.failures), " tests failed"
      else:
         print directory, " is not in this directory"
         print "Current directory is: ", os.getcwd()
