#!/usr/bin/env python2.2

import fnmatch, os
import sys

def filelister(dummy, dirname, filesindir):
   for fname in filesindir:
      if os.path.isfile( os.path.join(dirname, fname) ):
        if  fnmatch.fnmatch(fname, "*.pyc"):
           print "deleting: ", fname
           os.remove(  os.path.join(dirname, fname) );
        if  fname[-3:] == "exe":
           print "deleting: ", fname
           os.remove(  os.path.join(dirname, fname) );
        if  fname[-2:] == "ti":
           print "deleting: ", fname
           os.remove(  os.path.join(dirname, fname) );
        if  fname[-1:] == "o":
           print "deleting: ", fname
           os.remove(  os.path.join(dirname, fname) );
        if  fname == "core":
           print "deleting: ", fname
           os.remove(  os.path.join(dirname, fname) );
        if  fname == "*.swp":
           print "deleting: ", fname
           os.remove(  os.path.join(dirname, fname) );

def runClean():
  #os.path.walk(os.getcwd(),  filelister, None)
  os.path.walk('.',  filelister, None)

if __name__ == "__main__":
   runClean()
