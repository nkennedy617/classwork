#include <iostream>
int yyparse();

int main() {
   yyparse();
   return 0;
}
