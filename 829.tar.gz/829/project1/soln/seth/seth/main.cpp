/*  
    Seth Christie
    Advance Compiler Topics
    Cpsc 829

    This program takes an html page as input and 
    attempts to determine whether the page is 
    valid html 4.01 transitional.        
*/


#include <iostream>
extern FILE *yyin;
int yyparse();

/* extern int yydebug; */

int main(int argc, char* argv[]) {

/* if you want debug uncomment the following line */
/*   yydebug=1; */
   char* filename;
   if ( argc == 2 ) {
      filename = argv[1];
      yyin = fopen(argv[1], "r");
   } else {
      filename = new char[6];
      strcpy(filename, "input");
   }
   if ( yyparse() == 0 ) {
      std::cout << "Syntax correct for: " 
                << filename << std::endl;
   }
   else {
      std::cout << "Syntax invalid for: " 
                << filename << std::endl;
   }
}
