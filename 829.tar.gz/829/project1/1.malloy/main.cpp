
#include <iostream>
extern FILE *yyin;
int yyparse();

int main(int argc, char* argv[]) {
   char* filename;
   if ( argc == 2 ) {
      filename = argv[1];
      yyin = fopen(argv[1], "r");
   } else {
      filename = new char[6];
      strcpy(filename, "input");
   }
   if ( yyparse() == 0 ) {
      std::cout << "Syntax correct for: " 
                << filename << std::endl;
   }
}
