# LaTeX2HTML 2002 (1.62)
# Associate images original text with physical files.


$key = q/mkern-2muraise.50exhbox{{{tiny{+}}mkern-1muraise.50exhbox{{tiny{+};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\mkern-2mu\raise.50ex\hbox{{\tiny +}}\mkern-1mu\raise.50ex\hbox{\tiny +}$">|; 

1;

