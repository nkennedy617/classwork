
class A {
public:
   A() {}
   virtual void print() = 0;
   virtual void draw(int) = 0;
};

class B : public A {
public:
   B() : i(0) {}
   int get() { return i; }
   void set(int n) { i = n; }
   void draw(int x) {}
private:
   int i;
};

int main() {
   return 0;
}
