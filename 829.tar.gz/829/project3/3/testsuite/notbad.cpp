
class A {
private:
   int i;
   A *a;
public:
   A() {}
   int get() {}
   void set(int) {}
   void set(A* parm) { 
      a = parm;
   }
};

int main() {
   A a;
   A *b;
   return 0;
}
