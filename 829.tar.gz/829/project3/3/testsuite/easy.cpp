
class A {
public:
   A() {}
   int get() {}
   void set(int) {}
private:
   int i;
   A *a;
};

int main() {
   A a;
   A *b;
   return 0;
}
