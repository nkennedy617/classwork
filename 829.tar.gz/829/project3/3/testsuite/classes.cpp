
class A {
private:
   int i;
   A *a;
public:
   A() {}
   A(int n) : i(n) {}
   int get() { return i; }
   void set(int) {}
   bool set(A* a_param) { 
      a = a_param;
      return true;
   }
private:
   void do_it(int & x, int y, bool flag, A a) {}
protected:
   char getChar() {}
};

class B : public A {
public:
   B() : i(0) {}
   int get() { return i; }
   void set(int n) { i = n; }
private:
   int i;
};

int main() {
   A a;
   A *b;
   return 0;
}
