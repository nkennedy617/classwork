
class A {
public:
   A() {}
};

class B {
public:
   B() : i(0) {}
   int get() { return i; }
   void set(int n) { i = n; }
private:
   int i;
};

class C : public A, private B {
};

int main() {
   A a;
   A *b;
   return 0;
}
