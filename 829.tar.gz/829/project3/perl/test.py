#!/usr/bin/env python2.2

import os,sys,keystone

def printNamespace(ns,t):
	name = ns.getName()
	if not ns.getName():
		name = "Global namespace"
	print "%sNamespace: %s" % (t, name)
	t = t + "  "
	if ns.nameSpaceDefs():
		print "%sNested namespaces:" % t
		for p in ns.nameSpaceDefs():
			printNamespace(p,t+"  ")
	else:
		print "%sNo nested namespaces." % t
	if ns.classDefs():
		print "%sNested classes:" % t
		for p in ns.classDefs():
			printClass(p,t+"  ")
	else:
		print "%sNo nested classes." % t
	if ns.freeFunDefs():
		print "%sNested functions:" % t
		for p in ns.freeFunDefs():
			printFunction(p,t+"  ")
	else:
		print "%sNo nested functions." % t
	if ns.variables():
		print "%sNested variables:" % t
		for p in ns.variables():
			printVariable(p,t+"  ")
	else:
		print "%sNo nested variables." % t

def printClass(c,t):
	print "%sClass: `%s'" % (t, c.getName())
	t = t + "  "
	if c.templateParameters():
		print "%sTemplate parameters:" % t
	else:
		print "%sNo template parameters." % t
	if c.classDefsInClass():
		print "%sNested classes:" % t
		for p in c.classDefsInClass():
			printClass(p,t+"  ")
	else:
		print "%sNo nested classes." % t
	if c.funDefsInClass():
		print "%sMember functions:" % t
		for p in c.funDefsInClass():
			printFunction(p,t+"  ")
	else:
		print "%sNo member functions." % t
	if c.dataItems():
		print "%sMember variables:" % t
		for p in c.dataItems():
			printVariable(p,t+"  ")
	else:
		print "%sNo member variables." % t
	if c.parents():
		print "%sParent classes:" % t
		for p in c.parents():
			print "  %s%s" % (t,c.getName())
	else:
		print "%sNo parent classes." % t	


def printFunction(f,t):
	print "%sFunction: `%s'" % (t, f.getName())
	t = t + "  "
	print "%sReturn type: %s" % (t,f.returnType().getName())
	if f.localVars():
		print "%sLocal variables:" % t
		for p in f.localVars():
			printVariable(p,t+"  ")
	else:
		print "%sNo local variables." % t
	if f.params():
		print "%sFormal parameters:" % t
		for p in f.params():
			printVariable(p,t+"  ")
	else:
		print "%sEmpty parameter list." % t
	if f.isMember():
		if f.visibility() == keystone.AS_PUBLIC:
			print "%s%s is a public method." % (t,f.getName())
		elif f.visibility() == keystone.AS_PRIVATE:
			print "%s%s is a private method." % (t,f.getName())
		if f.visibility() == keystone.AS_PROTECTED:
			print "%s%s is a protected method." % (t,f.getName())
	if f.isPureVirtual():
		print "%s%s is pure virtual." % (t,f.getName())
	elif f.isVirtual():
		print "%s%s is virtual." % (t,f.getName())
	if f.isStatic():
		print "%s%s is static." % (t,f.getName())
	if f.isConstant():
		print "%s%s is constant." % (t,f.getName())
	if f.classDefsInFun():
		print "%sLocal classes:" % t
		for p in f.classDefsInFun():
			printClass(p,t+"  ")
	else:
		print "%sNo local classes." % t
	

def printVariable(v,t):
	print "%sVariable: %s {%s}" % (t,v.getName(),v.getType().getName())
	t = t + "  "
	if v.isMember():
		if v.visibility() == keystone.AS_PUBLIC:
			print "%s%s is a public data member." % (t,v.getName())
		elif v.visibility() == keystone.AS_PRIVATE:
			print "%s%s is a private data member." % (t,v.getName())
		if v.visibility() == keystone.AS_PROTECTED:
			print "%s%s is a protected data member." % (t,v.getName())
	if v.isStatic():
		print "%s%s is static." % (t,v.getName())
	if v.isConstant():
		print "%s%s is constant." % (t,v.getName())

if __name__=='__main__':
	print "parsing: " + sys.argv[1]
	key = keystone.Interface(sys.argv[1])
	for x in key.nameSpaces():
		printNamespace(x,"")
