# This file was created automatically by SWIG.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.
import _jkeystone
def _swig_setattr(self,class_type,name,value):
    if (name == "this"):
        if isinstance(value, class_type):
            self.__dict__[name] = value.this
            if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
            del value.thisown
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    self.__dict__[name] = value

def _swig_getattr(self,class_type,name):
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0


class Scope_Info(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Scope_Info, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Scope_Info, name)
    def __init__(self,*args):
        _swig_setattr(self, Scope_Info, 'this', apply(_jkeystone.new_Scope_Info,args))
        _swig_setattr(self, Scope_Info, 'thisown', 1)
    def getName(*args): return apply(_jkeystone.Scope_Info_getName,args)
    def __del__(self, destroy= _jkeystone.delete_Scope_Info):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C Scope_Info instance at %s>" % (self.this,)

class Scope_InfoPtr(Scope_Info):
    def __init__(self,this):
        _swig_setattr(self, Scope_Info, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Scope_Info, 'thisown', 0)
        _swig_setattr(self, Scope_Info,self.__class__,Scope_Info)
_jkeystone.Scope_Info_swigregister(Scope_InfoPtr)

AS_PUBLIC = _jkeystone.AS_PUBLIC
AS_PRIVATE = _jkeystone.AS_PRIVATE
AS_PROTECTED = _jkeystone.AS_PROTECTED
AS_NONE = _jkeystone.AS_NONE
class Class_Info(Scope_Info):
    __swig_setmethods__ = {}
    for _s in [Scope_Info]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, Class_Info, name, value)
    __swig_getmethods__ = {}
    for _s in [Scope_Info]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, Class_Info, name)
    def __init__(self,*args):
        _swig_setattr(self, Class_Info, 'this', apply(_jkeystone.new_Class_Info,args))
        _swig_setattr(self, Class_Info, 'thisown', 1)
    def classDefsInClass(*args): return apply(_jkeystone.Class_Info_classDefsInClass,args)
    def funDefsInClass(*args): return apply(_jkeystone.Class_Info_funDefsInClass,args)
    def dataItems(*args): return apply(_jkeystone.Class_Info_dataItems,args)
    def templateParameters(*args): return apply(_jkeystone.Class_Info_templateParameters,args)
    def parents(*args): return apply(_jkeystone.Class_Info_parents,args)
    def children(*args): return apply(_jkeystone.Class_Info_children,args)
    def friendClasses(*args): return apply(_jkeystone.Class_Info_friendClasses,args)
    def friendFunctions(*args): return apply(_jkeystone.Class_Info_friendFunctions,args)
    def isAbstract(*args): return apply(_jkeystone.Class_Info_isAbstract,args)
    def visibility(*args): return apply(_jkeystone.Class_Info_visibility,args)
    def classDerivedAccess(*args): return apply(_jkeystone.Class_Info_classDerivedAccess,args)
    def __del__(self, destroy= _jkeystone.delete_Class_Info):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C Class_Info instance at %s>" % (self.this,)

class Class_InfoPtr(Class_Info):
    def __init__(self,this):
        _swig_setattr(self, Class_Info, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Class_Info, 'thisown', 0)
        _swig_setattr(self, Class_Info,self.__class__,Class_Info)
_jkeystone.Class_Info_swigregister(Class_InfoPtr)

class DataType(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, DataType, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, DataType, name)
    def __init__(self,*args):
        _swig_setattr(self, DataType, 'this', apply(_jkeystone.new_DataType,args))
        _swig_setattr(self, DataType, 'thisown', 1)
    def getName(*args): return apply(_jkeystone.DataType_getName,args)
    def templateArguments(*args): return apply(_jkeystone.DataType_templateArguments,args)
    def getCategory(*args): return apply(_jkeystone.DataType_getCategory,args)
    def isUserDefined(*args): return apply(_jkeystone.DataType_isUserDefined,args)
    def __del__(self, destroy= _jkeystone.delete_DataType):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C DataType instance at %s>" % (self.this,)

class DataTypePtr(DataType):
    def __init__(self,this):
        _swig_setattr(self, DataType, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, DataType, 'thisown', 0)
        _swig_setattr(self, DataType,self.__class__,DataType)
_jkeystone.DataType_swigregister(DataTypePtr)

class Function_Info(Scope_Info):
    __swig_setmethods__ = {}
    for _s in [Scope_Info]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, Function_Info, name, value)
    __swig_getmethods__ = {}
    for _s in [Scope_Info]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, Function_Info, name)
    def __init__(self,*args):
        _swig_setattr(self, Function_Info, 'this', apply(_jkeystone.new_Function_Info,args))
        _swig_setattr(self, Function_Info, 'thisown', 1)
    def returnType(*args): return apply(_jkeystone.Function_Info_returnType,args)
    def visibility(*args): return apply(_jkeystone.Function_Info_visibility,args)
    def localVars(*args): return apply(_jkeystone.Function_Info_localVars,args)
    def params(*args): return apply(_jkeystone.Function_Info_params,args)
    def templateParameters(*args): return apply(_jkeystone.Function_Info_templateParameters,args)
    def isMember(*args): return apply(_jkeystone.Function_Info_isMember,args)
    def isVirtual(*args): return apply(_jkeystone.Function_Info_isVirtual,args)
    def isPureVirtual(*args): return apply(_jkeystone.Function_Info_isPureVirtual,args)
    def isStatic(*args): return apply(_jkeystone.Function_Info_isStatic,args)
    def isConstant(*args): return apply(_jkeystone.Function_Info_isConstant,args)
    def classDefsInFun(*args): return apply(_jkeystone.Function_Info_classDefsInFun,args)
    def __del__(self, destroy= _jkeystone.delete_Function_Info):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C Function_Info instance at %s>" % (self.this,)

class Function_InfoPtr(Function_Info):
    def __init__(self,this):
        _swig_setattr(self, Function_Info, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Function_Info, 'thisown', 0)
        _swig_setattr(self, Function_Info,self.__class__,Function_Info)
_jkeystone.Function_Info_swigregister(Function_InfoPtr)

class Interface(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Interface, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Interface, name)
    def __init__(self,*args):
        _swig_setattr(self, Interface, 'this', apply(_jkeystone.new_Interface,args))
        _swig_setattr(self, Interface, 'thisown', 1)
    def __del__(self, destroy= _jkeystone.delete_Interface):
        try:
            if self.thisown: destroy(self)
        except: pass
    def nameSpaces(*args): return apply(_jkeystone.Interface_nameSpaces,args)
    def __repr__(self):
        return "<C Interface instance at %s>" % (self.this,)

class InterfacePtr(Interface):
    def __init__(self,this):
        _swig_setattr(self, Interface, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Interface, 'thisown', 0)
        _swig_setattr(self, Interface,self.__class__,Interface)
_jkeystone.Interface_swigregister(InterfacePtr)

class NameSpace_Info(Scope_Info):
    __swig_setmethods__ = {}
    for _s in [Scope_Info]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, NameSpace_Info, name, value)
    __swig_getmethods__ = {}
    for _s in [Scope_Info]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, NameSpace_Info, name)
    def __init__(self,*args):
        _swig_setattr(self, NameSpace_Info, 'this', apply(_jkeystone.new_NameSpace_Info,args))
        _swig_setattr(self, NameSpace_Info, 'thisown', 1)
    def nameSpaceDefs(*args): return apply(_jkeystone.NameSpace_Info_nameSpaceDefs,args)
    def classDefs(*args): return apply(_jkeystone.NameSpace_Info_classDefs,args)
    def freeFunDefs(*args): return apply(_jkeystone.NameSpace_Info_freeFunDefs,args)
    def variables(*args): return apply(_jkeystone.NameSpace_Info_variables,args)
    def isUserDefined(*args): return apply(_jkeystone.NameSpace_Info_isUserDefined,args)
    def __del__(self, destroy= _jkeystone.delete_NameSpace_Info):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C NameSpace_Info instance at %s>" % (self.this,)

class NameSpace_InfoPtr(NameSpace_Info):
    def __init__(self,this):
        _swig_setattr(self, NameSpace_Info, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, NameSpace_Info, 'thisown', 0)
        _swig_setattr(self, NameSpace_Info,self.__class__,NameSpace_Info)
_jkeystone.NameSpace_Info_swigregister(NameSpace_InfoPtr)

class Type_Info(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Type_Info, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Type_Info, name)
    def __init__(self,*args):
        _swig_setattr(self, Type_Info, 'this', apply(_jkeystone.new_Type_Info,args))
        _swig_setattr(self, Type_Info, 'thisown', 1)
    def __eq__(*args): return apply(_jkeystone.Type_Info___eq__,args)
    def __ne__(*args): return apply(_jkeystone.Type_Info___ne__,args)
    def value(*args): return apply(_jkeystone.Type_Info_value,args)
    def getName(*args): return apply(_jkeystone.Type_Info_getName,args)
    def getSignature(*args): return apply(_jkeystone.Type_Info_getSignature,args)
    def __del__(self, destroy= _jkeystone.delete_Type_Info):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C Type_Info instance at %s>" % (self.this,)

class Type_InfoPtr(Type_Info):
    def __init__(self,this):
        _swig_setattr(self, Type_Info, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Type_Info, 'thisown', 0)
        _swig_setattr(self, Type_Info,self.__class__,Type_Info)
_jkeystone.Type_Info_swigregister(Type_InfoPtr)

class Variable_Info(Scope_Info):
    __swig_setmethods__ = {}
    for _s in [Scope_Info]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, Variable_Info, name, value)
    __swig_getmethods__ = {}
    for _s in [Scope_Info]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, Variable_Info, name)
    def __init__(self,*args):
        _swig_setattr(self, Variable_Info, 'this', apply(_jkeystone.new_Variable_Info,args))
        _swig_setattr(self, Variable_Info, 'thisown', 1)
    def getType(*args): return apply(_jkeystone.Variable_Info_getType,args)
    def isMember(*args): return apply(_jkeystone.Variable_Info_isMember,args)
    def isStatic(*args): return apply(_jkeystone.Variable_Info_isStatic,args)
    def isConstant(*args): return apply(_jkeystone.Variable_Info_isConstant,args)
    def visibility(*args): return apply(_jkeystone.Variable_Info_visibility,args)
    def __del__(self, destroy= _jkeystone.delete_Variable_Info):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C Variable_Info instance at %s>" % (self.this,)

class Variable_InfoPtr(Variable_Info):
    def __init__(self,this):
        _swig_setattr(self, Variable_Info, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Variable_Info, 'thisown', 0)
        _swig_setattr(self, Variable_Info,self.__class__,Variable_Info)
_jkeystone.Variable_Info_swigregister(Variable_InfoPtr)

class namespace_vec(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, namespace_vec, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, namespace_vec, name)
    def __init__(self,*args):
        _swig_setattr(self, namespace_vec, 'this', apply(_jkeystone.new_namespace_vec,args))
        _swig_setattr(self, namespace_vec, 'thisown', 1)
    def __len__(*args): return apply(_jkeystone.namespace_vec___len__,args)
    def clear(*args): return apply(_jkeystone.namespace_vec_clear,args)
    def append(*args): return apply(_jkeystone.namespace_vec_append,args)
    def __nonzero__(*args): return apply(_jkeystone.namespace_vec___nonzero__,args)
    def pop(*args): return apply(_jkeystone.namespace_vec_pop,args)
    def __getitem__(*args): return apply(_jkeystone.namespace_vec___getitem__,args)
    def __getslice__(*args): return apply(_jkeystone.namespace_vec___getslice__,args)
    def __setitem__(*args): return apply(_jkeystone.namespace_vec___setitem__,args)
    def __setslice__(*args): return apply(_jkeystone.namespace_vec___setslice__,args)
    def __delitem__(*args): return apply(_jkeystone.namespace_vec___delitem__,args)
    def __delslice__(*args): return apply(_jkeystone.namespace_vec___delslice__,args)
    def __del__(self, destroy= _jkeystone.delete_namespace_vec):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C namespace_vec instance at %s>" % (self.this,)

class namespace_vecPtr(namespace_vec):
    def __init__(self,this):
        _swig_setattr(self, namespace_vec, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, namespace_vec, 'thisown', 0)
        _swig_setattr(self, namespace_vec,self.__class__,namespace_vec)
_jkeystone.namespace_vec_swigregister(namespace_vecPtr)

class class_vec(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, class_vec, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, class_vec, name)
    def __init__(self,*args):
        _swig_setattr(self, class_vec, 'this', apply(_jkeystone.new_class_vec,args))
        _swig_setattr(self, class_vec, 'thisown', 1)
    def __len__(*args): return apply(_jkeystone.class_vec___len__,args)
    def clear(*args): return apply(_jkeystone.class_vec_clear,args)
    def append(*args): return apply(_jkeystone.class_vec_append,args)
    def __nonzero__(*args): return apply(_jkeystone.class_vec___nonzero__,args)
    def pop(*args): return apply(_jkeystone.class_vec_pop,args)
    def __getitem__(*args): return apply(_jkeystone.class_vec___getitem__,args)
    def __getslice__(*args): return apply(_jkeystone.class_vec___getslice__,args)
    def __setitem__(*args): return apply(_jkeystone.class_vec___setitem__,args)
    def __setslice__(*args): return apply(_jkeystone.class_vec___setslice__,args)
    def __delitem__(*args): return apply(_jkeystone.class_vec___delitem__,args)
    def __delslice__(*args): return apply(_jkeystone.class_vec___delslice__,args)
    def __del__(self, destroy= _jkeystone.delete_class_vec):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C class_vec instance at %s>" % (self.this,)

class class_vecPtr(class_vec):
    def __init__(self,this):
        _swig_setattr(self, class_vec, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, class_vec, 'thisown', 0)
        _swig_setattr(self, class_vec,self.__class__,class_vec)
_jkeystone.class_vec_swigregister(class_vecPtr)

class function_vec(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, function_vec, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, function_vec, name)
    def __init__(self,*args):
        _swig_setattr(self, function_vec, 'this', apply(_jkeystone.new_function_vec,args))
        _swig_setattr(self, function_vec, 'thisown', 1)
    def __len__(*args): return apply(_jkeystone.function_vec___len__,args)
    def clear(*args): return apply(_jkeystone.function_vec_clear,args)
    def append(*args): return apply(_jkeystone.function_vec_append,args)
    def __nonzero__(*args): return apply(_jkeystone.function_vec___nonzero__,args)
    def pop(*args): return apply(_jkeystone.function_vec_pop,args)
    def __getitem__(*args): return apply(_jkeystone.function_vec___getitem__,args)
    def __getslice__(*args): return apply(_jkeystone.function_vec___getslice__,args)
    def __setitem__(*args): return apply(_jkeystone.function_vec___setitem__,args)
    def __setslice__(*args): return apply(_jkeystone.function_vec___setslice__,args)
    def __delitem__(*args): return apply(_jkeystone.function_vec___delitem__,args)
    def __delslice__(*args): return apply(_jkeystone.function_vec___delslice__,args)
    def __del__(self, destroy= _jkeystone.delete_function_vec):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C function_vec instance at %s>" % (self.this,)

class function_vecPtr(function_vec):
    def __init__(self,this):
        _swig_setattr(self, function_vec, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, function_vec, 'thisown', 0)
        _swig_setattr(self, function_vec,self.__class__,function_vec)
_jkeystone.function_vec_swigregister(function_vecPtr)

class variable_vec(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, variable_vec, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, variable_vec, name)
    def __init__(self,*args):
        _swig_setattr(self, variable_vec, 'this', apply(_jkeystone.new_variable_vec,args))
        _swig_setattr(self, variable_vec, 'thisown', 1)
    def __len__(*args): return apply(_jkeystone.variable_vec___len__,args)
    def clear(*args): return apply(_jkeystone.variable_vec_clear,args)
    def append(*args): return apply(_jkeystone.variable_vec_append,args)
    def __nonzero__(*args): return apply(_jkeystone.variable_vec___nonzero__,args)
    def pop(*args): return apply(_jkeystone.variable_vec_pop,args)
    def __getitem__(*args): return apply(_jkeystone.variable_vec___getitem__,args)
    def __getslice__(*args): return apply(_jkeystone.variable_vec___getslice__,args)
    def __setitem__(*args): return apply(_jkeystone.variable_vec___setitem__,args)
    def __setslice__(*args): return apply(_jkeystone.variable_vec___setslice__,args)
    def __delitem__(*args): return apply(_jkeystone.variable_vec___delitem__,args)
    def __delslice__(*args): return apply(_jkeystone.variable_vec___delslice__,args)
    def __del__(self, destroy= _jkeystone.delete_variable_vec):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C variable_vec instance at %s>" % (self.this,)

class variable_vecPtr(variable_vec):
    def __init__(self,this):
        _swig_setattr(self, variable_vec, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, variable_vec, 'thisown', 0)
        _swig_setattr(self, variable_vec,self.__class__,variable_vec)
_jkeystone.variable_vec_swigregister(variable_vecPtr)

class datatype_vec(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, datatype_vec, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, datatype_vec, name)
    def __init__(self,*args):
        _swig_setattr(self, datatype_vec, 'this', apply(_jkeystone.new_datatype_vec,args))
        _swig_setattr(self, datatype_vec, 'thisown', 1)
    def __len__(*args): return apply(_jkeystone.datatype_vec___len__,args)
    def clear(*args): return apply(_jkeystone.datatype_vec_clear,args)
    def append(*args): return apply(_jkeystone.datatype_vec_append,args)
    def __nonzero__(*args): return apply(_jkeystone.datatype_vec___nonzero__,args)
    def pop(*args): return apply(_jkeystone.datatype_vec_pop,args)
    def __getitem__(*args): return apply(_jkeystone.datatype_vec___getitem__,args)
    def __getslice__(*args): return apply(_jkeystone.datatype_vec___getslice__,args)
    def __setitem__(*args): return apply(_jkeystone.datatype_vec___setitem__,args)
    def __setslice__(*args): return apply(_jkeystone.datatype_vec___setslice__,args)
    def __delitem__(*args): return apply(_jkeystone.datatype_vec___delitem__,args)
    def __delslice__(*args): return apply(_jkeystone.datatype_vec___delslice__,args)
    def __del__(self, destroy= _jkeystone.delete_datatype_vec):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C datatype_vec instance at %s>" % (self.this,)

class datatype_vecPtr(datatype_vec):
    def __init__(self,this):
        _swig_setattr(self, datatype_vec, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, datatype_vec, 'thisown', 0)
        _swig_setattr(self, datatype_vec,self.__class__,datatype_vec)
_jkeystone.datatype_vec_swigregister(datatype_vecPtr)


