#ifndef ACCESSSPECIFIER_H
#define ACCESSSPECIFIER_H
enum AccessSpecifier {
  AS_PUBLIC,
  AS_PRIVATE,
  AS_PROTECTED,
  AS_NONE
};
#endif
