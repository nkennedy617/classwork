class B:public A  { 
public :
   B (  ) {
      cout << "I'm a constructor forB"<< endl;
   }
   int get (  ) {
      return 12;
   }
   void set (   int n ) {
      cout << "I'm a set function "<< endl;
   }
}; 
