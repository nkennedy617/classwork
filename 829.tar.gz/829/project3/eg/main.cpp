#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <keystone.h>
#include <ios>

const int FACTOR = 3;
using std::cout; using std::endl; using std::ofstream;
using std::vector; using std::cin; using std::string; using std::ios;

void print_classes(const vector<Class_Info> &);
void print_parms(const vector<Variable_Info> &);
string cname;
ofstream outStub("stub.cpp", ios::out);

void print_vis(const AccessSpecifier & vis) {
   if(vis ==AS_PUBLIC) {
      outStub << "public ";
   }
   else if (vis == AS_PRIVATE) {
      outStub << "private ";
   }
   else if (vis == AS_PROTECTED) {
      outStub << "protected ";
   }
}
void print_methods(const vector<Function_Info> & vec) {
      AccessSpecifier curvis =AS_NONE;
   for (unsigned int i = 0; i < vec.size(); ++i) {
      if( vec[i].visibility() != curvis) {
          curvis = vec[i].visibility();
          print_vis(curvis);
          outStub << ":" << endl;
      }
      DataType dtype = vec[i].returnType();
        outStub << "   ";
      if(dtype.getName()=="void"){
        outStub << dtype.getName() << " ";
      }
      else if (dtype.getName()=="int"){
        outStub << dtype.getName() << " ";
      }
      else if (dtype.getName()=="char"){
        outStub << dtype.getName() << " ";
      }
      else if (dtype.getName()=="bool"){
        outStub << dtype.getName() << " ";
      }
      else if (dtype.getName()=="none"){
      }
      else{
        outStub << dtype.getName() << " ";
      }
      string tname = vec[i].getName();
      tname.erase(0, cname.size()+2);
        outStub <<  tname ;
      outStub << " ( ";       
      vector<Variable_Info> myparms = vec[i].params();
      print_parms (myparms);
      outStub << " ) {" << endl;       
      outStub << "   ";
      outStub << "   ";
      if(dtype.getName()=="void"){
	outStub << "cout << " << '"' << "I'm a set function " <<'"'<<"<< endl;"<< endl;
      }
      else if (dtype.getName()=="int"){
	outStub << "return 12;" << endl;
      }
      else if (dtype.getName()=="bool"){
	outStub << "return 1;" << endl;
      }
      else if (dtype.getName()=="char"){
	outStub << "return 'a';" << endl;
      }
      else if (dtype.getName()=="none"){
	outStub << "cout << " << '"' << "I'm a constructor for"<<cname <<'"'<<"<< endl;"<< endl;
      }
      else{
	outStub << "cout << " << '"' << "I haven't a clue " <<'"' <<" << endl;"<< endl;
      }
      outStub << "   ";
      outStub << "}" << endl;
      print_classes( vec[i].classDefsInFun() );
   } 
}

void print_parms(const vector<Variable_Info> & vec) {
   for (unsigned int i = 0; i < vec.size(); ++i) {
      DataType pdtype = vec[i].getType();
       outStub << "  " << pdtype.getName() << " ";
       outStub <<  vec[i].getName();
   } 
}
void print_classes(const vector<Class_Info> & vec) {
   for (unsigned int i = 0; i < vec.size(); ++i) {
      if(cname == vec[i].getName()){
         outStub << "class " << vec[i].getName();
         vector<Class_Info> parents = vec[i].parents();
         for(unsigned int p=0; p<parents.size(); ++p){
             if(p==0) outStub << ":";
             else outStub << ",";
	     print_vis(vec[i].classDerivedAccess(parents[p]));
 	     outStub << parents[p].getName() << ' ';
	 }
         outStub << " { " << endl; 
         print_methods(vec[i].funDefsInClass());
         outStub << "}; " << endl; 
      }
      print_classes( vec[i].classDefsInClass() );
   } 
}

void print_namespaces(const std::vector<NameSpace_Info> & vec) {
   for (unsigned int i = 0; i < vec.size(); ++i) {
      print_classes(vec[i].classDefs());
      print_namespaces(vec[i].nameSpaceDefs());
   } 
} 

int main(int argc, char *argv[] ) {
   try {
      if ( argc != 2 ) {
         cout << "usage: " << argv[0] << " <filename>" << endl;
         return 1;
      }
      Interface face(argv[1]);
      cout << "Enter class to be stubbed:   " << endl;
      cin >> cname;
      print_namespaces(face.nameSpaces());
   }
   catch (const std::string& msg) {
      cout << "Oops: " << msg << endl;
   }
   catch (...) {
      cout << "Oops: exception not caught!" << endl;
   }
   return 0;
}
