/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BegHtml = 258,
     EndHtml = 259,
     BegHead = 260,
     EndHead = 261,
     BegTitle = 262,
     EndTitle = 263,
     BegBody = 264,
     EndBody = 265,
     BegUnknown = 266,
     EndUnknown = 267,
     RightAngle = 268,
     Identifier = 269,
     Equal = 270,
     Number = 271,
     Quote = 272,
     Error = 273,
     CR = 274
   };
#endif
#define BegHtml 258
#define EndHtml 259
#define BegHead 260
#define EndHead 261
#define BegTitle 262
#define EndTitle 263
#define BegBody 264
#define EndBody 265
#define BegUnknown 266
#define EndUnknown 267
#define RightAngle 268
#define Identifier 269
#define Equal 270
#define Number 271
#define Quote 272
#define Error 273
#define CR 274




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 42 "htmltab.y"
typedef union YYSTYPE {
   expression *node;
   int inum;
   char * id;
} YYSTYPE;
/* Line 1248 of yacc.c.  */
#line 80 "htmltab.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



