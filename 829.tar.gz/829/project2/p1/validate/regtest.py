#!/usr/local/bin/python

import os, sys
from stat import ST_SIZE
from glob import glob
from os.path import exists

if __name__ == "__main__":
   if len(sys.argv) != 2:
      print 'usage: ' + sys.argv[0] + ' <testdir>'
      sys.exit()
   print 'Starting regression test ' + sys.argv[0]
   print 'user: ', os.environ['USER']
   print 'path: ', os.getcwd()
   testdir = sys.argv[1]

   if not exists('run'):
      print 'Need to make "run"'
      sys.exit()

   for test in glob(testdir + '/*.html'):
      if not exists('%s.out' % test):
         os.system('%s %s > %s.out' % ('run', test, test))
         print 'GENERATED: ', test
      else:
         os.rename(test + '.out', test + '.out.bkp')
         os.system('%s %s > %s.out' % ('run', test, test))
         os.system('diff %s.out %s.out.bkp > %s.diffs' % ((test,)*3) )
         if os.stat(test + '.diffs')[ST_SIZE] == 0:
            print 'passed: ', test
            os.remove(test + '.diffs')
         else:
            print 'FAILED: ', test, ' (see %s.diffs)' % test
   os.system('rm ' + testdir + '/*.bkp')

