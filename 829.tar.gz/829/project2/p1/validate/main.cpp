
#include <iostream>
extern FILE *yyin;
int yyparse();
extern bool no_errors;

int main(int argc, char* argv[]) {
   char* filename;
   if ( argc == 2 ) {
      filename = argv[1];
      yyin = fopen(argv[1], "r");
   } else {
      filename = new char[6];
      strcpy(filename, "input");
   }
   yyparse();
   if ( no_errors ) {
      std::cout << "Syntax correct for: " 
                << filename << std::endl;
   }
   else {
      std::cout << "Syntax invalid for: " 
                << filename << std::endl;
   }
}
