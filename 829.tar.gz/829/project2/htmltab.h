/* htmltab.h.  Generated automatically by treecc */
#ifndef __yy_htmltab_h
#define __yy_htmltab_h
#line 6 "htmltab.tc"

#include <vector>
using std::string;
#line 9 "htmltab.h"

#include <new>

const int expression_kind = 1;
const int parens_kind = 2;
const int newtag_kind = 3;
const int number_kind = 4;
const int ident_kind = 5;
const int start_kind = 6;
const int end_kind = 7;

class expression;
class parens;
class newtag;
class number;
class ident;
class start;
class end;

class YYNODESTATE
{
public:

	YYNODESTATE();
	virtual ~YYNODESTATE();

#line 1 "cpp_skel.h"
private:

	struct YYNODESTATE_block *blocks__;
	struct YYNODESTATE_push *push_stack__;
	int used__;
#line 42 "htmltab.h"
private:

	static YYNODESTATE *state__;

public:

	static YYNODESTATE *getState()
		{
			if(state__) return state__;
			state__ = new YYNODESTATE();
			return state__;
		}

public:

	void *alloc(size_t);
	void dealloc(void *, size_t);
	int push();
	void pop();
	void clear();
	virtual void failed();
	virtual char *currFilename();
	virtual long currLinenum();

};

class expression
{
protected:

	int kind__;
	char *filename__;
	long linenum__;

public:

	int getKind() const { return kind__; }
	const char *getFilename() const { return filename__; }
	long getLinenum() const { return linenum__; }
	void setFilename(char *filename) { filename__ = filename; }
	void setLinenum(long linenum) { linenum__ = linenum; }

	void *operator new(size_t);
	void operator delete(void *, size_t);

protected:

	expression();

public:

	int level;

	virtual void traverse() = 0;
	virtual void setLevel(int i) = 0;

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~expression();

};

class parens : public expression
{
public:

	parens(expression * s1, expression * s2);

public:

	expression * s1;
	expression * s2;

	virtual void traverse();
	virtual void setLevel(int i);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~parens();

};

class newtag : public expression
{
public:

	newtag(expression * s1);

public:

	expression * s1;

	virtual void traverse();
	virtual void setLevel(int i);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~newtag();

};

class number : public expression
{
public:

	number(int val);

public:

	int val;

	virtual void traverse();
	virtual void setLevel(int i);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~number();

};

class ident : public expression
{
public:

	ident(char * id);

public:

	char * id;

	virtual void traverse();
	virtual void setLevel(int i);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~ident();

};

class start : public expression
{
public:

	start(char * id);

public:

	char * id;

	virtual void traverse();
	virtual void setLevel(int i);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~start();

};

class end : public expression
{
public:

	end(char * id);

public:

	char * id;

	virtual void traverse();
	virtual void setLevel(int i);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~end();

};



#endif
