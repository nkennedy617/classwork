
#include <iostream>

int yyparse();

int main() {
   std::cout << "type your input: " << std::endl;
   if ( yyparse() ) std::cout << "program terminating." << std::endl;
}
