/* parens.h.  Generated automatically by treecc */
#ifndef __yy_parens_h
#define __yy_parens_h
#line 15 "parens.tc"

using std::string;
#include "Visitor.h"
#line 9 "parens.h"

#include <new>

const int expression_kind = 1;
const int parens_kind = 2;
const int number_kind = 3;
const int ident_kind = 4;

class expression;
class parens;
class number;
class ident;

class YYNODESTATE
{
public:

	YYNODESTATE();
	virtual ~YYNODESTATE();

#line 1 "cpp_skel.h"
private:

	struct YYNODESTATE_block *blocks__;
	struct YYNODESTATE_push *push_stack__;
	int used__;
#line 36 "parens.h"
private:

	static YYNODESTATE *state__;

public:

	static YYNODESTATE *getState()
		{
			if(state__) return state__;
			state__ = new YYNODESTATE();
			return state__;
		}

public:

	void *alloc(size_t);
	void dealloc(void *, size_t);
	int push();
	void pop();
	void clear();
	virtual void failed();
	virtual char *currFilename();
	virtual long currLinenum();

};

class expression
{
protected:

	int kind__;
	char *filename__;
	long linenum__;

public:

	int getKind() const { return kind__; }
	const char *getFilename() const { return filename__; }
	long getLinenum() const { return linenum__; }
	void setFilename(char *filename) { filename__ = filename; }
	void setLinenum(long linenum) { linenum__ = linenum; }

	void *operator new(size_t);
	void operator delete(void *, size_t);

protected:

	expression();

public:

	virtual void accept(Visitor * visitor) = 0;

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~expression();

};

class parens : public expression
{
public:

	parens(expression * s1, expression * s2);

public:

	expression * s1;
	expression * s2;

	virtual void accept(Visitor * visitor);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~parens();

};

class number : public expression
{
public:

	number(int val);

public:

	int val;

	virtual void accept(Visitor * visitor);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~number();

};

class ident : public expression
{
public:

	ident(char * id);

public:

	char * id;

	virtual void accept(Visitor * visitor);

	virtual int isA(int kind) const;
	virtual const char *getKindName() const;

protected:

	virtual ~ident();

};



#endif
