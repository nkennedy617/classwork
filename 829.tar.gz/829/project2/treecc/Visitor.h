
#ifndef VISITOR_H
#define VISITOR_H

class parens;
class ident;
class number;

class Visitor {
public:
   Visitor() { }
   virtual ~Visitor() { }

   virtual void visit(parens*) = 0;
   virtual void visit(ident*) = 0;
   virtual void visit(number*) = 0;
};

#endif /* VISITOR_H */
