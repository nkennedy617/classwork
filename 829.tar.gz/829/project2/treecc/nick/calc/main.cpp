
#include "AST.h"

#include <iostream>
using std::cout;
using std::endl;

extern int yyparse();
extern FILE *yyin;

int main(int argc, char* argv[]) {
  if ( argc == 2 )
    yyin = fopen(argv[1], "r");
  else
    yyin = stdin;

  if ( yyparse() == 0 )
    return 0;
  else
    return 1;
}
