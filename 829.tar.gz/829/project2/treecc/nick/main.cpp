
#include "AST.h"

#include <iostream>
using std::cout;
using std::endl;

extern int yyparse(void*);
extern FILE *yyin;

int main(int argc, char* argv[]) {
  int rc;
  if ( argc == 2 )
    yyin = fopen(argv[1], "r");
  else
    yyin = stdin;

  YYNODESTATE *state = new YYNODESTATE;
  rc = yyparse(state);
  delete state;
  return (rc);
}
