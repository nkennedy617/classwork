
#include "HTMLVisitor.h"
#include <iostream>

HTMLVisitor::HTMLVisitor()
{
   colors_.push("aliceblue");
   colors_.push("antiquewhite");
   colors_.push("aqua");
   colors_.push("aquamarine");
   colors_.push("azure");
   colors_.push("beige");
   colors_.push("bisque");
   colors_.push("black");
   colors_.push("blanchedalmond");
   colors_.push("blue");
   colors_.push("blueviolet");
   colors_.push("brown");
   colors_.push("burlywood");
   colors_.push("cadetblue");
   colors_.push("chartreuse");
   colors_.push("chocolate");
   colors_.push("coral");
   colors_.push("cornflowerblue");
   colors_.push("cornsilk");
   colors_.push("crimson");
   colors_.push("cyan");
   colors_.push("darkblue");
   colors_.push("darkcyan");
   colors_.push("darkgoldenrod");
   colors_.push("darkgray");
   colors_.push("darkgreen");
   colors_.push("darkgrey");
   colors_.push("darkkhaki");
   colors_.push("darkmagenta");
   colors_.push("darkolivegreen");
   colors_.push("darkorange");
   colors_.push("darkorchid");
   colors_.push("darkred");
   colors_.push("darksalmon");
   colors_.push("darkseagreen");
   colors_.push("darkslateblue");
   colors_.push("darkslategray");
   colors_.push("darkslategrey");
   colors_.push("darkturquoise");
   colors_.push("darkviolet");
   colors_.push("deeppink");
   colors_.push("deepskyblue");
   colors_.push("dimgray");
   colors_.push("dimgrey");
   colors_.push("dodgerblue");
   colors_.push("firebrick");
   colors_.push("floralwhite");
   colors_.push("forestgreen");
   colors_.push("fuchsia");
   colors_.push("gainsboro");
   colors_.push("ghostwhite");
   colors_.push("gold");
   colors_.push("goldenrod");
//   colors_.push("gray");
   colors_.push("grey");
   colors_.push("green");
   colors_.push("greenyellow");
   colors_.push("honeydew");
   colors_.push("hotpink");
   colors_.push("indianred");
   colors_.push("indigo");
   colors_.push("ivory");
   colors_.push("khaki");
   colors_.push("lavender");
   colors_.push("lavenderblush");
   colors_.push("lawngreen");
   colors_.push("lemonchiffon");
   colors_.push("lightblue");
   colors_.push("lightcoral");
   colors_.push("lightcyan");
   colors_.push("lightgoldenrodyellow");
   colors_.push("lightgray");
   colors_.push("lightgreen");
   colors_.push("lightgrey");
   colors_.push("lightpink");
   colors_.push("lightsalmon");
   colors_.push("lightseagreen");
   colors_.push("lightskyblue");
   colors_.push("lightslategray");
   colors_.push("lightslategrey");
   colors_.push("lightsteelblue");
   colors_.push("lightyellow");
   colors_.push("lime");
   colors_.push("limegreen");
   colors_.push("linen");
   colors_.push("magenta");
   colors_.push("maroon");
   colors_.push("mediumaquamarine");
   colors_.push("mediumblue");
   colors_.push("mediumorchid");
   colors_.push("mediumpurple");
   colors_.push("mediumseagreen");
   colors_.push("mediumslateblue");
   colors_.push("mediumspringgreen");
   colors_.push("mediumturquoise");
   colors_.push("mediumvioletred");
   colors_.push("midnightblue");
   colors_.push("mintcream");
   colors_.push("mistyrose");
   colors_.push("moccasin");
   colors_.push("navajowhite");
   colors_.push("navy");
   colors_.push("oldlace");
   colors_.push("olive");
   colors_.push("olivedrab");
   colors_.push("orange");
   colors_.push("orangered");
   colors_.push("orchid");
   colors_.push("palegoldenrod");
   colors_.push("palegreen");
   colors_.push("paleturquoise");
   colors_.push("palevioletred");
   colors_.push("papayawhip");
   colors_.push("peachpuff");
   colors_.push("peru");
   colors_.push("pink");
   colors_.push("plum");
   colors_.push("powderblue");
   colors_.push("purple");
   colors_.push("red");
   colors_.push("rosybrown");
   colors_.push("royalblue");
   colors_.push("saddlebrown");
   colors_.push("salmon");
   colors_.push("sandybrown");
   colors_.push("seagreen");
   colors_.push("seashell");
   colors_.push("sienna");
   colors_.push("silver");
   colors_.push("skyblue");
   colors_.push("slateblue");
   colors_.push("slategray");
   colors_.push("slategrey");
   colors_.push("snow");
   colors_.push("springgreen");
   colors_.push("steelblue");
   colors_.push("tan");
   colors_.push("teal");
   colors_.push("thistle");
   colors_.push("tomato");
   colors_.push("turquoise");
   colors_.push("violet");
//   colors_.push("wheat");
//   colors_.push("white");
//   colors_.push("whitesmoke");
//   colors_.push("yellow");
   colors_.push("yellowgreen");
}

HTMLVisitor::~HTMLVisitor()
{
   /* Empty */
}

void HTMLVisitor::visit(parens* p)
{
   std::string col = colors_.top();
   colors_.pop();
   std::cout << "<font color=\"" + col + "\">(</font>" << std::endl;
   if(p->s1)
      p->s1->accept(this);
   std::cout << "<font color=\"" + col + "\">)</font>" << std::endl;
   colors_.push(col);
   if(p->s2)
      p->s2->accept(this);
}

void HTMLVisitor::visit(number* n)
{
   std::cout << "<i>" << n->val << "</i>" << std::endl;
}

void HTMLVisitor::visit(ident* i)
{
   std::cout << "<b>" << i->id << "</b>" << std::endl;
}

