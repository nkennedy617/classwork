
#include <iostream>
#include "parens.h"

int yyparse();

int main() {
   return yyparse();
}
