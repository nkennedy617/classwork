
#ifndef HTML_VISITOR_H
#define HTML_VISITOR_H

#include "Visitor.h"

#include <stack>
#include <string>
#include "parens.h"

class HTMLVisitor : public Visitor
{
public:
   HTMLVisitor();
   virtual ~HTMLVisitor();

   void visit(parens*);
   void visit(number*);
   void visit(ident*);
private:
   std::stack<std::string> colors_;
};

#endif /* HTML_VISITOR_H */
