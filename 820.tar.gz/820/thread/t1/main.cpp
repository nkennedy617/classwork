#define _REENTRANT
#include <iostream>
#include <iomanip.h>
#include <stdlib.h>
#include <thread.h>
#include "Matrix.h"
// Main program 
int main(int argc, char **argv)
{
int size;
int num_threads;
hrtime_t start, stop;

if (argc != 3) {
        cout << "Usage: " << argv[0] << " Matrix-size Threads" << endl;
        exit(0);
        }

// set the size of the matrix and total threads for this run
size = atoi(argv[1]);
num_threads = atoi(argv[2]);
SetMaxThreads(num_threads);

if (size < num_threads) {
        cerr << "The size of the matrix MUST be greater then number of threads." 
<< endl;
        exit(1);
        }

cout << "Matrix size: [" << size << "x" << size << "]" << endl;
cout << "Number of worker threads: " << num_threads << endl;

// Create the Matrix
Matrix a('A', size), b('B', size), c('C', size);

// fill A & B with data and clear C
a.fill(); b.fill(); c.clear();

// Start the timer
start = gethrtime();

// Do the matrix multiply
MatMult(a, b, c);

// Stop the timer
stop = gethrtime();

// Print the results -- Only if matrix size is small enough
cout << a << b << c;

// Print the run time
cout << "Matrix multiplication time = " 
     << (double)(stop-start)/(double)1000000000 
     << " seconds = " << stop-start << " nanoseconds" << endl;
}
