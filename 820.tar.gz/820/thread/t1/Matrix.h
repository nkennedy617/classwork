#ifndef _matrix_h_
#define _matrix_h_

class Matrix
{
int matsize;
char matid;
double *data;

public:
Matrix(char id, int size);
virtual ~Matrix();
int getsize() {return(matsize);}
double *getdata() {return(data);}
void fill();
void clear();
void print(ostream &s) const;
};

// Function Prototypes
int MatMult(Matrix &a, Matrix &b, Matrix &c);       // Matrix Multiply
void *MultWorker(void *arg);                    // Matrix Thread Function
ostream &operator<<(ostream &s, const Matrix &mat);  // Overloaded output
void SetMaxThreads(int num); // Sets the number of threads to use

#endif 
