#define _REENTRANT
#include <iostream>
#include <iomanip.h>
#include <stdlib.h>
#include <thread.h>
#include "Matrix.h"
using namespace std;

//#include <iomanip.h>
//#include <stdlib.h>
// int true = 1;
//int false = 0;

// Thread control block - used by all threads as global data
struct thr_cntl_block { 
  mutex_t start_mutex;
  cond_t  start_cond;
  mutex_t stop_mutex;
  cond_t  stop_cond;
  Matrix *a, *b, *c;
  int work2do;
  int thrs_running;
  int total_threads;
  int queue; 
} TCB;

////////////////////////////////////////////////////////////////////////
//  Matrix Class Member Functions
////////////////////////////////////////////////////////////////////////

// Matrix constructor
Matrix::Matrix(char id, int size)
{
matid = id;
matsize = size;
data = new double[matsize*matsize];
}

// Matrix destructor
Matrix::~Matrix()
{
matsize = 0;
matid = 0;
delete[] data;
}

// Fills a matrix object with random data
void Matrix::fill()
{
int i;

for (i=0;i<matsize*matsize;i++)
        data[i] = double(rand()/1000);
srand(rand());
}

// Sets all elements of the matrix to 0.0
void Matrix::clear()
{
int i;

for (i=0;i<matsize*matsize;i++)
        data[i] = .0;
}

// Prints a Matrix object (if it is small enough)
void Matrix::print(ostream &s) const
{
int i;

if (matsize < 9) {
   s << "Matrix: " << matid << endl;

   for (i=0;i<matsize*matsize;i++)
        {
       s << setiosflags(ios::fixed) << setprecision(1) 
             << setw(8) << data[i] << " ";

        if ((i%matsize) == matsize-1) s << endl;
        }

   s << endl << endl;
   }
}

// Overloaded << operator - for ease of printing
ostream &operator<<(ostream &s, const Matrix &mat)
{
   mat.print(s);
   return(s);
}

// Sets the maximum number of threads to use
void SetMaxThreads(int num)
{
TCB.total_threads = num;
}

// The matrix multiply subroutine
int MatMult(Matrix &a, Matrix &b, Matrix &c)
{
int static running = false;
int i;

// Only run this code once, if MatMult is called multiple times
// then there is no need to recreate the threads
if (!running)
    {
    // Initialize the synch stuff.
    mutex_init(&TCB.start_mutex, USYNC_THREAD, 0);
    mutex_init(&TCB.stop_mutex, USYNC_THREAD, 0);
    cond_init(&TCB.start_cond, USYNC_THREAD, 0);
    cond_init(&TCB.stop_cond, USYNC_THREAD, 0);

    // set global variables
    TCB.work2do = 0;
    TCB.thrs_running = 0;
    TCB.queue = 0;
    if (!TCB.total_threads) TCB.total_threads = 1;

    // Create the threads - Bound daemon threads
    for (i = 0; i < TCB.total_threads; i++) 
        thr_create(NULL,0, MultWorker, NULL, THR_BOUND|THR_DAEMON, NULL);

    // set the running flag to true so we don't execute this again
    running = true;
    }

// Assign global pointers to the Matrix objects
TCB.a = &a;
TCB.b = &b;
TCB.c = &c;

mutex_lock(&TCB.start_mutex);

  // Assign the number of threads and the amount of work to do
  TCB.work2do = TCB.total_threads;
  TCB.thrs_running = TCB.total_threads;
  TCB.queue = 0;

  // tell all the threads to wake up!
  cond_broadcast(&TCB.start_cond);

mutex_unlock(&TCB.start_mutex);

// yield this LWP 
thr_yield();

// Wait for all the threads to finish
mutex_lock(&TCB.stop_mutex);

  while (TCB.thrs_running) 
        cond_wait(&TCB.stop_cond, &TCB.stop_mutex);

mutex_unlock(&TCB.stop_mutex);

return(0);
}

// Thread routine called from thr_create() as a Bound Daemon Thread
void *MultWorker(void *arg)
{
  int row, col, j, start, stop, id, size;

  // Do this loop forever - or until all the Non-Daemon threads have exited
  while(true)
    {
      // Wait for some work to do
      mutex_lock(&TCB.start_mutex);

        while (!TCB.work2do)
          cond_wait(&TCB.start_cond, &TCB.start_mutex);

        // decrement the work to be done
        TCB.work2do--;

        // get a unique id for work to be done
        id = TCB.queue++;

      mutex_unlock(&TCB.start_mutex);

      // set up the boundary for matrix operation - based on the unique id
      size = TCB.a->getsize();
      start = id * (int)(size/TCB.total_threads);
      stop = start + (int)(size/TCB.total_threads) - 1;
      if (id == TCB.total_threads - 1) stop = size - 1;

      // print what this thread will work on
      //cout << "Thread " << thr_self() << ": Start Row = " << start
      //     << ", Stop Row = " << stop << endl << flush;
      // Do the matrix multiply - within the bounds set above

      for (row=start; row<=stop; row++)
          for (col = 0; col < size; col++)
              for (j = 0; j < size; j++) 
                  TCB.c->getdata()[row*size+col] += 
                  TCB.a->getdata()[row*size+j] * 
                  TCB.b->getdata()[j*size+col]; 

      // signal the main thread that this thread is done with the work
      mutex_lock(&TCB.stop_mutex);
      TCB.thrs_running--;
      cond_signal(&TCB.stop_cond);
      mutex_unlock(&TCB.stop_mutex);
    } 
  return 0;
}
