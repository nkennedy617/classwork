#include <stdio.h>
#include <pthread.h>

void print_message_function( void *ptr );
void matrix_multiplication( void *ptr );
     int m[3];
     int n[3];

main()
{
     pthread_t thread1, thread2;
     char *message1 = "Thread 1";
     int *t=m; 
     char *message2 = "Thread 2";
     int  iret1, iret2;

     m[0]=1;
     m[1]=1;
     m[2]=1;
     n[0]=2;
     n[1]=2;
     n[2]=2;
    /* Create independant threads each of which will execute function */

     /*iret1 = pthread_create( &thread1, NULL, (void*)&print_message_function, (void*) message1);*/
     iret1 = pthread_create( &thread1, NULL, (void*)&matrix_multiplication, (void*) t);
     /*iret2 = pthread_create( &thread2, NULL, (void*)&print_message_function, (void*) message2);*/
     iret2 = pthread_create( &thread2, NULL, (void*)&matrix_multiplication, (void*) message1);

     /* Wait till threads are complete before main continues. Unless we  */
     /* wait we run the risk of executing an exit which will terminate   */
     /* the process and all threads before the threads have completed.   */

     pthread_join( thread1, NULL);
     pthread_join( thread2, NULL); 

     printf("Thread 1 returns: %d\n",iret1);
     printf("Thread 2 returns: %d\n",iret2);
     exit(0);
}

void matrix_multiplication( void *ptr )
{
     char *message;
     int k[3];
     message = (char *) ptr;
        printf("The answer is %s \n", message);
     int i;
     for(i=0; i<3; i++){
        printf("%s \n", message);
        k[i]=m[i]*n[i];
        printf("%d \n", k[i]);
     }
}
void print_message_function( void *ptr )
{
     char *message;
     message = (char *) ptr;
     printf("%s \n", message);
}


