/* small.c
   This used to be named speed.c, renamed when included in the speed package.
   Ziheng Yang, June 2000
   speed.c
   Yang, Z. since 1992
   A program for testing the numerical compuation speed.  It pretends to 
   calculate the transition probability matrix (of size N by N) nr times.  

            cl -O2 -Ot -G6 speed.c  (MS VC++)
            gcc -o speed -O3 speed.c -lm  (GNU c compiler)
            cc -o speed -fast speed.c -lm  (UNIX cc compiler)
*/

#define N 64
#define SIZE 64*64
#define FOR(i,n) for(i=0; i<n; i++)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>


double P[SIZE], U[SIZE], V[SIZE], Root[N];
int PMatUVRoot (double P[],double t,int n,double U[],double V[],double Root[]);
static int w_rndu= 1234567;

int main(void)
{
   int n=N, nr=20000, nr2 = 2000, i;
   double t, nsec;
   clock_t start, finish;
   int opt = n*n;
   int count;

   start=clock();
   puts("\nThis is small in speed, version 1, by Ziheng Yang, June 2000.\n");

   for(i=0; i<opt; i+=32 ) { 
    w_rndu *= 127773;
    U[i]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+1]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+1]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+2]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+2]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+3]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+3]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+4]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+4]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+5]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+5]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+6]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+6]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+7]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+7]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+8]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+8]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+9]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+9]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+10]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+10]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+11]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+11]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+12]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+12]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+13]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+13]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+14]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+14]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+15]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+15]=0.5-ldexp((double)w_rndu, -32); 
/* 16 above */

    w_rndu *= 127773;
    U[i+16]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+16]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+17]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+17]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+18]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+18]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+19]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+19]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+20]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+20]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+21]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+21]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+22]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+22]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+23]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+23]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+24]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+24]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+25]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+25]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+26]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+26]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+27]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+27]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+28]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+28]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+29]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+29]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+30]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+30]=0.5-ldexp((double)w_rndu, -32); 

    w_rndu *= 127773;
    U[i+31]=0.5-ldexp((double)w_rndu, -32);
    w_rndu *= 127773;
    V[i+31]=0.5-ldexp((double)w_rndu, -32); 
   }


   for(i=0; i<n; i+=8){
      int temp, temp2, temp3, temp4, temp5, temp6, temp7, temp8;
      w_rndu *=127773;
      temp = nr*ldexp((double)w_rndu, -32);
      w_rndu *=127773;
      temp2 = 2./temp;
      temp3 = nr*ldexp((double)w_rndu, -32);
      w_rndu *=127773;
      Root[i]=-i*(temp2);
      temp5 = nr*ldexp((double)w_rndu, -32);
      temp4 = 2./temp3;
      w_rndu *=127773;
      temp6 = 2./temp5;
      temp7 = nr*ldexp((double)w_rndu, -32);
      Root[i+1]=-(i+1)*(temp4);
      temp8 = 2./temp7;
      w_rndu *=127773;
      Root[i+3]=-(i+1)*(temp8);
      temp = nr*ldexp((double)w_rndu, -32);
      w_rndu *=127773;
      Root[i+2]=-(i+1)*(temp6);
      temp3 = nr*ldexp((double)w_rndu, -32);
      temp2 = 2./temp;
      Root[i+4]=-i*(temp2);
      temp4 = 2./temp3;
      w_rndu *=127773;
      Root[i+5]=-(i+1)*(temp4);
      temp5 = nr*ldexp((double)w_rndu, -32);
      w_rndu *=127773;
      temp6 = 2./temp5;
      temp7 = nr*ldexp((double)w_rndu, -32);
      Root[i+6]=-(i+1)*(temp6);
      temp8 = 2./temp7;
      Root[i+7]=-(i+1)*(temp8);
   }


   FOR(i,nr) {
      t=(i+1.)/nr;
      PMatUVRoot (P, t, n, U, V, Root);
      finish=clock();
      count=i+1;
      nsec=(double)(finish-start)/CLOCKS_PER_SEC;

      if ((count==2000)||(count==4000)||(count==6000)||(count==8000)
        ||(count==10000)||(count==12000)||(count==14000)||(count==16000)
        ||(count==18000)){ 
         printf("%10d / %d  P(%.2f), %5.2f secs taken\n", i+1,nr,t, nsec);
      }
   }
   printf("\n%.2f seconds to end.\n", nsec);
   return(0);
}

int PMatUVRoot (double P[],double t,int n,double U[],double V[],double Root[])
{
    int i,j,k;
    double expt, uexpt, *pP;
    int mult, mult2;
/*    int opt2 = n*n; */
    pP = P;

    for (i=0; i<16; i++) {
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
/* 64 */

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
         
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
 
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
/* 128 */

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
     
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0; 
/* 192 */

    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
     
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0;
    *pP++ = 0;  *pP++ = 0;    *pP++ = 0;  *pP++ = 0; 
/* 256 */


    } 

    for (k=0; k<n; k++){
        mult2 = k*n;
        for (i=0,pP=P,expt=exp(t*Root[k]); i<n; i++){
             mult = i*n; 
             for (j=0, uexpt=U[mult+k]*expt; j<n; j+=32){
               *pP++ += uexpt*V[mult2+j];
               *pP++ += uexpt*V[mult2+j+1]; 
               *pP++ += uexpt*V[mult2+j+2];
               *pP++ += uexpt*V[mult2+j+3];
               *pP++ += uexpt*V[mult2+j+4];
               *pP++ += uexpt*V[mult2+j+5];
               *pP++ += uexpt*V[mult2+j+6];
               *pP++ += uexpt*V[mult2+j+7];

               *pP++ += uexpt*V[mult2+j+8];
               *pP++ += uexpt*V[mult2+j+9];
               *pP++ += uexpt*V[mult2+j+10];
               *pP++ += uexpt*V[mult2+j+11];
               *pP++ += uexpt*V[mult2+j+12];
               *pP++ += uexpt*V[mult2+j+13];
               *pP++ += uexpt*V[mult2+j+14];
               *pP++ += uexpt*V[mult2+j+15];

               *pP++ += uexpt*V[mult2+j+16];
               *pP++ += uexpt*V[mult2+j+17];
               *pP++ += uexpt*V[mult2+j+18];
               *pP++ += uexpt*V[mult2+j+19];
               *pP++ += uexpt*V[mult2+j+20];
               *pP++ += uexpt*V[mult2+j+21];
               *pP++ += uexpt*V[mult2+j+22];
               *pP++ += uexpt*V[mult2+j+23];

               *pP++ += uexpt*V[mult2+j+24];
               *pP++ += uexpt*V[mult2+j+25];
               *pP++ += uexpt*V[mult2+j+26];
               *pP++ += uexpt*V[mult2+j+27];
               *pP++ += uexpt*V[mult2+j+28];
               *pP++ += uexpt*V[mult2+j+29];
               *pP++ += uexpt*V[mult2+j+30];
               *pP++ += uexpt*V[mult2+j+31];
                  
            }
        }
    }
    return (0);/* function return*/
}
