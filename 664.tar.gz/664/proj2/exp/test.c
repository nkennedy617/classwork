#include <math.h>
#include <stdio.h>


int main() {
int i, j, me=0;
 if(me==1)
 else
  for(i=0; i<2; i++) for(j=0; j<2; j++) me++;
    for(i=0; i<2; i++) for(j=0; j<2; j++) printf("here\n");
    for(i=0; i<2; i++) for(j=0; j<2; j++) printf("there\n");
    for(i=0; i<2; i++) for(j=0; j<2; j++){ printf("where\n");
     printf("end\n");}
}
