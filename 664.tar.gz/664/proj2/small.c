/* small.c
   This used to be named speed.c, renamed when included in the speed package.
   Ziheng Yang, June 2000


   speed.c
   Yang, Z. since 1992
   A program for testing the numerical compuation speed.  It pretends to 
   calculate the transition probability matrix (of size N by N) nr times.  


            cl -O2 -Ot -G6 speed.c  (MS VC++)
            gcc -o speed -O3 speed.c -lm  (GNU c compiler)
            cc -o speed -fast speed.c -lm  (UNIX cc compiler)
*/

#define N 64
#define FOR(i,n) for(i=0; i<n; i++)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double P[N*N], U[N*N], V[N*N], Root[N];
int PMatUVRoot (double P[],double t,int n,double U[],double V[],double Root[]);
double rndu (void);

int main(void)
{
   int n=N, nr=20000, i;
   double t, nsec;
   clock_t start, finish;

   start=clock();
   puts("\nThis is small in speed, version 1, by Ziheng Yang, June 2000.\n");
   FOR(i,n*n) { U[i]=0.5-rndu(); V[i]=0.5-rndu(); }
   FOR(i,n) Root[i]=-i*(2./nr*rndu());
   FOR(i,nr) {
      t=(i+1.)/nr;
      PMatUVRoot (P, t, n, U, V, Root);
      finish=clock();
      nsec=(double)(finish-start)/CLOCKS_PER_SEC;
      if ((i+1)%(nr/10)==0)
         printf("%10d / %d  P(%.2f), %5.2f secs taken\n", i+1,nr,t, nsec);
   }
   printf("\n%.2f seconds to end.\n", nsec);
   return(0);
}

int PMatUVRoot (double P[],double t,int n,double U[],double V[],double Root[])
{
/*  get transition P matrix by using U, V, and Root
*/
    int i,j,k;
    double expt, uexpt, *pP;

    for (i=0,pP=P; i<n*n; i++) *pP++ = 0;
    for (k=0; k<n; k++) 
        for (i=0,pP=P,expt=exp(t*Root[k]); i<n; i++) 
            for (j=0,uexpt=U[i*n+k]*expt; j<n; j++) 
               *pP++ += uexpt*V[k*n+j];
    return (0);
}

double rndu (void)
{
   static int w_rndu=1234567;
   w_rndu *= 127773;
   return ldexp((double)w_rndu, -32);
}
