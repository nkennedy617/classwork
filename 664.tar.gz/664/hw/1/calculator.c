/* benchmark performance calculator for 464/664
 * mark smotherman, fall 1997
 *
 * reads in a file named "benchmarks", which should have two numbers per
 * line - execution time for machine X and execution time for machine Y.
 * the program assumes that X is faster than Y, and calculates speedups.
 *
 * the following calculator commands can be issued (need only first letter)
 *   quit
 *   end
 *   exit
 *   times            (initialize the program to use execution times)
 *   rates            (initialize the program to use execution rates)
 *   x-normalization  (normalize numbers to machine X)
 *   y-normalization  (normalize numbers to machine Y)
 *   arithemetic-mean
 *   harmonic-mean
 *   geometric-mean
 *
 * the program also determines if the total execution times can be
 * recomputed from the mean values.
 */

#include <stdio.h>
#include <math.h>

#define FILENAME "benchmarks"



/* global data structure */

#define MAX_PROGS 50

  int num_times;             /* number of saved times */
  double time[2][MAX_PROGS]; /* saved times */

  int num_progs;             /* number of current times or rates*/
  double prog[2][MAX_PROGS]; /* current times or rates */

  double sum_times[2];       /* total execution times */

#define TIME 0
#define RATE 1

  int time_or_rate;          /* logical flag for time or rate */

#define NONE 0
#define ARITH 1
#define HARM 2
#define GEO 3

  int mean;                  /* logical flag for which mean */

#define UNNORMALIZED 0
#define NORM_X 1
#define NORM_Y 2

  int normalized;            /* logical flag for how normalized */



/* routines */

void read_times(void){
  int i;
  FILE *fp;
  fp = fopen(FILENAME,"r");
  if(fp==NULL){
    printf("cannot open the file named %s\n",FILENAME);
    exit(-1);
  }
  i = 0;
  while(fscanf(fp,"%lf %lf",&time[0][i],&time[1][i])!=EOF){
    i++;
    if(i>=MAX_PROGS){
      printf("too many entries in file named %s\n",FILENAME);
      printf("change MAX_PROGS value in program and recompile\n");
      exit(-1);
    }
  }
  num_times = i;
}

void init_time(void){
  int i;
  num_progs = num_times;
  for(i=0;i<num_progs;i++){
    prog[0][i] = time[0][i];
    prog[1][i] = time[1][i];
  }
  time_or_rate = TIME;
  mean = NONE;
  normalized = UNNORMALIZED;
  sum_times[0] = 0.0;
  sum_times[1] = 0.0;
  for(i=0;i<num_progs;i++){
    sum_times[0] += prog[0][i];
    sum_times[1] += prog[1][i];
  }
  printf("quit, times, rates, x-norm, y-norm, arith, harm, geo\n");
}

void init_rate(void){
  int i;
  init_time();
  for(i=0;i<num_progs;i++){
    prog[0][i] = 1.0/prog[0][i];
    prog[1][i] = 1.0/prog[1][i];
  }
  time_or_rate = RATE;
}

void normalize_x(void){
  int i;
  for(i=0;i<num_progs;i++){
    prog[1][i] /= prog[0][i];
    prog[0][i] = 1.0;
  }
  normalized = NORM_X;
}

void normalize_y(void){
  int i;
  for(i=0;i<num_progs;i++){
    prog[0][i] /= prog[1][i];
    prog[1][i] = 1.0;
  }
  normalized = NORM_Y;
}

void arith_mean(void){
  int i;
  double sum[2] = {0.0, 0.0};
  if(mean!=NONE){
    printf("\n*** note: a mean has already been taken\n");
    printf("          your command is ignored\n");
    return;
  }
  for(i=0;i<num_progs;i++){
    sum[0] += prog[0][i];
    sum[1] += prog[1][i];
  }
  prog[0][0] = sum[0]/num_progs;
  prog[1][0] = sum[1]/num_progs;
  num_progs = 1;
  mean = ARITH;
}

void harm_mean(void){
  int i;
  double sum[2] = {0.0, 0.0};
  if(mean!=NONE){
    printf("\n*** note: a mean has already been taken\n");
    printf("          your command is ignored\n");
    return;
  }
  for(i=0;i<num_progs;i++){
    sum[0] += 1/prog[0][i];
    sum[1] += 1/prog[1][i];
  }
  prog[0][0] = num_progs/sum[0];
  prog[1][0] = num_progs/sum[1];
  num_progs = 1;
  mean = HARM;
}

void geo_mean(void){
  int i;
  double prod[2] = {1.0, 1.0};
  if(mean!=NONE){
    printf("\n*** note: a mean has already been taken\n");
    printf("          your command is ignored\n");
    return;
  }
  for(i=0;i<num_progs;i++){
    prod[0] *= prog[0][i];
    prod[1] *= prog[1][i];
  }
  prog[0][0] = pow(prod[0],(double)1.0/num_progs);
  prog[1][0] = pow(prod[1],(double)1.0/num_progs);
  num_progs = 1;
  mean = GEO;
}

void display(void){
  int i;
  double factor[2];
  if(time_or_rate==TIME){
    printf("\n    X        Y     (times - ");
  }else{
    printf("\n    X        Y     (rates - ");
  }
  if(mean==ARITH){
    printf("arithmetic means - ");
  }else if(mean==HARM){
    printf("harmonic means - ");
  }else if(mean==GEO){
    printf("geometric means - ");
  }
  if(normalized==NORM_X){
    printf("normalized wrt X)\n");
  }else if(normalized==NORM_Y){
    printf("normalized wrt Y)\n");
  }else{
    printf("unnormalized)\n");
  }
  for(i=0;i<num_progs;i++){
    printf("%8.3f %8.3f  speedup of X over Y is ",prog[0][i],prog[1][i]);
    if(time_or_rate==TIME){
      printf("%8.3f\n",prog[1][i]/prog[0][i]);
      if(num_progs==1){
        factor[0] = sum_times[0]/prog[0][0];
        factor[1] = sum_times[1]/prog[1][0];
        if((factor[0]<1.01*factor[1])&&(factor[0]>.99*factor[1])){
          printf(" --- can predict total times\n");
          printf("     multiply by factor of %8.3f\n",factor[0]);
        }else{
          printf(" ... cannot predict total times\n");
          printf("%8.3f %8.3f are the factors\n",factor[0],factor[1]);
        }
      }
    }else{
      printf("%8.3f\n",prog[0][i]/prog[1][i]);
      if(num_progs==1){
        factor[0] = sum_times[0]*prog[0][0];
        factor[1] = sum_times[1]*prog[1][0];
        if((factor[0]<1.01*factor[1])&&(factor[0]>.99*factor[1])){
          printf(" --- can predict total times - take reciprocal\n");
          printf("     and multiply by factor of %8.3f\n",factor[0]);
        }else{
          printf(" ... cannot predict total times\n");
          printf("%8.3f %8.3f are the factors\n",factor[0],factor[1]);
        }
      }
    }
  }
}

int main(void){
  char action[80];
  read_times();
  action[0] = 't';
  printf("464/664 benchmark performance calculator\n");
  printf("  you can use the first letter of a command to operate\n");
  printf("  on benchmark data from a file named '%s',\n",FILENAME);
  printf("  which has one line per program, two machine execution\n");
  printf("  times on each line (w/ times from faster machine on left)\n\n");
  while((action[0] != 'q')&&(action[0] != 'e')){
    switch(action[0]){
      case 't': init_time();
                display();
                break;
      case 'r': init_rate();
                display();
                break;
      case 'x': normalize_x();
                display();
                break;
      case 'y': normalize_y();
                display();
                break;
      case 'a': arith_mean();
                display();
                break;
      case 'h': harm_mean();
                display();
                break;
      case 'g': geo_mean();
                display();
                break;
      default:  printf("try again - didn't recognize command\n");
    }
    printf("\nbenchmark calculator command > ");
    scanf("%s",&action);
  }
}
