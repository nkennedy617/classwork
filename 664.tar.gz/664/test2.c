#include <math.h>
#include <stdio.h>

/*#define PI   3.1415926543*/

int main() {
       printf("sin(pi) = %f\n", sin(3.1415926543));
       printf("sin(pi/2) = %f\n", sin(3.1415926543/2));
       exit(0);
}
