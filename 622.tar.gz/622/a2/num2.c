/* Nell Beatty 							  */
/* Computer Science 622				         	  */
/* Programming Assignment #2 					  */
/* September 16, 2000 						  */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>

main()
{ /* Declarations for the whole program */
  int rc;/* return code used from fork */
  int p[2]; /*pipe shared between child1 & child2*/ 
  int q[2]; /*pipe shared between child2 & child3*/ 
  int out=1; /*stdout indentifier */
  int in=0; /*stdin indentifier */

pipe(p); /* construct pipes p, q */
pipe(q);
/* Nex section will create child1 & call its code*/
/* It will pass, stdin as in, pipe p */
 rc=fork();
 if(rc==0)
 {
   child1(in,p[1]);
 }
 close(p[1]);
/* Next section will create child2 & call its code */
/* It will pass pipe p and pipe q */
 rc=fork();
 if(rc==0)
 {
   child2(p[0], q[1]);
 }
 close(q[1]);
/* Next section will create child3 & call its code */
/* it will pass pipe q and stdout as out */
 rc=fork();
 if(rc==0)
 {
   child3(q[0], out);
 }
/* Will now wait for children to do their thing*/
 wait(0);
 wait(0);
 wait(0);

 exit(1);
}
