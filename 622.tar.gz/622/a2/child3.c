#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int child3(int q, int out)
{
	/*declarations*/
        char buf[20]; /*character bufffer for read/write*/
         int len=0; /*length of read/write*/
        int i; /* loop variable*/
        char de_byte; /*temp variable*/

	/* read pipe, decrypt data, write stdout */
	while((len=read(q,buf,sizeof(buf))) >0)
	{
                for(i=0; i<len; i++)
                {
			/* decrypt is in separate file */
		   	de_byte=decrypt(buf[i]);
                        buf[i]=de_byte;
                }
        	write(out,buf,len);
	}
 

        	exit(1);
}

