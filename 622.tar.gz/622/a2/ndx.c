#include <stdio.h>
#include <stdlib.h>

int return_ndx(  )
{
   FILE *fd1;
   int myndx;
 
	fd1=fopen("crypt.out", "r");
 	fscanf(fd1, "%d", &myndx);
        fclose(fd1);
     return myndx;
}
