#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>

int child2(int p, int q)
{
	/* declarations */
        char buf[20]; /* character buffer for read/write*/
         int len=0; /* length of read */
      	int open_success; /* file handle for backup crypt file */
        int i; /* loop variable */
        char en_byte; /* temp variable */

	/* read pipe, encrypt data, write to pipe */
	while((len=read(p,buf,sizeof(buf))) >0)
	{
		open_success=open("crypt.out", O_WRONLY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
                for(i=0; i<len; i++)
                {
			/* encrypt in separate file */
		   	en_byte=encrypt(buf[i]);
                        buf[i]=en_byte;
                }
        	write(q,buf,len);
		write(open_success, buf, len);
	}
 

        	exit(1);
}

