#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int child1(int in, int p)
{
	/* declarations */
        char buf[20]; /* char buffer */
        int len=0; /* length of read */

	/* read in stdin, and write to pipe */
	while((len=read(in,buf,sizeof(buf)))> 0)
	{
       		 write(p,buf,len);
	}
        exit(1);
}

