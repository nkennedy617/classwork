#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int ENDX=0; /* encrypted index for TOTAL CHARS PRocesssed*/
int DNDX=0; /* decrypted index for TOTAL Charactes processed*/
char encrypt(char in)
{
  unsigned char out; /*Current output byte */
  unsigned char val; /*Work Value */
  /*encryption algorithm provided by dr. westall */
  int a;
  val = in;
  a= val;
  val ^=0xff;
  a= (val);
  val = (val >> 4) + ((val & 0xf) << 4);
  a= (val);
  val -= (-29 + ENDX);
  a= (val);
  
  out = val;
  ENDX++; /* increment index*/ 
  return out;
}
char decrypt(char in)
{
  unsigned char out; /*Current output byte */
  unsigned char val; /*Work Value */
  /*decryption reverse of encryption */
  int a;
  val = in;
  a= (val);
  val += (-29 + DNDX);
  a= (val);
  val = (val << 4) + ((val ) >> 4);
  a= (val);
  val ^=0xff;
  a= (val);
  out = val;

  DNDX++; /* increment running total of characters index*/
  return out;
}
