/* Nell Beatty                  */
/* Computer Science 622         */
/* November 9, 2000             */
/* Resman.c                     */
/* This program is a manager of serially reusable resources */

#include <stdlib.h>
#include <stdio.h>

void get_process_and_res_count(){
  scanf("%d%d", &pcount, &rcount);
  return;
}

void get_initial_avail_vector(){
  int i=0;
  for(i=0; i<=rcount-1; i++)
  {
    scanf("%d", &availres[i]);
  }
}
void initial_blockpids_vector(){
  int i=0;
  for(i=0; i<=19; i++)
  {
   blockpids[i]=0;
  }
}

int get_request(){
  char *line;
  int rc=0;
  int tmpresid;
  int tmprescount;

  scanf("%d%d%d", &pid, &action, &numpairs);

  switch (numpairs) {
     case 1:
        scanf("%d%d", &req_array[0].resid, &req_array[0].rescount);
        break;
     case 2:
        scanf("%d%d%d%d", &req_array[0].resid, &req_array[0].rescount, &req_arra
y[1].resid, &req_array[1].rescount);
        break;
     case 3:
        scanf("%d%d%d%d%d%d", &req_array[0].resid, &req_array[0].rescount, &req_
array[1].resid, &req_array[1].rescount, &req_array[2].resid, &req_array[2].resco
unt);
        break;
     default:
        printf("Error in request! Exiting....\n");
        exit(EXIT_FAILURE);
   }
  return 1;
}
