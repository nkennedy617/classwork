/* Nell Beatty			*/
/* Computer Science 622		*/
/* November 9, 2000		*/
/* Resman.c			*/
/* This program is a manager of serially reusable resources */

#include <stdlib.h>
#include <stdio.h>

typedef struct 
{
  int resid;
  int rescount;
} request_t;

/* Declarations to be set by the get functions */
  request_t req_array; /* Max of 3 res classes / req */

int get_request(){
  char *line;
  int rc=0;
  int tmpresid;
  int tmprescount;

  rc=scanf("%s", &line);
  if (rc ==0)
  {
    return 0;
  } 
  sscanf(line, "%d%d%d", &pid, &action, &numpairs);
  
  switch (numpairs) {
     case 1:
      	sscanf(line, "%d%d%d%d%d", &pid, &action, &numpairs, &tmpresid, &tmprescount);
        req_array->resid=tmpresid;
      	/*sscanf(line, "%d%d%d%d%d", &pid, &action, &numpairs, &req_array[0]->resid, &req_array[0]->rescount);*/
 		break; 
     default:
        printf("Error in request! Exiting....\n");
        exit(EXIT_FAILURE);
   }
  return 1;
}


main(){
int numclasses;

while ((numclasses=get_request()) > 0)
{
  int stat;
  stat = process_request(numclasses, req_array);
  if (stat < 0)
    break;
}
}

