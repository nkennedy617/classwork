/* Nell Beatty			*/
/* Computer Science 622		*/
/* November 9, 2000		*/
/* Resman.c			*/
/* This program is a manager of serially reusable resources */

#include <stdlib.h>
#include <stdio.h>

typedef struct request{
	int resid;
	int rescount;
} reequest_t
main()
{
  int p1, p2, p3, p4, p5, p6;
  reequest_t parray[3];
  char *line;
  parray[0]->resid=0;
  line="5 4 3 2 1 0";
  sscanf(line, "%d%d%d%d%d", &p1, &p2, &p3, &p4, &p5);
  printf("%d %d", p1, p4);
  printf("ha\n");
}

