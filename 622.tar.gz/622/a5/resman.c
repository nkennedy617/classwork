/* Nell Beatty                  */
/* Computer Science 622         */
/* November 9, 2000             */
/* Resman.c                     */
/* This program is a manager of serially reusable resources */

#include <stdlib.h>
#include <stdio.h>

typedef struct request{
   int resid;
   int rescount;
} request_t;

  request_t req_array[3];
  int availres[10]; /* Initial Available Resource Vector -- INPUT */
  int pcount; /* process count -- INPUT */
  int rcount; /* resource count -- INPUT */
  int allocres[20][10]; /* array to track which process has what */
  int requestres[20][10]; /* array to track which process wants what */
  int pid; /* current process id */
  int action; /*current action */
  int numpairs; /*current number of pairs in the request */
  int blockpids[20]; /* blocked process vector */
  int numblocked=0; /* number of blocked processes */

void get_process_and_res_count(){
  scanf("%d%d", &pcount, &rcount);
  return;
}

void get_initial_avail_vector(){
  int i=0;
  for(i=0; i<=rcount-1; i++)
  {
    scanf("%d", &availres[i]);
  }
}
void initial_blockpids_vector(){
  int i=0;
  for(i=0; i<=19; i++)
  {
   blockpids[i]=0;
  }
}

int get_request(){
  char *line;
  int rc=0;
  int tmpresid;
  int tmprescount;

  scanf("%d%d%d", &pid, &action, &numpairs);

  switch (numpairs) {
     case 1:
	scanf("%d%d", &req_array[0].resid, &req_array[0].rescount);
    	break;
     case 2:
  	scanf("%d%d%d%d", &req_array[0].resid, &req_array[0].rescount, &req_array[1].resid, &req_array[1].rescount);
 	break;
     case 3:
  	scanf("%d%d%d%d%d%d", &req_array[0].resid, &req_array[0].rescount, &req_array[1].resid, &req_array[1].rescount, &req_array[2].resid, &req_array[2].rescount);
	break;
     default:
        printf("Error in request! Exiting....\n");
        exit(EXIT_FAILURE);
   }
  return 1;
}

int process_request(int numclasses) {
 if(action==1) /* allocate resource */
 {
   myallocate();
 }
 else /* free resource */
 {
   myfree();
 }
 return 1;
} /* end function */

void deadlock_detect()
{
 int i, j=0;
 int workavailres[10];
 int workallocres[20][10];
 int workrequestres[20][10];
 int mark_array[20];
 int foundflag;
 int loopagain =1;
 int firsttime=1;
 int allmarked=0;
 /* Make a working copy of the tables */
 for(i=0; i<=pcount -1; i++)
 {
   for(j=0; j<=rcount -1; j++)
   {
     workavailres[j]=availres[j];
     workallocres[i][j]=allocres[i][j];
     workrequestres[i][j]=requestres[i][j];
   }
 }


 /* unmark all processes */ for(i=0; i<=pcount -1; i++)
 {
   mark_array[i]=0; /* 0= unmark */
 }

 /* clear all foundflags */
 foundflag=0;

 while(loopagain)
 {
   /* For all unmarked processes */
   for(i=0; i<=pcount -1; i++)
   {
      if(mark_array[i] == 1)
      {
         foundflag=0;
         break;
      }
      for(j=0; j<=rcount -1; j++)
      {
 	   
            if(workrequestres[i][j]<= workavailres[j])
	    {
 	      /* mark process */
              mark_array[i]=1;

	      /* set found flag */
              foundflag=1;

	      /* add allocated[i][j] to available[j] for all res */
	      workavailres[j] = workavailres[j] + workallocres[i][j];
	    }
            else
            {
	     loopagain=0;
             foundflag=0;
            }
       }
   }
   if(foundflag)
     loopagain=1;
   else
     loopagain=0;
 }

 /* set allmarked flag */
 /* will be unset if any not marked */
 allmarked=1;
 /* if all processes marked no deadlock */
 for(i=0; i<=pcount -1; i++)
 {
   if(mark_array[i] != 0)
   {
      allmarked=0;
   }

 }
     if(numpairs==1)
     {
       printf("   %d   %d   %d    -   -    -    -", pid, req_array[0].resid, req_array[0].rescount);
       printf("   Alloc   Block     N/A        Yes\n");

     }
     if(numpairs==2)
     {
       printf("   %d   %d   %d    %d   %d   -    -", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount);
       printf("   Alloc   Block     N/A        Yes\n");

     }
     if(numpairs==3)
     {
       printf("   %d   %d   %d    %d   %d   %d   %d", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount, req_array[2].resid, req_array[2].rescount);
       printf("   Alloc   Block     N/A        Yes\n");

     }
 if(allmarked)
 {
     printf("System terminating due to deadlock\n");
     printf("Deadlocked processes inculde ");
     for(i=0; i<=pcount -1; i++)
     {
       if(mark_array[i]==0)
         printf("%d", i);
     }
 
 }
 else
 {
   /* give back the resources */
   for(i=0; i<=pcount -1; i++)
   {
     for(j=0; j<=rcount -1; j++)
     {
        numblocked =0;
        availres[j] = workavailres[j];
        allocres[i][j] = workallocres[i][j];
        requestres[i][j] = workrequestres[i][j];
     }
   }
 }
 return;
}

int myallocate()
{
int needresnum=0;
 if(numpairs == 1)
 {
  if(availres[req_array[0].resid] >= req_array[0].rescount)
  {
    availres[req_array[0].resid] = availres[req_array[0].resid] - req_array[0].rescount;
    allocres[pid][req_array[0].resid] = req_array[0].rescount;
    printf("   %d   %d   %d    -   -    -    -", pid, req_array[0].resid, req_array[0].rescount);
    printf("   Alloc   Grant     N/A        No\n");
  } 
  else
  {
   
    /* mark process as blocked */
    blockpids[pid] = 1;

    /* if #requested > #available */
    needresnum = (availres[(req_array[0].resid)]) - (req_array[0].rescount);
    allocres[pid][req_array[0].resid] = availres[req_array[0].resid];
    availres[req_array[0].resid] = 0;
    requestres[pid][req_array[0].resid] = 0 - needresnum;
 
    /* increment number of blocked processes */
    numblocked++;
    if(numblocked<=1)
    {
      printf("   %d   %d   %d    -   -    -    -", pid, req_array[0].resid, req_array[0].rescount);
      printf("   Alloc   Block     N/A        No\n");
    }
    else
    {
      deadlock_detect();
    }

  }

 }

 if(numpairs == 2 )
 {
  if((availres[req_array[0].resid] >= req_array[0].rescount) && (availres[req_array[1].resid] >= req_array[1].rescount))
  {
    availres[req_array[0].resid] = availres[req_array[0].resid] - req_array[0].rescount;
    allocres[pid][req_array[0].resid] = req_array[0].rescount;
    availres[req_array[1].resid] = availres[req_array[1].resid] - req_array[1].rescount;
    allocres[pid][req_array[1].resid] = req_array[1].rescount;
    printf("   %d   %d   %d    %d   %d   -    -", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount);
    printf("   Alloc   Grant     N/A        No\n");
  } 
  else
  {
    /* mark process as blocked */
    blockpids[pid] = 1;

    /* have enough 0, not enough 1 */
    if(availres[req_array[0].resid] >= req_array[0].rescount)
    {
      availres[req_array[0].resid] = availres[req_array[0].resid] - req_array[0].rescount;
      allocres[pid][req_array[0].resid] = req_array[0].rescount;
      /* if #requested > #available */
      needresnum = (availres[(req_array[1].resid)]) - (req_array[1].rescount);
      allocres[pid][req_array[1].resid] = availres[req_array[1].resid];
      availres[req_array[1].resid] = 0;
      requestres[pid][req_array[1].resid] = 0 - needresnum;
    }
    /* have enough 1, not enough 0 */
    else
    {
      availres[req_array[1].resid] = availres[req_array[1].resid] - req_array[1].rescount;
      allocres[pid][req_array[1].resid] = req_array[1].rescount;
      /* if #requested > #available */
      needresnum = (availres[(req_array[0].resid)]) - (req_array[0].rescount);
      allocres[pid][req_array[0].resid] = availres[req_array[0].resid];
      availres[req_array[0].resid] = 0;
      requestres[pid][req_array[0].resid] = 0 - needresnum;
    }
    /* increment number of blocked processes */
    numblocked++;
    if(numblocked<=1)
    {
      printf("   %d   %d   %d    %d   %d   -    -", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount);
      printf("   Alloc   Block     N/A        No\n");
    }
    else
    {
      deadlock_detect();
    }
  }
 }
 
 if(numpairs == 3 )
 {
  if((availres[req_array[0].resid] >= req_array[0].rescount) && (availres[req_array[1].resid] >= req_array[1].rescount) && (availres[req_array[2].resid] >= req_array[2].rescount))
  {
    availres[req_array[0].resid] = availres[req_array[0].resid] - req_array[0].rescount;
    allocres[pid][req_array[0].resid] = req_array[0].rescount;
    availres[req_array[1].resid] = availres[req_array[1].resid] - req_array[1].rescount;
    allocres[pid][req_array[1].resid] = req_array[1].rescount;
    availres[req_array[2].resid] = availres[req_array[2].resid] - req_array[2].rescount;
    allocres[pid][req_array[2].resid] = req_array[2].rescount;
    printf("   %d   %d   %d    %d   %d   %d   %d", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount, req_array[2].resid, req_array[2].rescount);
    printf("   Alloc   Grant     N/A        No\n");
  } 
  else
  {
    printf("%d\n", availres[1]);
    /* mark process as blocked */
    blockpids[pid] = 1;
    
    /* have enough 0 */
    if(availres[req_array[0].resid] >= req_array[0].rescount)
    {
      availres[req_array[0].resid] = availres[req_array[0].resid] - req_array[0].rescount;
      allocres[pid][req_array[0].resid] = req_array[0].rescount;
    }
    else
    {
      /* if #requested > #available */
      needresnum = (availres[(req_array[0].resid)]) - (req_array[0].rescount);
      allocres[pid][req_array[0].resid] = availres[req_array[0].resid];
      availres[req_array[0].resid] = 0;
      requestres[pid][req_array[0].resid] = 0 - needresnum;
    }
    /* have enough 1 */
    if(availres[req_array[1].resid] >= req_array[1].rescount)
    {
      availres[req_array[1].resid] = availres[req_array[1].resid] - req_array[1].rescount;
      allocres[pid][req_array[1].resid] = req_array[1].rescount;
    }
    else
    {
      /* if #requested > #available */
      needresnum = (availres[(req_array[1].resid)]) - (req_array[1].rescount);
      allocres[pid][req_array[1].resid] = availres[req_array[1].resid];
      availres[req_array[1].resid] = 0;
      requestres[pid][req_array[1].resid] = 0 - needresnum;
    }
    /* have enough 2 */
    if(availres[req_array[2].resid] >= req_array[2].rescount)
    {
      availres[req_array[2].resid] = availres[req_array[2].resid] - req_array[2].rescount;
      allocres[pid][req_array[2].resid] = req_array[2].rescount;
    }
    else
    {
      /* if #requested > #available */
      needresnum = (availres[(req_array[2].resid)]) - (req_array[2].rescount);
      allocres[pid][req_array[2].resid] = availres[req_array[2].resid];
      availres[req_array[2].resid] = 0;
      requestres[pid][req_array[2].resid] = 0 - needresnum;
    }
    /* increment number of blocked processes */
    numblocked++;
    if(numblocked<=1)
    {
    printf("   %d   %d   %d    %d   %d   %d   %d", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount, req_array[2].resid, req_array[2].rescount);
    printf("   Alloc   Block     N/A        No\n");
    }
    else
    {
      deadlock_detect();
    }

  }

 }
 return 1;
}
int myfree()
{
 int i;
 if(numpairs == 3)
 {
   availres[req_array[0].resid] = availres[req_array[0].resid] + req_array[0].rescount; 
   availres[req_array[1].resid] = availres[req_array[1].resid] + req_array[1].rescount; 
   availres[req_array[2].resid] = availres[req_array[2].resid] + req_array[2].rescount; 
    printf("   %d   %d   %d    %d   %d   %d   %d", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount, req_array[2].resid, req_array[2].rescount);
    printf("   Free    N/A       ");
   for(i=0; i<= pcount - 1; i++)
   {
     if((blockpids[i]) == 0)
         printf("%d,", i);
   }
    printf("      No\n");
 }
 if(numpairs == 2)
 {
   availres[req_array[0].resid] = availres[req_array[0].resid] + req_array[0].rescount; 
   availres[req_array[1].resid] = availres[req_array[1].resid] + req_array[1].rescount; 
      printf("   %d   %d   %d    %d   %d   -    -", pid, req_array[0].resid, req_array[0].rescount, req_array[1].resid, req_array[1].rescount);
    printf("   Free    N/A       ");
   for(i=0; i<= pcount - 1; i++)
   {
     if((blockpids[i]) == 0)
         printf("%d,", i);
   }
    printf("      No\n");
 }
 if(numpairs == 1)
 {
   availres[req_array[0].resid] = availres[req_array[0].resid] + req_array[0].rescount; 
    printf("   %d   %d   %d    -   -    -    -", pid, req_array[0].resid, req_array[0].rescount);
    printf("   Free    N/A       ");
   for(i=0; i<= pcount - 1; i++)
   {
     if((blockpids[i]) == 0)
         printf("%d,", i);
   }
    printf("      No\n");
 }
 return 1;
}

main(){
int numclasses;
int printflag=1;
get_process_and_res_count();
get_initial_avail_vector();
initial_blockpids_vector();

while ((numclasses=get_request()) > 0)
{
  int stat;
  if(printflag)
  {
    printf("-------------------------------------------------------------------\n");
    printf("Proc  Res Req Res Req Res Req  Action Status Unblocked   Deadlock\n");
    printf("  ID   ID SIZE ID SIZE ID SIZE		      Process\n");
   printflag=0;
  }
  stat = process_request(numclasses);
  if (stat < 0)
    break;
}

}

