/* rdrwrtr.c  */

/* This programs tests Readers and Writers serialization. */
/* Note that you must include -lrt when compiling this    */

/* To compile (on a Solaris == SunOS 5.x machine )        */
/*    cc pthreadex.c -lpthread -lrt                       */
/* To run                                                 */
/*    a.out 1000000                                       */


#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/times.h>

#include "enqdeq.h"

/* Here is the QCB that will represent the resource */

struct qcbtype qcb;

#define MAX_THREADS 16         /* Maximum possible number of threads  */
#define NUM_WRITERS  2         /* Number of threads to us in this run */

pthread_t td[MAX_THREADS];      /* Thread descriptors for the new threads */


volatile int shared = 0;       /* The shared variable being updated */
int loopcount = 100000;        /* Default value for increment count */

FILE *io;

/**/
/* Sleep for specified number of micro seconds... We use */
/* this one because usleep causes nasty SIGALARM type    */
/* problems with Solaris.                                */

void microsleep(
int microsecs)
{
  struct timeval  now;        /* All of these different time structures */
  struct timespec timeout;    /* are a pain in the neck..               */
  pthread_cond_t  cv;
  pthread_mutex_t mtx;
  int             null = 0;

/* Initialize the CV and MTX we will use for the sleep */
/* If they aren't initialized they won't work.         */

   pthread_cond_init(&cv, NULL);
   pthread_mutex_init(&mtx, NULL);
   gettimeofday(&now, &null);

/* Add timeount and correct for rollover if need be */

   now.tv_usec += microsecs;
   if (now.tv_usec >= 1000000)
   {
      now.tv_usec -= 1000000;
      now.tv_sec  += 1;
   }

/* Timeout value is specified in nsec though */

   timeout.tv_sec = now.tv_sec;
   timeout.tv_nsec = now.tv_usec * 1000;

/* This cv will NEVER be broadcast.. it will always */
/* just timeout                                     */

   pthread_cond_timedwait(&cv, &mtx, &timeout);
}

/* Writer threads run this function */

void *wthread(
void *parm)    /* Logical thread id */
{
   int i;
   int id;
   int local;
   FILE *work;

   id = (int)parm;
   printf("Made it in %d \n", id);

   for (i = 0; i < loopcount; i++)
   {
      enqueue(&qcb, WRITE, id);
      work = fopen("test.dat", "r");
      if (fscanf(work, "%d", &local) != 1)
      {
          printf("YEOW: my input file is trashed \n");
          printf("Thread %d exiting \n", id);
          perror("Failure was");
          fclose(work);
          pthread_exit(0);
      }
      fclose(work);

      sched_yield();

      local += 1;
      work = fopen("test.dat", "w");
      fprintf(work, "%d", local);
      fclose(work);
      dequeue(&qcb, id);
      microsleep(10000);
   }
   pthread_exit((void *)0);
}

/* Reader threads run this one */

void *rthread(
void *parm)    /* Logical thread id.. */
{
   int i;
   int id;
   int local;
   FILE *work;

   id = (int)parm;
   printf("Made it in %d \n", id);

   for (i = 0; i < loopcount; i++)
   {
      enqueue(&qcb, READ, id);
#ifdef SOLARIS
      thr_yield();
#else
      sched_yield();
#endif
      work = fopen("test.dat", "r");
      if (fscanf(work, "%d", &local) != 1)
      {
          printf("YEOW: my input file is trashed \n");
          printf("Thread %d exiting \n", id);
          perror("Failure was");
          fclose(work);
          pthread_exit(0);
      }
      fclose(work);
      sched_yield();
      dequeue(&qcb, id);
      microsleep(90000);
   }
   pthread_exit((void *)0);
}

int main(
int argc,
char **argv)
{
   int            tid;
   int            stat;
   pthread_attr_t attr;

/* Initialize the value in the shared output file */

   io = fopen("test.dat", "w");
   fprintf(io, "%12d", 0);
   fclose(io);

/* Override loop count if user supplied one */

   if (argc > 1)
      sscanf(argv[1], "%d", &loopcount);

   pthread_attr_init(&attr);
   pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

   pthread_mutex_init(&qcb.mtx, NULL);
   pthread_cond_init(&qcb.cv, NULL);

/* Create the threads... writers then readers */

   for (tid = 0; tid < NUM_WRITERS; tid++)
   {
      pthread_create(&td[tid], &attr, wthread, (void *)tid);
   }

   for (; tid < MAX_THREADS; tid++)
   {
      pthread_create(&td[tid], &attr, rthread, (void *)tid);
   }

/* Wait for all  to terminate */

   for (tid = 0; tid < MAX_THREADS; tid++)
   {
      stat = pthread_join(td[tid], NULL);
      printf("Thread %d done \n", tid);
   }
   printf("Made it out \n");
}

