#include <stdio.h>

main(){
int nulval;
nulval=NULL;
printf("%d");
}
