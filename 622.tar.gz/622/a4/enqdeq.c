/* Nell Beatty			*/
/* Computer Science 622		*/
/* October 16, 2000		*/
/* Enqdeq.c			*/

#include <stdlib.h>
#include <stdio.h>
#include "enqdeq.h"

int enqueue( struct qcbtype *q, int action, int tid)
{
  int allocated; /* variable to show success/failure of grab_resource */
  struct qeltype *myqel;
  struct qeltype *tmpqel;
  int result;
  /* Lock the resource mutex */
  pthread_mutex_lock(&q->mtx);
  /* allocated=grab_resource(); */
  allocated=grab_resource(q, action, tid);
  /* If allocated, then unlock mutex & return*/
  if(allocated==1)
  {
     pthread_mutex_unlock(&q->mtx);
     return 1;
  }
  /*   allocate my queue element and put it on the tail of the queue */
  myqel=malloc(sizeof(struct qeltype));
  myqel->tid=tid;
  myqel->action=action;
  myqel->qnext=NULL;
  /* Queue Theory */
  /* Basically, as I see the queue, there is an empty queue, a queue with only */
  /* a head (incoming item is the tail) or a three items or more view */
  /* I am using QUEUE_HEAD as a means to find the head, where QUEUE_TAIL */
  /* is being used for the tail, as a safety measure */
  if (q->qhead==NULL) /*no other's waiting */
  {
    q->qhead=myqel;
    QUEUE_HEAD=myqel;
  }
  else /*other's are waiting, got to find the end, then add */
  {
   if(q->qhead->qnext==NULL) /* only one item in queue */
   {
     q->qhead->qnext=myqel; /* link item in queue */
     q->qtail=myqel; /* since only 2total items in queue, */
                     /* 1st head, new one is tail*/
     QUEUE_TAIL=myqel;
   }
   else
   {
     q->qtail->qnext=myqel; /* link item in queue */
     q->qtail=myqel; /* change the head items tail */
   }
 }
 while(!allocated)  { 
  /*   wait on condition variable */
   pthread_cond_wait(&q->cv, &q->mtx);
    /* if(my-queue-element is at the head of the list)*/
   allocated=grab_resource(q, action, tid);
   if(&QUEUE_HEAD==&myqel)/*verify that this is head)*/
   /*if(&q->qhead==&myqel)verify that this is head)*/
   {
     allocated=grab_resource(q, action, tid);
   }
}
  /* dequeue my queue element */
  /* free my queue element */
  free(myqel);
  /* broadcast the condition variable */
  pthread_cond_broadcast(&q->cv);
  /* unlock and return */ 
     pthread_mutex_unlock(&q->mtx);
     return 1;
}

int dequeue(struct qcbtype *q, int tid)
{
  /* lock the resource mutex */
  pthread_mutex_lock(&q->mtx);
  /* decrement numusing for the resource */
  q->numusing--;
  /* Check to see if the last item in the queue */
  /* if its not, then update local QUEUE_HEAD */
  if(q->qhead->qnext!=NULL)
  {
   QUEUE_HEAD=q->qhead->qnext;
  }
  if(q->numusing==0) 
  {
  /*  broadcast the condition variable  */
   pthread_cond_broadcast(&q->cv);
  }
  /* unlock the resource mutex */
  pthread_mutex_unlock(&q->mtx);
  return 1;
}

int grab_resource( struct qcbtype *q, int action, int tid)
{
   if(q->numusing == 0)  
   {
     /* set resource state to request type (R/W) */
     CURRENT_RES_STATE=action;
     q->state=action;
     /* increment numusing and return */
     q->numusing++;
     return 1;
    }

   if(action==WRITE) 
   {
     return 0;
   } 

  /* if resource state is "R" */
   if(CURRENT_RES_STATE==READ)
   {
  /* increment numusing and return (1) */
     q->numusing++;
     return 1;
   }

   return 0; 
}

