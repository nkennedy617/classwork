#include <stdio.h>

main()
{
  int x;
  x= 0x65 ;
  printf("%d", x);
}
