/* Nell Beatty 							  */
/* Computer Science 622				         	  */
/* Programming Assignment #1 					  */
/* September 06, 2000 						  */


#define _STRUCTURED_PROC 1 /* Dr. Westall said this was important */

#include <procfs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/time.h>


main(int argc, char *argv[])
{ /* Declarations for the whole program */
   psinfo_t mypsinfo; /* structure to read the general info into */
   prusage_t myprusage; /* structure to read the resource info into */
   int open_success;
   int read_success;
   int close_success;
   int str_tmp;
   /*  These are character constructs to assist in assembling the path name  */
   char* file_path= "";
   char file_proc[6] = "/proc/";
   char* file_psinfo = "/psinfo";
   char* file_psusage = "/usage";
   /* used to convert times from nanoseconds to secs */
   long  nanoseconds;
   float  seconds = 0.0;
   /* directory declarations */
   DIR * dir_p;
   struct dirent * dir_entry_p; 
   char* curdir = ".";
   char* prevdir = "..";

    /*  This segment processes information if there are 2 parameters  */
    /*  One parameter is a.out, the other is hopefully a process id   */ 
   if (argc == 2)
   {
     /* make the file path and name by using strcat */
     /* example /proc/580/psinfo          */
     file_path=malloc(1024);
     strcat(file_path, file_proc);
     strcat(file_path, argv[1]);
     strcat(file_path, file_psinfo);
     open_success = open (file_path, O_RDONLY);
     /* make sure open worked alright */
     if (open_success == -1)
     {
	printf("Error! Invalid process id\n");
        exit(EXIT_FAILURE);
     }
     read_success = read (open_success, &mypsinfo, sizeof(mypsinfo));
     /* make sure read worked alright */
     if (read_success == -1)
     {
	printf("Error! Read Failure \n");
        exit(EXIT_FAILURE);
     }
     printf("General information for process ");
     printf("%d\n", mypsinfo.pr_pid);
     printf("Parent pid is:		");
     printf("%d\n", mypsinfo.pr_ppid);
     printf("Number of lwps: 	");
     printf("%d\n", mypsinfo.pr_nlwp);
     printf("Owner's userid is:	");
     printf("%d\n", mypsinfo.pr_uid);
     printf("Owner's groupid is:	");
     printf("%d\n", mypsinfo.pr_gid);
     printf("Program name is:	");
     printf("%s\n\n", mypsinfo.pr_fname);
     close_success = close (open_success);
     /* make the file path and name by using strcat */
     /* example /proc/580/usage          */
     file_path = "";
     file_path=malloc(1024);
     strcat(file_path, file_proc);
     strcat(file_path, argv[1]);
     strcat(file_path, file_psusage);

     open_success = open (file_path, O_RDONLY);   
     /* make sure open worked alright */
     if (open_success == -1)
     {
	printf("Error! Invalid process id\n");
        exit(EXIT_FAILURE);
     }
     read_success = read (open_success, &myprusage, sizeof(myprusage));
     if (read_success == -1)
     {
	printf("Error! Read Failure \n");
        exit(EXIT_FAILURE);
     }
     printf("Resource utilization for process ");
     printf("%d\n", mypsinfo.pr_pid);
     printf("Elapsed time:		");
     nanoseconds=myprusage.pr_rtime.tv_nsec; 
     /*seconds = nanoseconds / 1000000000; */
     seconds = nanoseconds / 100000; 
     seconds = seconds / 100000; 
     printf("%f\n", seconds);
     printf("User CPU time:		");
     nanoseconds=myprusage.pr_utime.tv_nsec; 
     /*seconds = nanoseconds / 1000000000; */
     seconds = nanoseconds / 100000; 
     seconds = seconds / 100000; 
     printf("%f\n", seconds);
     printf("Sys CPU time:		");
     nanoseconds=myprusage.pr_stime.tv_nsec; 
     /*seconds = nanoseconds / 1000000000; */
     seconds = nanoseconds / 100000; 
     seconds = seconds / 100000; 
     printf("%f\n", seconds);
     printf("Sleep time:		");
     nanoseconds=myprusage.pr_slptime.tv_nsec; 
     printf("%d\n", nanoseconds);
     printf("System calls :		");
     printf("%f\n", myprusage.pr_sysc);
     printf("Major page faults :	");
     printf("%d\n", myprusage.pr_majf);
     printf("Minor page faults :	");
     printf("%d\n", myprusage.pr_minf);
     printf("Swaps:			");
     printf("%d\n", myprusage.pr_nswap);
     close_success = close (open_success);
    /*clean up*/
   }
   else
   {
    /* This segment of code process information on receiving only 1  */
    /* parameter, a.out, and according to the assignment, it must    */
    /* process the whole /proc directory to print all processes      */
     if (argc == 1)
     {
       dir_p = opendir(file_proc);
       while (NULL != (dir_entry_p= readdir(dir_p)))
       { 
              /* make the file path and name by using strcat */
              /* example /proc/580/psinfo          */
         file_path = "";
         file_path=malloc(1024);
         strcat(file_path, file_proc);
         /* make sure . nor .. directories get processed */
         if ((str_tmp = strcmp(dir_entry_p->d_name, curdir)!=0))
         {
           if ((str_tmp = strcmp(dir_entry_p->d_name, prevdir)!=0))
 	    {
              strcat(file_path, dir_entry_p->d_name);
              strcat(file_path, file_psinfo);
              open_success = open (file_path, O_RDONLY);
              /* make sure open worked alright */
              if (open_success == -1)
                {
    	           printf("Error! Invalid process id\n");
                   exit(EXIT_FAILURE);
                }
              read_success = read (open_success, &mypsinfo, sizeof(mypsinfo));
              /* make sure read worked alright */
              if (read_success == -1)
              {
  	         printf("Error! Read Failure \n");
                 exit(EXIT_FAILURE);
              }
              printf("General information for process ");
              printf("%d\n", mypsinfo.pr_pid);
              printf("Parent pid is:			");
              printf("%d\n", mypsinfo.pr_ppid);
              printf("Number of lwps: 		");
              printf("%d\n", mypsinfo.pr_nlwp);
              printf("Owner's userid is:		");
              printf("%d\n", mypsinfo.pr_uid);
              printf("Owner's groupid is:		");
              printf("%d\n", mypsinfo.pr_gid);
              printf("Program name is:		");
              printf("%s\n\n", mypsinfo.pr_fname);
              close_success = close (open_success);
              /* make the file path and name by using strcat */
              /* example /proc/580/usage          */
              file_path = "";
              file_path=malloc(1024);
              strcat(file_path, file_proc);
              strcat(file_path, dir_entry_p->d_name);
              strcat(file_path, file_psusage);

  	      /* this section retrieves usage information for a.out*/
              /* with no parmaters being given                     */ 
              open_success = open (file_path, O_RDONLY);   
              /* make sure open worked alright */
              if (open_success == -1)
                {
    	           printf("Error! Invalid process id\n");
                   exit(EXIT_FAILURE);
                }
              read_success = read (open_success, &myprusage, sizeof(myprusage));
              /* make sure read worked alright */
              if (read_success == -1)
              {
	         printf("Error! Read Failure \n");
                 exit(EXIT_FAILURE);
              }
              printf("Resource utilization for process ");
              printf("%d\n", mypsinfo.pr_pid);
              printf("Elapsed time:			");
              nanoseconds=myprusage.pr_rtime.tv_nsec; 
              /*seconds = nanoseconds / 1000000000; */
              seconds = nanoseconds / 100000; 
              seconds = seconds / 100000; 
              printf("%f\n", seconds);
              /*printf("%f\n", myprusage.pr_rtime);*/
              printf("User CPU time:			");
              nanoseconds=myprusage.pr_utime.tv_nsec; 
              /*seconds = nanoseconds / 1000000000; */
              seconds = nanoseconds / 100000; 
              seconds = seconds / 100000; 
              printf("%f\n", seconds);
              printf("Sys CPU time:			");
              nanoseconds=myprusage.pr_stime.tv_nsec; 
              /*seconds = nanoseconds / 1000000000; */
              seconds = nanoseconds / 100000; 
              seconds = seconds / 100000; 
              printf("%f\n", seconds);
              printf("Sleep time:			");
              nanoseconds=myprusage.pr_slptime.tv_nsec; 
              printf("%d\n", nanoseconds);
              printf("System calls :			");
              printf("%d\n", myprusage.pr_sysc);
              printf("Major page faults :		");
              printf("%d\n", myprusage.pr_majf);
              printf("Minor page faults :		");
              printf("%d\n", myprusage.pr_minf);
              printf("Swaps:				");
              printf("%d\n\n", myprusage.pr_nswap);
              close_success = close (open_success);
              }
             }
       else
       {
	NULL;
        }

       }
       /* clean up and close dir */
       closedir(dir_p);
     }
     else
     {
      /* make sure that you aren't getting a.out [pid] [pid] or */
      /* any other combination other than 1 parm [a.out] or */
      /* [a.out pid]					       */
       printf("Error!  You must provide either a process id or no other argument!\n");
       exit(EXIT_FAILURE);
     }
   }

}
