/* pthreadex.c */

/* This version is used to test Peterson's algorithm for N threads */

/* To compile (on a Solaris == SunOS 5.x machine )        */
/*    cc pthreadex.c -lpthread                            */
/* To run                                                 */
/*    a.out 1000000                                       */

/* Nell Beatty							*/
/* Computer Science 622						*/
/* October 4, 2000						*/
/* No changes were made to this code other than commenting out 	*/
/* the lock and unlock stubs of code				*/
/* My code is in the dekker.c file				*/
#define SOLARIS 1

#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>

#define MAX_THREADS 16         /* Maximum possible number of threads  */
#define NUM_THREADS  2         /* Number of threads to us in this run */

pthread_t td[MAX_THREADS];      /* Thread descriptors for the new threads */
pthread_attr_t attr;
pthread_mutex_t t_mtx  = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  t_cond = PTHREAD_COND_INITIALIZER;

volatile int shared = 0;       /* The shared variable being updated */
int loopcount = 100000;        /* Default value for increment count */


FILE *io;

#if 0
void dek_lock(
int tid)
{
#ifdef SAFE
   pthread_mutex_lock(&t_mtx);
#endif
}
void dek_unlock(
int tid)
{
#ifdef SAFE
   pthread_mutex_unlock(&t_mtx);
#endif
}
#endif

/* We will run instances of this function as separate threads */

void xthread(
int  id)       /* Logical thread id.. values are 0, 1, 2,... */
{
   int i;
   int local;
   FILE *work;

   printf("Made it in %d \n", id);

   for (i = 0; i < loopcount; i++)
   {
      dek_lock(id);
      work = fopen("test.dat", "r");
      if (fscanf(work, "%d", &local) != 1)
      {
          printf("YEOW: my input file is trashed \n");
          printf("Thread %d exiting \n", id);
          perror("Failure was");
          fclose(work);
          pthread_exit(0);
      }
      fclose(work);
#ifdef SOLARIS
      thr_yield();
#else
      sched_yield();
#endif
      local += 1;
      work = fopen("test.dat", "w");
      fprintf(work, "%d", local);
      fclose(work);

      dek_unlock(id);
   }
   pthread_exit((void *)0);
}

void main(
int argc,
char **argv)
{
   int tid;
   int pri;
   int stat;
   int tstatus;

/* Initialize the value in the shared output file */

   io = fopen("test.dat", "w");
   fprintf(io, "%12d", 0);
   fclose(io);

/* Override loop count if user supplied one */

   if (argc > 1)
      sscanf(argv[1], "%d", &loopcount);

   pthread_attr_init(&attr);
   pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

/* Create the threads */

   for (tid = 0; tid < NUM_THREADS; tid++)
   {
      pthread_create(&td[tid], &attr, xthread, tid);
   }

/* Wait for all  to terminate */

   for (tid = 0; tid < NUM_THREADS; tid++)
   {
      stat = pthread_join(td[tid], NULL);
      printf("Thread %d done \n", tid);
   }

   printf("Made it out \n");
}

