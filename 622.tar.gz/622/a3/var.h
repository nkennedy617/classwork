#include <stdio.h>

int p0using=0; /* For thread0 to use the critical section */
int p1using=0; /* For thread1 to use the critical section */
int turn=0; /* Indicator for whether it is thread1's turn or  not */


