#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>


dek_unlock(int threadid)
{
 if(threadid==0)
 {
  p0using =0;
  turn = 1;
 }
 else
 {
  p1using=0;
  turn=0;
 }
 return;
}
