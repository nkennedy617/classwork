#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
int p0using;
int p1using;
int turn;

dek_lock(int threadid)
{
 printf("in here");
 if (threadid==0)
 { 
  printf("I am thread 0\n");
  p0using = 1;
  if(p1using==1)
  { 
    printf("Thread1 has lock\n");
    if(turn==1)
    {
     p0using=0;
     while(turn==1);
      p0using = 1;
    }
  }
 }   
 else
 {
  printf("I am thread 1\n");
  p1using =1;
  if(p0using==0)
  {
   if (turn==0)
   {
     p1using=0;
     while(turn==0);
      p1using = 1;
    }
   }
   
 }
 return;
}

dek_unlock(int threadid)
{
 if(threadid==0)
 {
  p0using =0;
  turn = 1;
 }
 else
 {
  p1using=0;
  turn=0;
 }
 return;
}

