/* Nell Beatty 		*/
/* Computer Science 622		*/
/* October 4, 2000		*/
/* Assignment #3		*/
/* Implement Dekker's algorithm */
#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
int p0using=0; /* Flag to indicate whether t0 is using crit. sec. */
int p1using=0; /* Flag to indicate whether t1 is using crit. sec. */
int turn=1; /* Flag to indicate whose turn it is to enter crit sect */
/* This function will lock the critical section for 1 thread */
dek_lock(int tid)
{
  if (tid==0) /* if t0, then check to make sure t1 isn't using */
  {           /* the crit sect  */
    p0using = 1;  /* set your own flag */
    if(p1using==1) /*verify if t1 is using crit sect and that */
    { 			/* it is still their turn */
      if(turn==1)
      {
       p0using=0;  /* unset own variable in case of pre-empt*/
       while(p1using==1); /*not my turn so loop until it is */
        p0using = 1;/* my turn, set my flag and go! */
       }
     }
  }
  else  /* since not t0, must be t1 */
  {
   p1using =1; /* set flag to indicate t1 using the crit sec */
/* since we not the only one wanting to use crit sec, */
/* verify that nobody else is OR that it is our turn */

    if((p0using==1) || (turn==0))
    {
     p1using=0;
     while(p0using==1); /*not my turn so loop until it is*/
      p1using = 1; /* yippee! my turn in crit sec so go*/
    }
   }
return;
}

dek_unlock(int tid)
{
if(tid==0) /* give up turn, and set var to indicate done with */
 {		/* crit sect 		*/
  turn = 1;
  p0using =0;
 }
 else
 {
  turn=0;
  p1using=0;
 }
return;
}

