#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
#include "var.h"


dek_lock(int threadid)
{
 printf("in here");
 if (threadid==0)
 { 
  printf("I am thread 0\n");
  p0using = 1;
  if(p1using==1)
  { 
    printf("Thread1 has lock\n");
    if(turn==1)
    {
     p0using=0;
     while(turn==1);
      p0using = 1;
    }
  }
 }   
 else
 {
  printf("I am thread 1\n");
  p1using =1;
  if(p0using==0)
  {
   if (turn==0)
   {
     p1using=0;
     while(turn==0);
      p1using = 1;
    }
   }
   
 }
 return;
}
